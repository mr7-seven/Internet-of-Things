"""Node kamera Smart Object Monitoring — Python 3.10 / ONNX Runtime CPU."""

from __future__ import annotations

import argparse
import json
import random
import secrets
import string
import threading
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import cv2
import paho.mqtt.client as mqtt

from yolo26_core import YOLO26NMSFree, class_color


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def validate_id(value: str, label: str) -> str:
    allowed = set(string.ascii_letters + string.digits + "_-")
    if not value or len(value) > 48 or any(char not in allowed for char in value):
        raise ValueError(f"{label} hanya boleh berisi huruf, angka, '-' dan '_'")
    return value


class RemoteState:
    def __init__(self, camera_name: str) -> None:
        self._lock = threading.Lock()
        self.config: dict[str, Any] = {
            "enabled": True,
            "mode": "restricted",
            "rules": {},
            "area": "Belum didaftarkan",
            "camera_name": camera_name,
            "config_version": 0,
        }
        self.monitor: dict[str, Any] = {"state": "IDLE", "detail": []}

    def update_config(self, payload: dict[str, Any]) -> None:
        with self._lock:
            self.config.update(payload)

    def update_monitor(self, payload: dict[str, Any]) -> None:
        with self._lock:
            self.monitor.update(payload)

    def snapshot(self) -> tuple[dict[str, Any], dict[str, Any]]:
        with self._lock:
            return dict(self.config), dict(self.monitor)


class MQTTLink:
    def __init__(self, cfg: dict[str, Any], group_id: str, node_id: str, remote: RemoteState) -> None:
        self.cfg = cfg
        self.group_id = group_id
        self.node_id = node_id
        self.remote = remote
        suffix = secrets.token_hex(5)
        self.username = f"onnx_{random.randint(100000, 999999)}"
        self.client_id = f"y26-{group_id}-{node_id}-{suffix}"[:64]
        self.connected = False
        self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=self.client_id)
        self.client.username_pw_set(self.username, secrets.token_urlsafe(12))
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message
        self.base = f"{group_id}/{node_id}"

    def start(self) -> None:
        self.client.will_set(
            f"{self.base}/camera/status",
            json.dumps({"online": False, "id_group": self.group_id, "node_id": self.node_id}),
            qos=int(self.cfg["qos"]), retain=True,
        )
        self.client.connect_async(self.cfg["host"], int(self.cfg["port"]), int(self.cfg["keepalive"]))
        self.client.loop_start()

    def stop(self, camera_name: str) -> None:
        self.publish_camera(False, camera_name)
        self.client.disconnect()
        self.client.loop_stop()

    def _on_connect(self, client, userdata, flags, reason_code, properties) -> None:
        self.connected = reason_code == 0
        if self.connected:
            client.subscribe(f"{self.base}/monitor/config", qos=int(self.cfg["qos"]))
            client.subscribe(f"{self.base}/monitor/status", qos=int(self.cfg["qos"]))
            print(f"[MQTT] Terhubung sebagai {self.client_id} / user {self.username}")
        else:
            print(f"[MQTT] Gagal terhubung: {reason_code}")

    def _on_disconnect(self, client, userdata, disconnect_flags, reason_code, properties) -> None:
        self.connected = False
        print(f"[MQTT] Terputus: {reason_code}")

    def _on_message(self, client, userdata, message) -> None:
        try:
            payload = json.loads(message.payload.decode("utf-8"))
            if message.topic.endswith("/monitor/config") and isinstance(payload, dict):
                self.remote.update_config(payload)
            elif message.topic.endswith("/monitor/status") and isinstance(payload, dict):
                self.remote.update_monitor(payload)
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            print(f"[MQTT] Payload diabaikan: {error}")

    def publish(self, suffix: str, payload: dict[str, Any], retain: bool = False) -> bool:
        if not self.connected:
            return False
        info = self.client.publish(
            f"{self.base}/{suffix}", json.dumps(payload, separators=(",", ":")),
            qos=int(self.cfg["qos"]), retain=retain,
        )
        return info.rc == mqtt.MQTT_ERR_SUCCESS

    def publish_camera(self, online: bool, camera_name: str) -> bool:
        return self.publish("camera/status", {
            "id_group": self.group_id, "node_id": self.node_id,
            "online": online, "camera_name": camera_name, "timestamp": utc_now(),
        }, retain=True)


class StableCounter:
    def __init__(self, frames: int, seconds: float) -> None:
        self.frames = max(1, frames)
        self.seconds = max(0.0, seconds)
        self.candidate: tuple[tuple[str, int], ...] | None = None
        self.candidate_since = 0.0
        self.candidate_frames = 0
        self.published: tuple[tuple[str, int], ...] | None = None

    def update(self, counts: dict[str, int], now: float) -> dict[str, int] | None:
        signature = tuple(sorted((str(name), int(count)) for name, count in counts.items() if count > 0))
        if signature != self.candidate:
            self.candidate = signature
            self.candidate_since = now
            self.candidate_frames = 1
            return None
        self.candidate_frames += 1
        if self.candidate_frames < self.frames or now - self.candidate_since < self.seconds:
            return None
        if signature == self.published:
            return None
        self.published = signature
        return dict(signature)


def draw_panel(frame, counts: dict[str, int], mqtt_ok: bool, group_id: str, node_id: str,
               remote_config: dict[str, Any], monitor: dict[str, Any], fps: float) -> None:
    height, width = frame.shape[:2]
    header_height = 38
    footer_height = 48
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (width, header_height), (20, 24, 30), -1)
    cv2.rectangle(overlay, (0, height - footer_height), (width, height), (20, 24, 30), -1)
    cv2.addWeighted(overlay, 0.78, frame, 0.22, 0, frame)
    state = str(monitor.get("state", "IDLE")).upper()
    state_color = {"NORMAL": (70, 210, 100), "VIOLATION": (60, 70, 245)}.get(state, (0, 205, 255))
    mqtt_text = "MQTT ONLINE" if mqtt_ok else "MQTT OFFLINE"
    cv2.putText(frame, f"{group_id} / {node_id}", (12, 25), cv2.FONT_HERSHEY_SIMPLEX,
                0.56, (255, 255, 255), 1, cv2.LINE_AA)
    right_text = f"{mqtt_text}  |  {state}  |  FPS {fps:.1f}"
    (tw, _), _ = cv2.getTextSize(right_text, cv2.FONT_HERSHEY_SIMPLEX, 0.50, 1)
    cv2.putText(frame, right_text, (max(12, width - tw - 12), 25), cv2.FONT_HERSHEY_SIMPLEX,
                0.50, state_color if mqtt_ok else (60, 70, 245), 1, cv2.LINE_AA)

    object_text = "  |  ".join(
        f"{name} x{count}" for name, count in
        sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:7]
    ) or "Tidak ada objek terdeteksi"
    area = str(remote_config.get("area", "-") or "-")[:22]
    cv2.putText(frame, f"Area: {area}", (12, height - 27), cv2.FONT_HERSHEY_SIMPLEX,
                0.46, (195, 205, 215), 1, cv2.LINE_AA)
    cv2.putText(frame, object_text[:88], (12, height - 9), cv2.FONT_HERSHEY_SIMPLEX,
                0.48, (255, 255, 255), 1, cv2.LINE_AA)


def draw_boxes(frame, detections) -> None:
    for item in detections:
        color = class_color(item.class_id)
        label = f"{item.class_name} {item.score:.2f}"
        cv2.rectangle(frame, (item.x1, item.y1), (item.x2, item.y2), color, 2)
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.52, 1)
        top = max(0, item.y1 - th - 10)
        cv2.rectangle(frame, (item.x1, top), (item.x1 + tw + 8, item.y1), color, -1)
        cv2.putText(frame, label, (item.x1 + 4, max(th + 1, item.y1 - 6)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.52, (255, 255, 255), 1, cv2.LINE_AA)


def main() -> None:
    parser = argparse.ArgumentParser(description="Smart Object Monitoring YOLO26 ONNX CPU")
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args()
    config_path = Path(args.config).expanduser().resolve()
    cfg = load_json(config_path)
    identity = cfg["identity"]
    group_id = validate_id(str(identity["group_id"]), "group_id")
    node_id = validate_id(str(identity["node_id"]), "node_id")
    model_cfg, camera_cfg = cfg["model"], cfg["camera"]
    model_path = (config_path.parent / model_cfg["path"]).resolve()

    detector = YOLO26NMSFree(str(model_path), int(model_cfg["imgsz"]),
                             float(model_cfg["confidence"]), int(model_cfg["threads"]))
    capture = cv2.VideoCapture(int(camera_cfg["index"]))
    capture.set(cv2.CAP_PROP_FRAME_WIDTH, int(camera_cfg["width"]))
    capture.set(cv2.CAP_PROP_FRAME_HEIGHT, int(camera_cfg["height"]))
    capture.set(cv2.CAP_PROP_FPS, int(camera_cfg["fps"]))
    if not capture.isOpened():
        raise RuntimeError(f"Webcam index {camera_cfg['index']} tidak dapat dibuka")

    camera_name = str(camera_cfg.get("name") or f"Camera {camera_cfg['index']}")
    remote = RemoteState(camera_name)
    link = MQTTLink(cfg["mqtt"], group_id, node_id, remote)
    stable = StableCounter(int(cfg["filter"]["stable_frames"]), float(cfg["filter"]["stable_seconds"]))
    heartbeat = float(cfg["mqtt"]["heartbeat_seconds"])
    last_publish = last_camera = 0.0
    last_stable: dict[str, int] = {}
    fps = 0.0
    previous_frame_at = time.perf_counter()
    link.start()

    try:
        while True:
            ok, frame = capture.read()
            if not ok:
                raise RuntimeError("Frame webcam tidak dapat dibaca")
            detections = detector.predict(frame)
            counts = dict(sorted(Counter(item.class_name for item in detections).items()))
            now = time.monotonic()
            frame_at = time.perf_counter()
            instant_fps = 1.0 / max(0.0001, frame_at - previous_frame_at)
            fps = instant_fps if fps == 0.0 else (0.88 * fps + 0.12 * instant_fps)
            previous_frame_at = frame_at
            changed = stable.update(counts, now)
            if changed is not None:
                last_stable = changed
            remote_config, monitor = remote.snapshot()
            if changed is not None or now - last_publish >= heartbeat:
                sent = link.publish("detection/state", {
                    "id_group": group_id, "node_id": node_id,
                    "objects": last_stable, "total_objects": sum(last_stable.values()),
                    "config_version": remote_config.get("config_version", 0),
                    "timestamp": utc_now(), "heartbeat": changed is None,
                }, retain=True)
                if sent:
                    last_publish = now
            if now - last_camera >= heartbeat:
                if link.publish_camera(True, camera_name):
                    last_camera = now

            draw_boxes(frame, detections)
            draw_panel(frame, counts, link.connected, group_id, node_id, remote_config, monitor, fps)
            cv2.imshow("Smart Object Monitoring — tekan Q untuk keluar", frame)
            if cv2.waitKey(1) & 0xFF in (ord("q"), ord("Q"), 27):
                break
    finally:
        link.stop(camera_name)
        capture.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
