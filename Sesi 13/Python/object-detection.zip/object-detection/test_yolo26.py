"""Pengujian mandiri YOLO26 ONNX untuk gambar, video, atau webcam — tanpa MQTT."""

from __future__ import annotations

import argparse
import time
from collections import Counter
from pathlib import Path

import cv2

from yolo26_core import YOLO26NMSFree, class_color


IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}


def resolve_mode(source: str, requested: str) -> str:
    if requested != "auto":
        return requested
    normalized = source.strip().lower()
    if normalized in {"webcam", "camera", "cam"} or normalized.isdigit():
        return "webcam"
    if Path(source).suffix.lower() in IMAGE_EXTENSIONS:
        return "image"
    return "video"


def draw_result(frame, detections, fps: float | None, source_label: str):
    output = frame.copy()
    height, width = output.shape[:2]

    for item in detections:
        color = class_color(item.class_id)
        label = f"{item.class_name} {item.score:.2f}"
        cv2.rectangle(output, (item.x1, item.y1), (item.x2, item.y2), color, 2)
        (text_width, text_height), _ = cv2.getTextSize(
            label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1
        )
        label_top = max(0, item.y1 - text_height - 10)
        cv2.rectangle(
            output,
            (item.x1, label_top),
            (min(width - 1, item.x1 + text_width + 8), item.y1),
            color,
            -1,
        )
        cv2.putText(
            output,
            label,
            (item.x1 + 4, max(text_height + 1, item.y1 - 6)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            1,
            cv2.LINE_AA,
        )

    counts = dict(sorted(Counter(item.class_name for item in detections).items()))
    overlay = output.copy()
    cv2.rectangle(overlay, (0, max(0, height - 54)), (width, height), (18, 22, 30), -1)
    cv2.addWeighted(overlay, 0.78, output, 0.22, 0, output)

    if fps is not None:
        fps_text = f"FPS: {max(0.0, fps):.1f}"
        # Outline hitam menjaga teks terbaca tanpa panel/overlay latar.
        cv2.putText(
            output, fps_text, (12, 28),
            cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 0, 0), 4, cv2.LINE_AA,
        )
        cv2.putText(
            output, fps_text, (12, 28),
            cv2.FONT_HERSHEY_SIMPLEX, 0.65, (50, 255, 120), 2, cv2.LINE_AA,
        )

    summary = " | ".join(f"{name} x{count}" for name, count in counts.items())
    if not summary:
        summary = "Tidak ada objek terdeteksi"
    cv2.putText(
        output, f"Objek: {summary[:105]}", (12, height - 20),
        cv2.FONT_HERSHEY_SIMPLEX, 0.52, (255, 255, 255), 1, cv2.LINE_AA,
    )
    return output, counts


def print_counts(counts: dict[str, int]) -> None:
    if counts:
        print("[DETEKSI] " + ", ".join(f"{name}={count}" for name, count in counts.items()))
    else:
        print("[DETEKSI] Tidak ada objek")


def run_image(detector: YOLO26NMSFree, source: Path, output_path: Path | None, display: bool) -> None:
    frame = cv2.imread(str(source))
    if frame is None:
        raise RuntimeError(f"Gambar tidak dapat dibuka: {source}")
    started = time.perf_counter()
    detections = detector.predict(frame)
    inference_ms = (time.perf_counter() - started) * 1000.0
    image_fps = 1000.0 / max(0.001, inference_ms)
    result, counts = draw_result(frame, detections, image_fps, source.name)
    print_counts(counts)
    print(f"[INFERENCE] {inference_ms:.1f} ms | total objek={sum(counts.values())}")

    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        if not cv2.imwrite(str(output_path), result):
            raise RuntimeError(f"Gagal menyimpan hasil: {output_path}")
        print(f"[OUTPUT] {output_path}")
    if display:
        cv2.imshow("YOLO26 Image — tekan tombol apa saja untuk keluar", result)
        cv2.waitKey(0)
        cv2.destroyAllWindows()


def is_network_source(source: str) -> bool:
    return source.strip().lower().startswith(("http://", "https://", "rtsp://", "rtmp://"))


def open_capture(source: str, mode: str):
    capture_source = int(source) if mode == "webcam" and source.isdigit() else (0 if mode == "webcam" else source)
    if is_network_source(source):
        # Timeout mencegah aplikasi membeku terlalu lama saat segmen HLS/RTSP putus.
        params = [
            cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 10_000,
            cv2.CAP_PROP_READ_TIMEOUT_MSEC, 10_000,
        ]
        try:
            capture = cv2.VideoCapture(capture_source, cv2.CAP_FFMPEG, params)
        except TypeError:
            # Kompatibilitas untuk build OpenCV yang belum menerima parameter constructor.
            capture = cv2.VideoCapture(capture_source, cv2.CAP_FFMPEG)
        capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    else:
        capture = cv2.VideoCapture(capture_source)
    if not capture.isOpened():
        raise RuntimeError(f"Sumber {mode} tidak dapat dibuka: {source}")
    return capture


def run_stream(
    detector: YOLO26NMSFree,
    source: str,
    mode: str,
    output_path: Path | None,
    display: bool,
) -> None:
    network_stream = is_network_source(source)
    capture = open_capture(source, mode)
    writer = None
    fps_average = 0.0
    last_frame_at = time.perf_counter()
    last_counts: dict[str, int] | None = None

    try:
        while True:
            ok, frame = capture.read()
            if not ok:
                if network_stream:
                    print("[STREAM] Koneksi terputus. Mencoba menyambung kembali...")
                    capture.release()
                    time.sleep(2.0)
                    try:
                        capture = open_capture(source, mode)
                        last_frame_at = time.perf_counter()
                        fps_average = 0.0
                        print("[STREAM] Berhasil tersambung kembali.")
                    except RuntimeError as error:
                        print(f"[STREAM] Belum tersambung: {error}")
                    continue
                break
            detections = detector.predict(frame)
            now = time.perf_counter()
            instant_fps = 1.0 / max(0.0001, now - last_frame_at)
            fps_average = instant_fps if fps_average == 0.0 else 0.88 * fps_average + 0.12 * instant_fps
            last_frame_at = now
            result, counts = draw_result(frame, detections, fps_average, mode.upper())

            if counts != last_counts:
                print_counts(counts)
                last_counts = counts

            if output_path and writer is None:
                output_path.parent.mkdir(parents=True, exist_ok=True)
                source_fps = capture.get(cv2.CAP_PROP_FPS)
                output_fps = source_fps if 1.0 <= source_fps <= 240.0 else 25.0
                writer = cv2.VideoWriter(
                    str(output_path), cv2.VideoWriter_fourcc(*"mp4v"), output_fps,
                    (result.shape[1], result.shape[0]),
                )
                if not writer.isOpened():
                    raise RuntimeError(f"Gagal membuat video output: {output_path}")
            if writer:
                writer.write(result)
            if display:
                cv2.imshow("YOLO26 Detection — Q atau ESC untuk keluar", result)
                key = cv2.waitKey(1) & 0xFF
                if key in (ord("q"), ord("Q"), 27):
                    break
    finally:
        capture.release()
        if writer:
            writer.release()
            print(f"[OUTPUT] {output_path}")
        cv2.destroyAllWindows()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Uji YOLO26 ONNX Native NMS-Free tanpa MQTT"
    )
    parser.add_argument("--source", default="0", help="Path gambar/video, indeks webcam, atau 'webcam'")
    parser.add_argument("--mode", choices=("auto", "image", "video", "webcam"), default="auto")
    parser.add_argument("--model", default="models/yolo26n.onnx")
    parser.add_argument("--imgsz", type=int, default=320)
    parser.add_argument("--conf", type=float, default=0.25)
    parser.add_argument("--threads", type=int, default=0)
    parser.add_argument("--output", help="Path hasil gambar atau video; opsional")
    parser.add_argument("--no-display", action="store_true", help="Tidak membuka jendela OpenCV")
    args = parser.parse_args()

    script_directory = Path(__file__).resolve().parent
    model_path = Path(args.model).expanduser()
    if not model_path.is_absolute():
        model_path = script_directory / model_path
    mode = resolve_mode(args.source, args.mode)
    output_path = Path(args.output).expanduser().resolve() if args.output else None
    detector = YOLO26NMSFree(
        str(model_path), imgsz=args.imgsz,
        conf_threshold=args.conf, threads=args.threads,
    )

    print(f"[SOURCE] mode={mode} source={args.source}")
    if mode == "image":
        run_image(detector, Path(args.source).expanduser().resolve(), output_path, not args.no_display)
    else:
        run_stream(detector, args.source, mode, output_path, not args.no_display)


if __name__ == "__main__":
    main()
