"""Runtime khusus YOLO26 ONNX Native NMS-Free menggunakan CPUExecutionProvider."""

from __future__ import annotations

import ast
import colorsys
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np
import onnxruntime as ort


@dataclass(frozen=True)
class Detection:
    x1: int
    y1: int
    x2: int
    y2: int
    score: float
    class_id: int
    class_name: str


class YOLO26NMSFree:
    """Detektor output [batch, max_det, 6] tanpa NMS eksternal."""

    def __init__(
        self,
        model_path: str,
        imgsz: int = 320,
        conf_threshold: float = 0.25,
        threads: int = 0,
    ) -> None:
        path = Path(model_path).expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError(f"Model tidak ditemukan: {path}")
        if not 0.0 <= conf_threshold <= 1.0:
            raise ValueError("conf_threshold harus berada pada rentang 0 sampai 1")

        options = ort.SessionOptions()
        options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        if threads > 0:
            options.intra_op_num_threads = threads
            options.inter_op_num_threads = 1

        self.session = ort.InferenceSession(
            str(path),
            sess_options=options,
            providers=["CPUExecutionProvider"],
        )
        input_meta = self.session.get_inputs()[0]
        self.input_name = input_meta.name
        self.output_name = self.session.get_outputs()[0].name
        shape = input_meta.shape
        self.input_height = int(shape[2]) if isinstance(shape[2], int) else imgsz
        self.input_width = int(shape[3]) if isinstance(shape[3], int) else imgsz
        self.conf_threshold = conf_threshold
        self.names = self._read_names()
        self.metadata = self.session.get_modelmeta().custom_metadata_map

        print(f"[MODEL] {path.name}")
        print(f"[MODEL] Input: 1x3x{self.input_height}x{self.input_width}")
        print(f"[MODEL] Provider: {self.session.get_providers()}")
        print(f"[MODEL] Threads: {threads if threads > 0 else 'otomatis'}")
        print("[MODEL] Post-process: confidence filter saja, tanpa NMS")

    def _read_names(self) -> dict[int, str]:
        raw = self.session.get_modelmeta().custom_metadata_map.get("names", "")
        if raw:
            try:
                parsed = ast.literal_eval(raw)
                if isinstance(parsed, dict):
                    return {int(key): str(value) for key, value in parsed.items()}
                if isinstance(parsed, (list, tuple)):
                    return {index: str(value) for index, value in enumerate(parsed)}
            except (SyntaxError, ValueError, TypeError):
                pass
        return {}

    def _preprocess(self, frame: np.ndarray):
        original_height, original_width = frame.shape[:2]
        scale = min(
            self.input_width / original_width,
            self.input_height / original_height,
        )
        resized_width = int(round(original_width * scale))
        resized_height = int(round(original_height * scale))
        resized = cv2.resize(
            frame, (resized_width, resized_height), interpolation=cv2.INTER_LINEAR
        )
        pad_width = self.input_width - resized_width
        pad_height = self.input_height - resized_height
        left = pad_width // 2
        right = pad_width - left
        top = pad_height // 2
        bottom = pad_height - top
        padded = cv2.copyMakeBorder(
            resized,
            top,
            bottom,
            left,
            right,
            cv2.BORDER_CONSTANT,
            value=(114, 114, 114),
        )
        rgb = cv2.cvtColor(padded, cv2.COLOR_BGR2RGB)
        tensor = rgb.transpose(2, 0, 1)[None].astype(np.float32) / 255.0
        return np.ascontiguousarray(tensor), scale, left, top

    def predict(self, frame: np.ndarray) -> list[Detection]:
        tensor, scale, pad_x, pad_y = self._preprocess(frame)
        output = self.session.run(
            [self.output_name], {self.input_name: tensor}
        )[0]
        return self._decode(output, frame.shape, scale, pad_x, pad_y)

    def _decode(
        self,
        output: np.ndarray,
        original_shape: tuple[int, ...],
        scale: float,
        pad_x: int,
        pad_y: int,
    ) -> list[Detection]:
        predictions = np.asarray(output)
        if predictions.ndim != 3 or predictions.shape[0] != 1:
            raise RuntimeError(f"Batch/output YOLO26 tidak didukung: {predictions.shape}")
        predictions = predictions[0]
        if predictions.ndim != 2 or predictions.shape[1] != 6:
            raise RuntimeError(
                "Model bukan YOLO26 Native NMS-Free [1,max_det,6]: "
                f"{output.shape}"
            )

        predictions = predictions[np.isfinite(predictions).all(axis=1)]
        predictions = predictions[predictions[:, 4] >= self.conf_threshold]
        if len(predictions) == 0:
            return []

        image_height, image_width = original_shape[:2]
        detections: list[Detection] = []
        for x1, y1, x2, y2, score, raw_class_id in predictions:
            x1 = float(np.clip((x1 - pad_x) / scale, 0, image_width - 1))
            y1 = float(np.clip((y1 - pad_y) / scale, 0, image_height - 1))
            x2 = float(np.clip((x2 - pad_x) / scale, 0, image_width - 1))
            y2 = float(np.clip((y2 - pad_y) / scale, 0, image_height - 1))
            if x2 <= x1 or y2 <= y1:
                continue
            class_id = int(round(float(raw_class_id)))
            detections.append(
                Detection(
                    x1=int(x1),
                    y1=int(y1),
                    x2=int(x2),
                    y2=int(y2),
                    score=float(score),
                    class_id=class_id,
                    class_name=self.names.get(class_id, f"class_{class_id}"),
                )
            )
        return sorted(detections, key=lambda item: item.score, reverse=True)


def class_color(class_id: int) -> tuple[int, int, int]:
    hue = (class_id * 0.61803398875) % 1.0
    red, green, blue = colorsys.hsv_to_rgb(hue, 0.78, 1.0)
    return int(blue * 255), int(green * 255), int(red * 255)


def draw_detections(
    frame: np.ndarray, detections: list[Detection], fps: float
) -> np.ndarray:
    for detection in detections:
        color = class_color(detection.class_id)
        label = f"{detection.class_name} {detection.score:.2f}"
        cv2.rectangle(
            frame,
            (detection.x1, detection.y1),
            (detection.x2, detection.y2),
            color,
            2,
        )
        (text_width, text_height), _ = cv2.getTextSize(
            label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1
        )
        label_top = max(0, detection.y1 - text_height - 10)
        cv2.rectangle(
            frame,
            (detection.x1, label_top),
            (detection.x1 + text_width + 8, detection.y1),
            color,
            -1,
        )
        cv2.putText(
            frame,
            label,
            (detection.x1 + 4, max(text_height + 1, detection.y1 - 6)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            1,
            cv2.LINE_AA,
        )
    cv2.putText(
        frame,
        f"FPS: {fps:.1f} | NMS-Free",
        (12, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.70,
        (0, 255, 0),
        2,
        cv2.LINE_AA,
    )
    return frame


def count_objects(detections: list[Detection]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for detection in detections:
        counts[detection.class_name] = counts.get(detection.class_name, 0) + 1
    return dict(sorted(counts.items()))
