#pragma once
#include <Arduino.h>

namespace AppConfig {
constexpr char WIFI_SSID[] = "NAMA_WIFI";
constexpr char WIFI_PASSWORD[] = "PASSWORD_WIFI";
constexpr char MQTT_HOST[] = "broker.hivemq.com";
constexpr uint16_t MQTT_PORT = 1883;
constexpr char MQTT_USERNAME[] = "";
constexpr char MQTT_PASSWORD[] = "";
constexpr char GROUP_ID[] = "kelompok-00";
constexpr char NODE_ID[] = "node-01";

static_assert(sizeof(GROUP_ID) <= 49, "GROUP_ID maksimal 48 karakter");
static_assert(sizeof(NODE_ID) <= 49, "NODE_ID maksimal 48 karakter");
constexpr uint32_t WIFI_RECONNECT_INTERVAL_MS = 3000;
constexpr uint32_t WIFI_CONNECT_TIMEOUT_MS = 10000;
constexpr uint32_t MQTT_RECONNECT_INTERVAL_MS = 5000;
constexpr uint32_t MQTT_CONNECT_TIMEOUT_MS = 10000;
constexpr uint32_t STATUS_HEARTBEAT_MS = 10000;
constexpr uint32_t BUTTON_DEBOUNCE_MS = 50;
constexpr uint32_t BUTTON_HOLD_MS = 3000;
constexpr uint32_t BUTTON_BEEP_MS = 120;
constexpr uint32_t ALARM_ON_MS = 250;
constexpr uint32_t ALARM_OFF_MS = 250;

constexpr uint8_t LED_RED_PIN = 25;
constexpr uint8_t LED_YELLOW_PIN = 26;
constexpr uint8_t LED_GREEN_PIN = 27;
constexpr uint8_t BUZZER_PIN = 32;
constexpr uint8_t BUTTON_PIN = 33;
constexpr bool LED_ACTIVE_HIGH = true;
constexpr bool BUZZER_ACTIVE_HIGH = true;
constexpr bool BUTTON_ACTIVE_LOW = true;
}
