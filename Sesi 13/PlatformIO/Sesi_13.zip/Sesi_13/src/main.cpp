#include <Arduino.h>
#include <ArduinoJson.h>
#include <WiFi.h>
#include <esp_system.h>
#include <cstring>

#include "app_config.h"
#include "mqtt_manager.h"
#include "wifi_manager.h"

WifiManager wifiManager(AppConfig::WIFI_SSID, AppConfig::WIFI_PASSWORD,
                        AppConfig::WIFI_RECONNECT_INTERVAL_MS,
                        AppConfig::WIFI_CONNECT_TIMEOUT_MS);
char commandTopic[160], registrationTopic[128], statusTopic[160], clientId[128];
MqttManager mqttManager(AppConfig::MQTT_HOST, AppConfig::MQTT_PORT, commandTopic,
                        AppConfig::MQTT_USERNAME, AppConfig::MQTT_PASSWORD,
                        AppConfig::MQTT_RECONNECT_INTERVAL_MS,
                        AppConfig::MQTT_CONNECT_TIMEOUT_MS);

enum class MonitorState : uint8_t { Idle, Normal, Violation };
MonitorState monitorState = MonitorState::Idle;
portMUX_TYPE commandMux = portMUX_INITIALIZER_UNLOCKED;
char pendingCommand[512] = "";
bool commandAvailable = false;
bool alarmRequested = false, alarmOutput = false;
uint32_t alarmChangedAt = 0, buttonBeepUntil = 0;
bool buttonRaw = false, buttonStable = false, longPressSent = false;
uint32_t buttonChangedAt = 0, buttonPressedAt = 0;
String lastCommandKey;
bool mqttWasConnected = false;
uint32_t lastStatusAt = 0;

void setOutput(uint8_t pin, bool on, bool activeHigh) {
  digitalWrite(pin, on == activeHigh ? HIGH : LOW);
}
const char* monitorStateName() {
  if (monitorState == MonitorState::Normal) return "normal";
  if (monitorState == MonitorState::Violation) return "violation";
  return "idle";
}
void applyLedOutputs() {
  setOutput(AppConfig::LED_RED_PIN, monitorState == MonitorState::Violation, AppConfig::LED_ACTIVE_HIGH);
  setOutput(AppConfig::LED_YELLOW_PIN, monitorState == MonitorState::Idle, AppConfig::LED_ACTIVE_HIGH);
  setOutput(AppConfig::LED_GREEN_PIN, monitorState == MonitorState::Normal, AppConfig::LED_ACTIVE_HIGH);
}
void startButtonBeep(uint32_t now) {
  buttonBeepUntil = now + AppConfig::BUTTON_BEEP_MS;
  setOutput(AppConfig::BUZZER_PIN, true, AppConfig::BUZZER_ACTIVE_HIGH);
}
void updateBuzzer(uint32_t now) {
  if (static_cast<int32_t>(buttonBeepUntil - now) > 0) {
    setOutput(AppConfig::BUZZER_PIN, true, AppConfig::BUZZER_ACTIVE_HIGH);
    return;
  }
  if (!alarmRequested) {
    alarmOutput = false;
    setOutput(AppConfig::BUZZER_PIN, false, AppConfig::BUZZER_ACTIVE_HIGH);
    return;
  }
  const uint32_t interval = alarmOutput ? AppConfig::ALARM_ON_MS : AppConfig::ALARM_OFF_MS;
  if (now - alarmChangedAt >= interval) {
    alarmOutput = !alarmOutput;
    alarmChangedAt = now;
  }
  setOutput(AppConfig::BUZZER_PIN, alarmOutput, AppConfig::BUZZER_ACTIVE_HIGH);
}
void queueCommand(const char* topic, const char* payload) {
  if (!topic || !payload || std::strcmp(topic, commandTopic) != 0) return;
  const size_t length = strnlen(payload, sizeof(pendingCommand));
  if (length >= sizeof(pendingCommand)) return;
  portENTER_CRITICAL(&commandMux);
  std::memcpy(pendingCommand, payload, length + 1);
  commandAvailable = true;
  portEXIT_CRITICAL(&commandMux);
}
void processCommand(uint32_t now) {
  char payload[sizeof(pendingCommand)];
  portENTER_CRITICAL(&commandMux);
  const bool available = commandAvailable;
  if (available) { std::memcpy(payload, pendingCommand, sizeof(payload)); commandAvailable = false; }
  portEXIT_CRITICAL(&commandMux);
  if (!available) return;
  JsonDocument doc;
  if (deserializeJson(doc, payload) || !doc.is<JsonObject>()) return;
  if (std::strcmp(doc["id_group"] | "", AppConfig::GROUP_ID) != 0 ||
      std::strcmp(doc["node_id"] | "", AppConfig::NODE_ID) != 0) return;
  const char* state = doc["state"] | "";
  const bool alarm = doc["alarm"] | false;
  const char* eventId = doc["event_id"] | "";
  const String commandKey = String(state) + "|" + String(alarm) + "|" + eventId;
  if (commandKey == lastCommandKey) return;
  lastCommandKey = commandKey;
  if (std::strcmp(state, "normal") == 0) monitorState = MonitorState::Normal;
  else if (std::strcmp(state, "violation") == 0) monitorState = MonitorState::Violation;
  else monitorState = MonitorState::Idle;
  alarmRequested = alarm && monitorState == MonitorState::Violation;
  alarmOutput = alarmRequested;
  alarmChangedAt = now;
  applyLedOutputs();
  Serial.printf("[MONITOR] state=%s alarm=%s\n", monitorStateName(), alarmRequested ? "ON" : "OFF");
}
bool publishRegistration(uint32_t now) {
  if (!mqttManager.connected()) return false;
  JsonDocument doc;
  doc["id_group"] = AppConfig::GROUP_ID;
  doc["node_id"] = AppConfig::NODE_ID;
  doc["event_id"] = String(clientId) + "-" + String(now);
  doc["uptime_ms"] = now;
  char payload[256];
  if (measureJson(doc) >= sizeof(payload)) return false;
  serializeJson(doc, payload, sizeof(payload));
  return mqttManager.publish(registrationTopic, payload, false);
}
void updateButton(uint32_t now) {
  const bool rawPressed = AppConfig::BUTTON_ACTIVE_LOW ? digitalRead(AppConfig::BUTTON_PIN) == LOW
                                                       : digitalRead(AppConfig::BUTTON_PIN) == HIGH;
  if (rawPressed != buttonRaw) { buttonRaw = rawPressed; buttonChangedAt = now; }
  if (now - buttonChangedAt >= AppConfig::BUTTON_DEBOUNCE_MS && buttonStable != buttonRaw) {
    buttonStable = buttonRaw;
    if (buttonStable) {
      buttonPressedAt = now;
      longPressSent = false;
      startButtonBeep(now);
      Serial.println("[TOMBOL] Terbaca; tahan 3 detik untuk registrasi");
    }
  }
  if (buttonStable && !longPressSent && now - buttonPressedAt >= AppConfig::BUTTON_HOLD_MS) {
    longPressSent = true;
    Serial.printf("[REGISTRASI] %s\n", publishRegistration(now) ? "terkirim" : "gagal");
  }
}
bool publishStatus(uint32_t now) {
  if (!mqttManager.connected()) return false;
  JsonDocument doc;
  doc["id_group"] = AppConfig::GROUP_ID;
  doc["node_id"] = AppConfig::NODE_ID;
  doc["online"] = true;
  doc["monitor_state"] = monitorStateName();
  doc["alarm"] = alarmRequested;
  doc["rssi"] = WiFi.RSSI();
  doc["uptime_ms"] = now;
  char payload[256];
  if (measureJson(doc) >= sizeof(payload)) return false;
  serializeJson(doc, payload, sizeof(payload));
  return mqttManager.publish(statusTopic, payload, true);
}
void setup() {
  Serial.begin(115200); delay(200);
  pinMode(AppConfig::LED_RED_PIN, OUTPUT); pinMode(AppConfig::LED_YELLOW_PIN, OUTPUT);
  pinMode(AppConfig::LED_GREEN_PIN, OUTPUT); pinMode(AppConfig::BUZZER_PIN, OUTPUT);
  pinMode(AppConfig::BUTTON_PIN, AppConfig::BUTTON_ACTIVE_LOW ? INPUT_PULLUP : INPUT_PULLDOWN);
  applyLedOutputs(); setOutput(AppConfig::BUZZER_PIN, false, AppConfig::BUZZER_ACTIVE_HIGH);
  snprintf(commandTopic, sizeof(commandTopic), "%s/%s/esp32/cmd", AppConfig::GROUP_ID, AppConfig::NODE_ID);
  snprintf(registrationTopic, sizeof(registrationTopic), "%s/node/register", AppConfig::GROUP_ID);
  snprintf(statusTopic, sizeof(statusTopic), "%s/%s/esp32/status", AppConfig::GROUP_ID, AppConfig::NODE_ID);
  const uint64_t chipId = ESP.getEfuseMac();
  snprintf(clientId, sizeof(clientId), "smart-monitor-%s-%s-%04X%08X", AppConfig::GROUP_ID,
           AppConfig::NODE_ID, static_cast<uint16_t>(chipId >> 32), static_cast<uint32_t>(chipId));
  mqttManager.setCallback(queueCommand); mqttManager.begin(clientId); wifiManager.begin();
}
void loop() {
  const uint32_t now = millis();
  wifiManager.loop(); mqttManager.loop(wifiManager.connected()); processCommand(now);
  updateButton(now); updateBuzzer(now);
  const bool connected = mqttManager.connected();
  if (connected && (!mqttWasConnected || now - lastStatusAt >= AppConfig::STATUS_HEARTBEAT_MS)) {
    if (publishStatus(now)) lastStatusAt = now;
  }
  mqttWasConnected = connected;
}
