from __future__ import annotations

import argparse
import json
import math
import os
import time
from pathlib import Path
from typing import Any

import cv2

from gesture_detector import GestureDetectorLite, HandObservation


PROJECT_DIR = Path(__file__).resolve().parent


def load_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Config tidak ditemukan: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def distance(a, b) -> float:
    return math.hypot(a.x - b.x, a.y - b.y)


class VirtualTestControl:
    """Simulasi lokal: slider tangan kiri dan toggle tangan kanan."""

    def __init__(self, pinch_threshold: float) -> None:
        self.pinch_threshold = pinch_threshold
        self.slider_value = 0
        self.toggle_on = False
        self.left_pointer: tuple[int, int] | None = None
        self.right_pointer: tuple[int, int] | None = None
        self._button_contact = False

    @staticmethod
    def layout(width: int) -> tuple[tuple[int, int, int, int], tuple[int, int], int]:
        slider = (24, 58, max(230, min(330, int(width * 0.48))), 88)
        button = (max(slider[2] + 85, width - 88), 82)
        radius = max(42, min(55, int(width * 0.075)))
        return slider, button, radius

    @staticmethod
    def pointer(hand: HandObservation, width: int, height: int) -> tuple[int, int]:
        tip = hand.landmarks[8]
        return int(tip.x * width), int(tip.y * height)

    def update(
        self,
        left: HandObservation | None,
        right: HandObservation | None,
        frame_shape,
    ) -> None:
        height, width = frame_shape[:2]
        slider, button, radius = self.layout(width)

        self.left_pointer = None if left is None else self.pointer(left, width, height)
        if left is not None and self.left_pointer is not None:
            pinched = distance(left.landmarks[8], left.landmarks[4]) <= self.pinch_threshold
            x, y = self.left_pointer
            x1, y1, x2, y2 = slider
            if pinched and x1 - 15 <= x <= x2 + 15 and y1 - 18 <= y <= y2 + 18:
                ratio = max(0.0, min(1.0, (x - x1) / max(1, x2 - x1)))
                self.slider_value = int(round(ratio * 100))

        self.right_pointer = None if right is None else self.pointer(right, width, height)
        contact = False
        if self.right_pointer is not None:
            contact = math.hypot(
                self.right_pointer[0] - button[0],
                self.right_pointer[1] - button[1],
            ) <= radius
        if contact and not self._button_contact:
            self.toggle_on = not self.toggle_on
        self._button_contact = contact

    def draw(self, frame) -> None:
        height, width = frame.shape[:2]
        slider, button, radius = self.layout(width)
        x1, y1, x2, y2 = slider

        cv2.putText(
            frame, "LEFT: PINCH SLIDER", (x1, 35),
            cv2.FONT_HERSHEY_SIMPLEX, 0.43, (255, 255, 255), 1, cv2.LINE_AA,
        )
        cv2.rectangle(frame, (x1, y1), (x2, y2), (48, 54, 62), -1)
        fill = x1 + int((x2 - x1) * self.slider_value / 100)
        cv2.rectangle(frame, (x1, y1), (fill, y2), (230, 145, 45), -1)
        cv2.rectangle(frame, (x1, y1), (x2, y2), (220, 225, 230), 1)
        cv2.putText(
            frame, f"{self.slider_value}%", (x1 + 8, y1 + 21),
            cv2.FONT_HERSHEY_SIMPLEX, 0.48, (255, 255, 255), 1, cv2.LINE_AA,
        )

        color = (45, 190, 75) if self.toggle_on else (55, 55, 225)
        cv2.circle(frame, button, radius, color, -1, cv2.LINE_AA)
        cv2.circle(frame, button, radius, (235, 235, 235), 2, cv2.LINE_AA)
        text = "ON" if self.toggle_on else "OFF"
        size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.65, 2)[0]
        cv2.putText(
            frame, text, (button[0] - size[0] // 2, button[1] + size[1] // 2),
            cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2, cv2.LINE_AA,
        )

        if self.left_pointer is not None:
            cv2.circle(frame, self.left_pointer, 9, (0, 220, 255), 2, cv2.LINE_AA)
        if self.right_pointer is not None:
            cv2.circle(frame, self.right_pointer, 9, (255, 255, 255), 2, cv2.LINE_AA)


def add_footer(frame, left_label: str, right_label: str, fps: float):
    height, width = frame.shape[:2]
    footer_height = 30
    canvas = cv2.copyMakeBorder(
        frame, 0, footer_height, 0, 0, cv2.BORDER_CONSTANT, value=(16, 21, 28)
    )
    left_text = f"LEFT: {left_label or 'IDLE'}"
    right_text = f"RIGHT: {right_label or 'IDLE'}"
    fps_text = f"FPS {fps:.1f}"
    cv2.putText(canvas, left_text, (8, height + 20), cv2.FONT_HERSHEY_SIMPLEX,
                0.40, (85, 225, 255), 1, cv2.LINE_AA)
    fps_width = cv2.getTextSize(fps_text, cv2.FONT_HERSHEY_SIMPLEX, 0.38, 1)[0][0]
    cv2.putText(canvas, fps_text, ((width - fps_width) // 2, height + 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.38, (180, 190, 200), 1, cv2.LINE_AA)
    right_width = cv2.getTextSize(right_text, cv2.FONT_HERSHEY_SIMPLEX, 0.40, 1)[0][0]
    cv2.putText(canvas, right_text, (max(8, width - right_width - 8), height + 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.40, (130, 255, 150), 1, cv2.LINE_AA)
    return canvas


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Uji gesture dua tangan dan virtual control tanpa MQTT"
    )
    parser.add_argument("--config", type=Path, default=PROJECT_DIR / "config.json")
    parser.add_argument("--camera", type=int, default=None, help="Override indeks webcam")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config.resolve())
    camera = config.get("camera", {})
    detection = config.get("detection", {})
    node2 = config.get("node2", {})

    detector = GestureDetectorLite(
        min_detection_confidence=float(detection.get("min_detection_confidence", 0.6)),
        min_tracking_confidence=float(detection.get("min_tracking_confidence", 0.6)),
        extended_angle=float(detection.get("extended_angle", 155.0)),
        max_num_hands=2,
    )
    controller = VirtualTestControl(float(node2.get("pinch_threshold", 0.065)))
    camera_index = int(camera.get("index", 0) if args.camera is None else args.camera)
    backend = cv2.CAP_DSHOW if os.name == "nt" else cv2.CAP_ANY
    capture = cv2.VideoCapture(camera_index, backend)
    capture.set(cv2.CAP_PROP_FRAME_WIDTH, int(camera.get("width", 640)))
    capture.set(cv2.CAP_PROP_FRAME_HEIGHT, int(camera.get("height", 480)))
    capture.set(cv2.CAP_PROP_FPS, int(camera.get("target_fps", 20)))
    capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    if not capture.isOpened():
        detector.close()
        raise RuntimeError("Webcam tidak dapat dibuka; ubah --camera atau camera.index")

    previous = time.perf_counter()
    smoothed_fps = 0.0
    mirror = bool(camera.get("mirror", True))
    print("[TEST] Tanpa MQTT | Q atau ESC untuk keluar")
    try:
        while True:
            ok, frame = capture.read()
            if not ok:
                continue
            if mirror:
                frame = cv2.flip(frame, 1)
            result, observations = detector.process(frame, swap_handedness=not mirror)
            left = observations.get("LEFT")
            right = observations.get("RIGHT")
            left_label = left.pose.label if left is not None else "IDLE"
            right_label = right.pose.label if right is not None else "IDLE"

            controller.update(left, right, frame.shape)
            detector.draw(frame, result, observations, swap_handedness=not mirror)
            controller.draw(frame)

            now = time.perf_counter()
            instant_fps = 1.0 / max(now - previous, 1e-6)
            previous = now
            smoothed_fps = instant_fps if smoothed_fps == 0 else 0.9 * smoothed_fps + 0.1 * instant_fps
            output = add_footer(frame, left_label, right_label, smoothed_fps)
            cv2.imshow("Test Gesture + Virtual Control (Tanpa MQTT)", output)
            if cv2.waitKey(1) & 0xFF in (ord("q"), ord("Q"), 27):
                break
    except KeyboardInterrupt:
        pass
    finally:
        capture.release()
        detector.close()
        cv2.destroyAllWindows()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
