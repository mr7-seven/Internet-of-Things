from __future__ import annotations


class StableCommand:
    """Accept a command only after it appears for N consecutive frames."""

    def __init__(self, confirm_frames: int = 4) -> None:
        if confirm_frames < 1:
            raise ValueError("confirm_frames minimal 1")
        self.confirm_frames = confirm_frames
        self.current: str | None = None
        self._candidate: str | None = None
        self._count = 0

    def update(self, observed: str | None) -> tuple[str | None, bool]:
        if observed is None:
            self._candidate = None
            self._count = 0
            return self.current, False

        if observed == self.current:
            self._candidate = observed
            self._count = 0
            return self.current, False

        if observed != self._candidate:
            self._candidate = observed
            self._count = 1
        else:
            self._count += 1

        if self._count >= self.confirm_frames:
            self.current = observed
            self._count = 0
            return self.current, True

        return self.current, False

    def reset(self) -> None:
        """Lepaskan state agar gesture diskret yang sama dapat dipicu ulang."""
        self.current = None
        self._candidate = None
        self._count = 0
