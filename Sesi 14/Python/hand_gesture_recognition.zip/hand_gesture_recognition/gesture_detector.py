from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Sequence

import cv2
import mediapipe as mp


NON_THUMB_FINGERS = (
    (5, 6, 8),
    (9, 10, 12),
    (13, 14, 16),
    (17, 18, 20),
)


@dataclass(frozen=True)
class HandPose:
    label: str
    extended_fingers: int
    thumb_up: bool


@dataclass(frozen=True)
class HandObservation:
    side: str
    pose: HandPose
    landmarks: Sequence
    score: float


def _angle(a, b, c) -> float:
    ba = (a.x - b.x, a.y - b.y, a.z - b.z)
    bc = (c.x - b.x, c.y - b.y, c.z - b.z)
    dot = sum(x * y for x, y in zip(ba, bc))
    len_ba = math.sqrt(sum(x * x for x in ba))
    len_bc = math.sqrt(sum(x * x for x in bc))
    if len_ba < 1e-9 or len_bc < 1e-9:
        return 0.0
    cosine = max(-1.0, min(1.0, dot / (len_ba * len_bc)))
    return math.degrees(math.acos(cosine))


def _distance(a, b) -> float:
    return math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2)


def classify_pose(landmarks: Sequence, extended_angle: float) -> HandPose:
    extended = sum(
        _angle(landmarks[mcp], landmarks[pip], landmarks[tip]) >= extended_angle
        for mcp, pip, tip in NON_THUMB_FINGERS
    )

    wrist = landmarks[0]
    thumb_mcp = landmarks[2]
    thumb_ip = landmarks[3]
    thumb_tip = landmarks[4]
    thumb_straight = _angle(thumb_mcp, thumb_ip, thumb_tip) >= extended_angle
    thumb_far = _distance(wrist, thumb_tip) > _distance(wrist, thumb_ip) * 1.08
    thumb_is_extended = thumb_straight and thumb_far
    thumb_up = (
        extended == 0
        and thumb_is_extended
        and thumb_tip.y < thumb_ip.y < thumb_mcp.y
    )

    if thumb_up:
        label = "THUMB_UP"
    elif extended == 0 and not thumb_is_extended:
        label = "FIST"
    elif extended == 4:
        label = "OPEN_PALM"
    elif extended in (1, 2, 3):
        label = f"FINGERS_{extended}"
    else:
        label = "IDLE"

    return HandPose(label=label, extended_fingers=extended, thumb_up=thumb_up)


class GestureDetectorLite:
    def __init__(
        self,
        min_detection_confidence: float,
        min_tracking_confidence: float,
        extended_angle: float,
        max_num_hands: int = 2,
    ) -> None:
        self.extended_angle = extended_angle
        self._hands_module = mp.solutions.hands
        self._drawing = mp.solutions.drawing_utils
        self._styles = mp.solutions.drawing_styles
        self._hands = self._hands_module.Hands(
            static_image_mode=False,
            max_num_hands=max(1, min(2, int(max_num_hands))),
            model_complexity=0,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        )

    def process(
        self, bgr_image, swap_handedness: bool = False
    ) -> tuple[Any, dict[str, HandObservation]]:
        rgb = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2RGB)
        rgb.flags.writeable = False
        result = self._hands.process(rgb)
        observations: dict[str, HandObservation] = {}

        if result.multi_handedness and result.multi_hand_landmarks:
            for index, handedness in enumerate(result.multi_handedness):
                side = handedness.classification[0].label.upper()
                if swap_handedness:
                    side = "RIGHT" if side == "LEFT" else "LEFT"
                landmarks = result.multi_hand_landmarks[index].landmark
                observations[side] = HandObservation(
                    side=side,
                    pose=classify_pose(landmarks, self.extended_angle),
                    landmarks=landmarks,
                    score=float(handedness.classification[0].score),
                )
        return result, observations

    def draw(
        self,
        image,
        result,
        observations: dict[str, HandObservation],
        swap_handedness: bool,
    ) -> None:
        # Label gesture tidak digambar di dekat tangan karena mudah menutupi
        # area interaksi. Gesture aktif ditampilkan ringkas pada footer main.py.
        _ = observations, swap_handedness
        if not result.multi_hand_landmarks:
            return
        for landmarks in result.multi_hand_landmarks:
            self._drawing.draw_landmarks(
                image,
                landmarks,
                self._hands_module.HAND_CONNECTIONS,
                self._styles.get_default_hand_landmarks_style(),
                self._styles.get_default_hand_connections_style(),
            )

    def close(self) -> None:
        self._hands.close()
