from __future__ import annotations

import json
import secrets
import threading
from datetime import datetime, timezone
from typing import Any, Callable

import paho.mqtt.client as mqtt


MessageHandler = Callable[[str, dict[str, Any]], None]


class MqttRuntime:
    """MQTT bersama untuk ketiga mode dengan topic group/node yang terisolasi."""

    def __init__(
        self,
        group_id: str,
        node_id: str,
        config: dict[str, Any],
        handler: MessageHandler | None = None,
    ) -> None:
        self.group_id = group_id
        self.node_id = node_id
        self.enabled = bool(config.get("enabled", True))
        self.host = str(config.get("host", "broker.emqx.io"))
        self.port = int(config.get("port", 1883))
        self.qos = int(config.get("qos", 1))
        self.keepalive = int(config.get("keepalive", 60))
        self.heartbeat_seconds = float(config.get("heartbeat_seconds", 10))
        self.prefix = str(config.get("topic_prefix", "gesture")).strip("/")
        self.base = f"{self.prefix}/{group_id}/{node_id}"
        self.handler = handler
        self._connected = threading.Event()
        self._sequence = 0
        self._client: mqtt.Client | None = None

        suffix = secrets.token_hex(4)
        self.client_id = f"{config.get('client_id_prefix', 'gesture_py')}_{group_id}_{node_id}_{suffix}"
        self.username = f"{config.get('username_prefix', 'gesture_user')}_{suffix}"
        self.topics = {
            "command": f"{self.base}/command",
            "event": f"{self.base}/event",
            "control": f"{self.base}/control",
            "python_status": f"{self.base}/python/status",
            "device_status": f"{self.base}/device/status",
            "availability": f"{self.base}/availability/python",
        }
        if not self.enabled:
            return

        self._client = mqtt.Client(
            callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
            client_id=self.client_id,
            protocol=mqtt.MQTTv311,
        )
        password = str(config.get("password", ""))
        configured_username = str(config.get("username", "")).strip()
        self._client.username_pw_set(configured_username or self.username, password)
        self._client.will_set(
            self.topics["availability"],
            json.dumps(self._identity_payload(online=False), separators=(",", ":")),
            qos=self.qos,
            retain=True,
        )
        self._client.on_connect = self._on_connect
        self._client.on_disconnect = self._on_disconnect
        self._client.on_message = self._on_message
        self._client.reconnect_delay_set(min_delay=1, max_delay=30)

    def _identity_payload(self, **extra: Any) -> dict[str, Any]:
        return {
            "group_id": self.group_id,
            "node_id": self.node_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            **extra,
        }

    def _on_connect(self, client, userdata, flags, reason_code, properties) -> None:
        if reason_code != 0:
            print(f"[MQTT] Connection rejected: {reason_code}")
            return
        self._connected.set()
        client.subscribe(self.topics["control"], qos=self.qos)
        client.subscribe(self.topics["device_status"], qos=self.qos)
        client.publish(
            self.topics["availability"],
            json.dumps(self._identity_payload(online=True), separators=(",", ":")),
            qos=self.qos,
            retain=True,
        )
        print(f"[MQTT] CONNECTED {self.host}:{self.port}")
        print(f"[MQTT] Base topic: {self.base}")

    def _on_disconnect(self, client, userdata, disconnect_flags, reason_code, properties) -> None:
        self._connected.clear()
        if reason_code != 0:
            print(f"[MQTT] Disconnected; reconnecting ({reason_code})")

    def _on_message(self, client, userdata, message) -> None:
        try:
            payload = json.loads(message.payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return
        if not isinstance(payload, dict):
            return
        if payload.get("group_id") != self.group_id or payload.get("node_id") != self.node_id:
            return
        if self.handler:
            self.handler(message.topic, payload)

    def start(self) -> None:
        if not self.enabled or self._client is None:
            print("[MQTT] DISABLED")
            return
        self._client.connect_async(self.host, self.port, self.keepalive)
        self._client.loop_start()

    def ready(self) -> bool:
        return not self.enabled or self._connected.is_set()

    def connected(self) -> bool:
        return self.enabled and self._connected.is_set()

    def _publish(self, topic: str, payload: dict[str, Any], retain: bool = False) -> bool:
        if not self.enabled:
            print(f"[MQTT-OFF] {topic}: {payload}")
            return True
        if self._client is None or not self._connected.is_set():
            return False
        info = self._client.publish(
            topic,
            json.dumps(payload, separators=(",", ":")),
            qos=self.qos,
            retain=retain,
        )
        return info.rc == mqtt.MQTT_ERR_SUCCESS

    def publish_command(self, device: str, value: Any, gesture: str) -> bool:
        self._sequence += 1
        command_id = f"{self.node_id}-{self._sequence}-{secrets.token_hex(2)}"
        return self._publish(
            self.topics["command"],
            self._identity_payload(
                command_id=command_id,
                seq=self._sequence,
                device=device,
                value=value,
                gesture=gesture,
            ),
            retain=False,
        )

    def publish_event(self, gesture: str, action: str, app_mode: str) -> bool:
        self._sequence += 1
        return self._publish(
            self.topics["event"],
            self._identity_payload(
                event_id=f"{self.node_id}-{self._sequence}-{secrets.token_hex(2)}",
                seq=self._sequence,
                gesture=gesture,
                action=action,
                app_mode=app_mode,
            ),
            retain=False,
        )

    def publish_status(self, mode: int, gesture: str, last_command: str) -> bool:
        return self._publish(
            self.topics["python_status"],
            self._identity_payload(
                online=True,
                camera_online=True,
                mode=mode,
                gesture=gesture,
                last_command=last_command,
            ),
            retain=False,
        )

    def stop(self) -> None:
        if not self.enabled or self._client is None:
            return
        if self._connected.is_set():
            self._publish(self.topics["availability"], self._identity_payload(online=False), True)
        self._client.disconnect()
        self._client.loop_stop()

