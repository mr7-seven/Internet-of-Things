from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Any

import cv2

from gesture_detector import HandObservation


@dataclass(frozen=True)
class TouchCommand:
    device: str
    value: int | bool
    gesture: str


def _distance(a, b) -> float:
    return math.hypot(a.x - b.x, a.y - b.y)


class VirtualTouchController:
    """Slider khusus tangan kiri dan tombol relay khusus tangan kanan."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.values = {"PWM_RED": 0, "PWM_YELLOW": 0, "PWM_GREEN": 0}
        self.relay_requested = False
        self.actual = {**self.values, "RELAY": False}
        self.pinch_threshold = float(config.get("pinch_threshold", 0.065))
        self.publish_interval = float(config.get("publish_interval_seconds", 0.08))
        self.deadband = int(config.get("deadband_percent", 1))
        self.dragging: str | None = None
        self._left_pinched = False
        self._button_contact = False
        self._last_publish_at = 0.0
        self._last_published = dict(self.values)
        self.left_pointer: tuple[int, int] | None = None
        self.right_pointer: tuple[int, int] | None = None
        self.left_state = "NORMAL"
        self.right_state = "NORMAL"

    @staticmethod
    def _layout(width: int, height: int):
        left = 24
        right = max(230, min(int(width * 0.46), 330))
        top = 54
        gap = max(62, int(height * 0.14))
        sliders = {
            "PWM_RED": (left, top, right, top + 28),
            "PWM_YELLOW": (left, top + gap, right, top + gap + 28),
            "PWM_GREEN": (left, top + 2 * gap, right, top + 2 * gap + 28),
        }
        button_center = (max(right + 90, width - 92), 105)
        button_radius = max(46, min(62, int(width * 0.085)))
        return sliders, button_center, button_radius

    @staticmethod
    def _inside_rect(point: tuple[int, int], rect, margin: int = 13) -> bool:
        x, y = point
        x1, y1, x2, y2 = rect
        return x1 - margin <= x <= x2 + margin and y1 - margin <= y <= y2 + margin

    @staticmethod
    def _inside_circle(point: tuple[int, int], center, radius: int) -> bool:
        return math.hypot(point[0] - center[0], point[1] - center[1]) <= radius

    @staticmethod
    def _pointer(observation: HandObservation, width: int, height: int) -> tuple[int, int]:
        tip = observation.landmarks[8]
        return int(tip.x * width), int(tip.y * height)

    def update(
        self,
        left_hand: HandObservation | None,
        right_hand: HandObservation | None,
        frame_shape,
    ) -> list[TouchCommand]:
        height, width = frame_shape[:2]
        sliders, button_center, button_radius = self._layout(width, height)
        commands: list[TouchCommand] = []

        if left_hand is None:
            self.left_pointer = None
            self.left_state = "NORMAL"
            self.dragging = None
            self._left_pinched = False
        else:
            self.left_pointer = self._pointer(left_hand, width, height)
            pinched = _distance(left_hand.landmarks[8], left_hand.landmarks[4]) <= self.pinch_threshold
            pinch_started = pinched and not self._left_pinched
            pinch_released = not pinched and self._left_pinched
            hovered = next(
                (name for name, rect in sliders.items()
                 if self._inside_rect(self.left_pointer, rect)),
                None,
            )
            self.left_state = "PRESSED" if pinched else ("HOVER" if hovered else "NORMAL")
            if pinch_started and hovered:
                self.dragging = hovered
            if pinched and self.dragging:
                x1, _, x2, _ = sliders[self.dragging]
                ratio = max(0.0, min(1.0, (self.left_pointer[0] - x1) / max(1, x2 - x1)))
                value = int(round(ratio * 100))
                self.values[self.dragging] = value
                now = time.monotonic()
                previous = self._last_published[self.dragging]
                if (abs(value - previous) >= self.deadband and
                        now - self._last_publish_at >= self.publish_interval):
                    self._last_published[self.dragging] = value
                    self._last_publish_at = now
                    commands.append(TouchCommand(self.dragging, value, "LEFT_PINCH"))
            if pinch_released:
                self.dragging = None
            self._left_pinched = pinched

        if right_hand is None:
            self.right_pointer = None
            self.right_state = "NORMAL"
            self._button_contact = False
        else:
            self.right_pointer = self._pointer(right_hand, width, height)
            contact = self._inside_circle(
                self.right_pointer, button_center, button_radius
            )
            self.right_state = "TOUCH" if contact else "NORMAL"
            # Toggle hanya pada transisi dari luar ke dalam tombol. Pengguna
            # harus menjauhkan telunjuk sebelum dapat menekan sekali lagi.
            if contact and not self._button_contact:
                self.relay_requested = not self.relay_requested
                commands.append(
                    TouchCommand("RELAY", self.relay_requested, "RIGHT_TOUCH")
                )
            self._button_contact = contact

        return commands

    def set_actual(self, payload: dict[str, Any]) -> None:
        pwm = payload.get("pwm", {})
        if isinstance(pwm, dict):
            for key, source in (
                ("PWM_RED", "red"),
                ("PWM_YELLOW", "yellow"),
                ("PWM_GREEN", "green"),
            ):
                if source in pwm:
                    self.actual[key] = max(0, min(100, int(pwm[source])))
        if "relay" in payload:
            self.actual["RELAY"] = bool(payload["relay"])

    def draw(self, frame) -> None:
        height, width = frame.shape[:2]
        sliders, button_center, button_radius = self._layout(width, height)
        colors = {
            "PWM_RED": (55, 65, 235),
            "PWM_YELLOW": (20, 205, 245),
            "PWM_GREEN": (70, 205, 75),
        }
        labels = {
            "PWM_RED": "RED",
            "PWM_YELLOW": "YELLOW",
            "PWM_GREEN": "GREEN",
        }

        cv2.putText(
            frame, "LEFT HAND - PINCH & DRAG", (24, 35),
            cv2.FONT_HERSHEY_SIMPLEX, 0.44, (255, 255, 255), 1, cv2.LINE_AA,
        )
        for name, rect in sliders.items():
            x1, y1, x2, y2 = rect
            cv2.rectangle(frame, (x1, y1), (x2, y2), (42, 48, 56), -1)
            fill = x1 + int((x2 - x1) * self.values[name] / 100)
            cv2.rectangle(frame, (x1, y1), (fill, y2), colors[name], -1)
            border = (255, 255, 255) if self.dragging == name else (135, 145, 155)
            cv2.rectangle(frame, (x1, y1), (x2, y2), border, 1)
            cv2.putText(
                frame, f"{labels[name]} {self.values[name]}%", (x1 + 6, y1 + 19),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1,
                cv2.LINE_AA,
            )

        requested_color = (45, 190, 75) if self.relay_requested else (55, 55, 225)
        cv2.circle(frame, button_center, button_radius, requested_color, -1, cv2.LINE_AA)
        border = (255, 255, 255) if self.right_state == "TOUCH" else (190, 195, 205)
        cv2.circle(frame, button_center, button_radius, border, 3, cv2.LINE_AA)
        state = "ON" if self.relay_requested else "OFF"
        label_size = cv2.getTextSize(
            state, cv2.FONT_HERSHEY_SIMPLEX, 0.70, 2
        )[0]
        cv2.putText(
            frame, state,
            (button_center[0] - label_size[0] // 2,
             button_center[1] + label_size[1] // 2),
            cv2.FONT_HERSHEY_SIMPLEX, 0.70, (255, 255, 255), 2,
            cv2.LINE_AA,
        )
        cv2.putText(
            frame, "RIGHT HAND - TOUCH", (button_center[0] - button_radius - 9, 27),
            cv2.FONT_HERSHEY_SIMPLEX, 0.40, (255, 255, 255), 1,
            cv2.LINE_AA,
        )

        if self.left_pointer is not None:
            left_color = (70, 255, 110) if self.left_state == "PRESSED" else (0, 220, 255)
            cv2.circle(frame, self.left_pointer, 10, left_color, 2, cv2.LINE_AA)
        if self.right_pointer is not None:
            right_color = (70, 255, 110) if self.right_state == "TOUCH" else (255, 255, 255)
            cv2.circle(frame, self.right_pointer, 10, right_color, 2, cv2.LINE_AA)
