from __future__ import annotations

import argparse
import json
import re
import time
from pathlib import Path
from typing import Any

import cv2

from gesture_detector import GestureDetectorLite, HandObservation, HandPose
from mqtt_runtime import MqttRuntime
from state_filter import StableCommand
from virtual_touch import VirtualTouchController


PROJECT_DIR = Path(__file__).resolve().parent
VALID_CONTROL_MODES = {
    "RIGHT_TRAFFIC_LEFT_BUZZER": ("RIGHT", "LEFT"),
    "LEFT_TRAFFIC_RIGHT_BUZZER": ("LEFT", "RIGHT"),
}
VALID_HAND_MODES = {"RIGHT", "LEFT", "BOTH"}
VALID_APP_MODES = {"MEDIA_PLAYER", "SNAKE_GAME"}


def load_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Config tidak ditemukan: {path}")
    config = json.loads(path.read_text(encoding="utf-8"))
    group_id = str(config.get("identity", {}).get("group_id", "")).strip()
    if not group_id or not re.fullmatch(r"[A-Za-z0-9_-]+", group_id):
        raise ValueError("identity.group_id wajib diisi dan hanya boleh berisi huruf, angka, _ atau -")
    hand_mode = str(config.get("hand_tracking", {}).get("hand_mode", "RIGHT")).upper()
    if hand_mode not in VALID_HAND_MODES:
        raise ValueError("hand_tracking.hand_mode harus RIGHT, LEFT, atau BOTH")
    control_mode = str(config.get("node1", {}).get("control_mode", "RIGHT_TRAFFIC_LEFT_BUZZER"))
    if control_mode not in VALID_CONTROL_MODES:
        raise ValueError(f"node1.control_mode harus salah satu: {', '.join(VALID_CONTROL_MODES)}")
    return config


def traffic_command(pose: HandPose | None) -> str | None:
    if pose is None:
        return None
    return {
        "FINGERS_1": "RED", "FINGERS_2": "YELLOW", "FINGERS_3": "GREEN",
        "FIST": "OFF", "THUMB_UP": "BLINK",
    }.get(pose.label)


def buzzer_command(pose: HandPose | None) -> str | None:
    if pose is None:
        return None
    return {"OPEN_PALM": "BLINK", "FIST": "OFF"}.get(pose.label)


class ActiveHandLock:
    def __init__(self, mode: str, release_frames: int = 8) -> None:
        self.mode = mode
        self.release_frames = release_frames
        self.side: str | None = None
        self.missing = 0

    def select(self, observations: dict[str, HandObservation]) -> HandObservation | None:
        if self.mode in ("RIGHT", "LEFT"):
            return observations.get(self.mode)
        if self.side and self.side in observations:
            self.missing = 0
            return observations[self.side]
        if self.side:
            self.missing += 1
            if self.missing < self.release_frames:
                return None
        self.side = "RIGHT" if "RIGHT" in observations else ("LEFT" if "LEFT" in observations else None)
        self.missing = 0
        return observations.get(self.side) if self.side else None


def draw_status_footer(frame, mqtt_connected: bool, group_id: str, node_id: str,
                       fps: float, gesture: str, mode_text: str):
    """Tambahkan footer di luar area kamera agar tidak menutupi gambar."""
    height, width = frame.shape[:2]
    footer_height = 26
    canvas = cv2.copyMakeBorder(
        frame, 0, footer_height, 0, 0, cv2.BORDER_CONSTANT,
        value=(16, 21, 28),
    )
    status = "MQTT ON" if mqtt_connected else "MQTT OFF"
    status_color = (70, 230, 120) if mqtt_connected else (80, 90, 240)
    base = f"{status} | {group_id}/{node_id} | FPS {fps:.1f} | {mode_text}"
    cv2.putText(
        canvas, base, (7, height + 18), cv2.FONT_HERSHEY_SIMPLEX,
        0.35, status_color, 1, cv2.LINE_AA,
    )
    gesture_text = f"GESTURE: {gesture or 'IDLE'}"
    text_width = cv2.getTextSize(
        gesture_text, cv2.FONT_HERSHEY_SIMPLEX, 0.35, 1
    )[0][0]
    cv2.putText(
        canvas, gesture_text, (max(7, width - text_width - 7), height + 18),
        cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 255, 255), 1,
        cv2.LINE_AA,
    )
    return canvas


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="MediaPipe Gesture multi-node MQTT")
    parser.add_argument("--node", type=int, choices=(1, 2, 3), default=1)
    parser.add_argument("--config", type=Path, default=PROJECT_DIR / "config.json")
    parser.add_argument("--no-mqtt", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config.resolve())
    if args.no_mqtt:
        config["mqtt"]["enabled"] = False
    node_id = f"node_{args.node:02d}"
    group_id = str(config["identity"]["group_id"])
    camera, tracking, detection = config["camera"], config["hand_tracking"], config["detection"]
    hand_lock = ActiveHandLock(str(tracking.get("hand_mode", "RIGHT")).upper())
    touch = VirtualTouchController(config.get("node2", {}))
    app_mode = str(config.get("node3", {}).get("default_app_mode", "MEDIA_PLAYER"))
    if app_mode not in VALID_APP_MODES:
        app_mode = "MEDIA_PLAYER"

    def on_mqtt_message(topic: str, payload: dict[str, Any]) -> None:
        nonlocal app_mode
        if topic.endswith("/device/status") and args.node == 2:
            touch.set_actual(payload)
        elif topic.endswith("/control") and args.node == 3:
            requested = str(payload.get("app_mode", "")).upper()
            if requested in VALID_APP_MODES:
                app_mode = requested
                print(f"[NODE 3] Active app: {app_mode}")

    mqtt = MqttRuntime(group_id, node_id, config["mqtt"], on_mqtt_message)
    mqtt.start()
    detector = GestureDetectorLite(
        min_detection_confidence=float(detection.get("min_detection_confidence", 0.6)),
        min_tracking_confidence=float(detection.get("min_tracking_confidence", 0.6)),
        extended_angle=float(detection.get("extended_angle", 155.0)),
        max_num_hands=int(tracking.get("max_num_hands", 2)),
    )
    backend = cv2.CAP_DSHOW if hasattr(cv2, "CAP_DSHOW") else cv2.CAP_ANY
    capture = cv2.VideoCapture(int(camera.get("index", 0)), backend)
    capture.set(cv2.CAP_PROP_FRAME_WIDTH, int(camera.get("width", 640)))
    capture.set(cv2.CAP_PROP_FRAME_HEIGHT, int(camera.get("height", 480)))
    capture.set(cv2.CAP_PROP_FPS, int(camera.get("target_fps", 20)))
    capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    if not capture.isOpened():
        detector.close(); mqtt.stop()
        raise RuntimeError("Webcam tidak dapat dibuka; ubah camera.index pada config.json")

    confirm_frames = int(detection.get("confirm_frames", 4))
    traffic_filter, buzzer_filter = StableCommand(confirm_frames), StableCommand(confirm_frames)
    node3_confirm = int(config.get("node3", {}).get("confirm_frames", confirm_frames))
    node3_media_filter = StableCommand(node3_confirm)
    node3_left_filter = StableCommand(node3_confirm)
    node3_right_filter = StableCommand(node3_confirm)
    traffic_hand, buzzer_hand = VALID_CONTROL_MODES[config["node1"]["control_mode"]]
    previous_time, smoothed_fps = time.perf_counter(), 0.0
    last_command = last_gesture = "IDLE"
    last_traffic = last_buzzer = None
    last_heartbeat = 0.0
    node3_media_neutral = node3_left_neutral = node3_right_neutral = 0
    print(f"[SYSTEM] Group={group_id} Node={node_id} Mode={args.node}")
    print("[CAMERA] Tekan Q atau ESC untuk keluar")

    try:
        while True:
            ok, frame = capture.read()
            if not ok:
                continue
            mirror = bool(camera.get("mirror", True))
            if mirror:
                frame = cv2.flip(frame, 1)
            result, observations = detector.process(frame, swap_handedness=not mirror)
            if args.node == 1:
                traffic_obs, buzzer_obs = observations.get(traffic_hand), observations.get(buzzer_hand)
                raw_traffic = traffic_command(traffic_obs.pose if traffic_obs else None)
                raw_buzzer = buzzer_command(buzzer_obs.pose if buzzer_obs else None)
                stable_traffic, _ = traffic_filter.update(raw_traffic)
                stable_buzzer, _ = buzzer_filter.update(raw_buzzer)
                last_gesture = "/".join(value for value in (
                    traffic_obs.pose.label if traffic_obs and traffic_obs.pose.label != "IDLE" else "",
                    buzzer_obs.pose.label if buzzer_obs and buzzer_obs.pose.label != "IDLE" else "",
                ) if value) or "IDLE"
                if stable_traffic and stable_traffic != last_traffic:
                    if mqtt.publish_command("TRAFFIC", stable_traffic, last_gesture):
                        last_traffic, last_command = stable_traffic, f"TRAFFIC={stable_traffic}"
                if stable_buzzer and stable_buzzer != last_buzzer:
                    if mqtt.publish_command("BUZZER", stable_buzzer, last_gesture):
                        last_buzzer, last_command = stable_buzzer, f"BUZZER={stable_buzzer}"
                mode_text = "TRAFFIC + BUZZER"
            elif args.node == 2:
                left_hand = observations.get("LEFT")
                right_hand = observations.get("RIGHT")
                last_gesture = "/".join(value for value in (
                    f"LEFT:{left_hand.pose.label}" if left_hand and left_hand.pose.label != "IDLE" else "",
                    f"RIGHT:{right_hand.pose.label}" if right_hand and right_hand.pose.label != "IDLE" else "",
                ) if value) or "IDLE"
                for command in touch.update(left_hand, right_hand, frame.shape):
                    if mqtt.publish_command(command.device, command.value, command.gesture):
                        last_command = f"{command.device}={command.value}"
                mode_text = "VIRTUAL TOUCH"
            else:
                left = observations.get("LEFT")
                right = observations.get("RIGHT")
                left_label = left.pose.label if left else "IDLE"
                right_label = right.pose.label if right else "IDLE"
                active_labels = [
                    f"LEFT:{left_label}" if left_label != "IDLE" else "",
                    f"RIGHT:{right_label}" if right_label != "IDLE" else "",
                ]
                last_gesture = "/".join(x for x in active_labels if x) or "IDLE"
                pending_events: list[tuple[str, str]] = []

                if app_mode == "MEDIA_PLAYER":
                    media_map = {
                        "OPEN_PALM": ("OPEN_PALM", "PLAY"),
                        "FIST": ("FIST", "PAUSE"),
                        "FINGERS_1": ("FINGERS_1", "PREVIOUS"),
                        "FINGERS_2": ("FINGERS_2", "MUTE_TOGGLE"),
                        "FINGERS_3": ("FINGERS_3", "NEXT"),
                    }
                    # Prioritaskan gesture valid tangan kanan; bila tangan kanan
                    # IDLE, gesture valid tangan kiri tetap dapat digunakan.
                    label = right_label if right_label in media_map else left_label
                    raw = media_map.get(label)
                    if raw is None:
                        node3_media_neutral += 1
                        if node3_media_neutral >= 3:
                            node3_media_filter.reset()
                    else:
                        node3_media_neutral = 0
                    stable, changed = node3_media_filter.update(raw[0] if raw else None)
                    if changed and stable:
                        pending_events.append((stable, media_map[stable][1]))
                else:
                    left_map = {
                        "OPEN_PALM": ("LEFT_OPEN_PALM", "START_RESUME"),
                        "FIST": ("LEFT_FIST", "PAUSE"),
                        "THUMB_UP": ("LEFT_THUMB_UP", "RESTART"),
                    }
                    right_map = {
                        "FINGERS_1": ("RIGHT_FINGERS_1", "MOVE_UP"),
                        "FINGERS_2": ("RIGHT_FINGERS_2", "MOVE_RIGHT"),
                        "FINGERS_3": ("RIGHT_FINGERS_3", "MOVE_DOWN"),
                        "OPEN_PALM": ("RIGHT_OPEN_PALM", "MOVE_LEFT"),
                    }
                    raw_left = left_map.get(left_label)
                    raw_right = right_map.get(right_label)
                    if raw_left is None:
                        node3_left_neutral += 1
                        if node3_left_neutral >= 3:
                            node3_left_filter.reset()
                    else:
                        node3_left_neutral = 0
                    if raw_right is None:
                        node3_right_neutral += 1
                        if node3_right_neutral >= 3:
                            node3_right_filter.reset()
                    else:
                        node3_right_neutral = 0
                    stable_left, changed_left = node3_left_filter.update(
                        raw_left[0] if raw_left else None
                    )
                    stable_right, changed_right = node3_right_filter.update(
                        raw_right[0] if raw_right else None
                    )
                    # Kedua tangan boleh memberi perintah pada frame yang sama,
                    # misalnya tangan kiri START dan tangan kanan memilih arah.
                    if changed_left and stable_left:
                        pending_events.append((stable_left, left_map[left_label][1]))
                    if changed_right and stable_right:
                        pending_events.append((stable_right, right_map[right_label][1]))

                for event, action in pending_events:
                    if mqtt.publish_event(event, action, app_mode):
                        last_command = action
                mode_text = app_mode

            detector.draw(frame, result, observations, swap_handedness=not mirror)
            if args.node == 2:
                touch.draw(frame)
            now = time.perf_counter()
            instant_fps = 1.0 / max(now - previous_time, 1e-6)
            previous_time = now
            smoothed_fps = instant_fps if smoothed_fps == 0 else 0.9 * smoothed_fps + 0.1 * instant_fps
            frame = draw_status_footer(
                frame, mqtt.connected(), group_id, node_id, smoothed_fps,
                last_gesture, mode_text,
            )
            if now - last_heartbeat >= mqtt.heartbeat_seconds:
                mqtt.publish_status(args.node, last_gesture, last_command)
                last_heartbeat = now
            cv2.imshow(f"MediaPipe Gesture | {group_id} | {node_id}", frame)
            if cv2.waitKey(1) & 0xFF in (ord("q"), ord("Q"), 27):
                break
    except KeyboardInterrupt:
        pass
    finally:
        capture.release(); detector.close(); mqtt.stop(); cv2.destroyAllWindows()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
