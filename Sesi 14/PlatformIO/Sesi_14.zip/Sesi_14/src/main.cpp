#include <Arduino.h>
#include <ArduinoJson.h>
#include <esp_arduino_version.h>
#include <esp_system.h>

#include "app_config.h"
#include "mqtt_manager.h"
#include "wifi_manager.h"

namespace {
enum class TrafficState : uint8_t { OFF, RED, YELLOW, GREEN, BLINK };
enum class BuzzerState : uint8_t { OFF, BLINK };

char commandTopic[128] = {};
char statusTopic[128] = {};
char clientId[96] = {};
String lastCommandId;

TrafficState trafficState = TrafficState::OFF;
BuzzerState buzzerState = BuzzerState::OFF;
bool trafficBlinkLevel = false;
bool buzzerBlinkLevel = false;
uint32_t lastTrafficBlinkMs = 0;
uint32_t lastBuzzerBlinkMs = 0;

uint8_t pwmRed = 0;
uint8_t pwmYellow = 0;
uint8_t pwmGreen = 0;
bool relayState = false;

bool statusPending = true;
bool mqttWasConnected = false;
uint32_t lastStatusMs = 0;

WifiManager wifiManager(AppConfig::WIFI_SSID,
                        AppConfig::WIFI_PASSWORD,
                        AppConfig::WIFI_RECONNECT_INTERVAL_MS,
                        AppConfig::WIFI_CONNECT_TIMEOUT_MS);

MqttManager mqttManager(AppConfig::MQTT_HOST,
                        AppConfig::MQTT_PORT,
                        commandTopic,
                        AppConfig::MQTT_USERNAME,
                        AppConfig::MQTT_PASSWORD,
                        AppConfig::MQTT_RECONNECT_INTERVAL_MS,
                        AppConfig::MQTT_CONNECT_TIMEOUT_MS);

uint8_t activeLevel(bool active, bool activeHigh) {
  return active == activeHigh ? HIGH : LOW;
}

void setBuzzer(bool active) {
  digitalWrite(AppConfig::BUZZER_PIN,
               activeLevel(active, AppConfig::BUZZER_ACTIVE_HIGH));
}

void setLeds(bool red, bool yellow, bool green) {
  digitalWrite(AppConfig::LED_RED_PIN,
               activeLevel(red, AppConfig::LED_ACTIVE_HIGH));
  digitalWrite(AppConfig::LED_YELLOW_PIN,
               activeLevel(yellow, AppConfig::LED_ACTIVE_HIGH));
  digitalWrite(AppConfig::LED_GREEN_PIN,
               activeLevel(green, AppConfig::LED_ACTIVE_HIGH));
}

const char* trafficStateText() {
  switch (trafficState) {
    case TrafficState::RED: return "RED";
    case TrafficState::YELLOW: return "YELLOW";
    case TrafficState::GREEN: return "GREEN";
    case TrafficState::BLINK: return "BLINK";
    default: return "OFF";
  }
}

const char* buzzerStateText() {
  return buzzerState == BuzzerState::BLINK ? "BLINK" : "OFF";
}

void applyTrafficState(TrafficState next) {
  if (trafficState == next) return;
  trafficState = next;
  trafficBlinkLevel = false;
  lastTrafficBlinkMs = millis();
  switch (trafficState) {
    case TrafficState::RED: setLeds(true, false, false); break;
    case TrafficState::YELLOW: setLeds(false, true, false); break;
    case TrafficState::GREEN: setLeds(false, false, true); break;
    case TrafficState::BLINK:
      trafficBlinkLevel = true;
      setLeds(true, true, true);
      break;
    default: setLeds(false, false, false); break;
  }
  statusPending = true;
}

void applyBuzzerState(BuzzerState next) {
  if (buzzerState == next) return;
  buzzerState = next;
  buzzerBlinkLevel = next == BuzzerState::BLINK;
  lastBuzzerBlinkMs = millis();
  setBuzzer(buzzerBlinkLevel);
  statusPending = true;
}

bool parseTrafficCommand(const String& command, TrafficState& result) {
  if (command == "RED") result = TrafficState::RED;
  else if (command == "YELLOW") result = TrafficState::YELLOW;
  else if (command == "GREEN") result = TrafficState::GREEN;
  else if (command == "BLINK") result = TrafficState::BLINK;
  else if (command == "OFF") result = TrafficState::OFF;
  else return false;
  return true;
}

uint32_t percentToDuty(uint8_t percent) {
  const uint32_t maximum = (1UL << AppConfig::PWM_RESOLUTION_BITS) - 1UL;
  return (static_cast<uint32_t>(percent) * maximum + 50UL) / 100UL;
}

void setupPwmPin(uint8_t pin, uint8_t channel) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  (void)channel;
  ledcAttach(pin, AppConfig::PWM_FREQUENCY_HZ,
             AppConfig::PWM_RESOLUTION_BITS);
#else
  ledcSetup(channel, AppConfig::PWM_FREQUENCY_HZ,
            AppConfig::PWM_RESOLUTION_BITS);
  ledcAttachPin(pin, channel);
#endif
}

void writePwm(uint8_t pin, uint8_t channel, uint8_t percent) {
  const uint32_t duty = percentToDuty(percent);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  (void)channel;
  ledcWrite(pin, duty);
#else
  (void)pin;
  ledcWrite(channel, duty);
#endif
}

void applyPwm(const String& device, uint8_t value) {
  if (device == "PWM_RED") {
    pwmRed = value;
    writePwm(AppConfig::LED_RED_PIN, AppConfig::PWM_RED_CHANNEL, value);
  } else if (device == "PWM_YELLOW") {
    pwmYellow = value;
    writePwm(AppConfig::LED_YELLOW_PIN, AppConfig::PWM_YELLOW_CHANNEL, value);
  } else if (device == "PWM_GREEN") {
    pwmGreen = value;
    writePwm(AppConfig::LED_GREEN_PIN, AppConfig::PWM_GREEN_CHANNEL, value);
  } else {
    return;
  }
  statusPending = true;
}

void handleMqttMessage(const char* topic, const char* payload) {
  if (String(topic) != commandTopic) return;
  JsonDocument document;
  if (deserializeJson(document, payload)) return;

  const String groupId = static_cast<const char*>(document["group_id"] | "");
  const String nodeId = static_cast<const char*>(document["node_id"] | "");
  const String commandId = static_cast<const char*>(document["command_id"] | "");
  if (groupId != AppConfig::GROUP_ID || nodeId != AppConfig::NODE_ID ||
      commandId.length() == 0 || commandId == lastCommandId) {
    return;
  }
  lastCommandId = commandId;
  String device = static_cast<const char*>(document["device"] | "");
  device.toUpperCase();

  if (AppConfig::DEVICE_MODE == 1) {
    String value = static_cast<const char*>(document["value"] | "");
    value.toUpperCase();
    if (device == "TRAFFIC") {
      TrafficState next;
      if (parseTrafficCommand(value, next)) applyTrafficState(next);
    } else if (device == "BUZZER") {
      applyBuzzerState(value == "BLINK" || value == "ON"
                           ? BuzzerState::BLINK
                           : BuzzerState::OFF);
    }
  } else {
    if (device == "PWM_RED" || device == "PWM_YELLOW" ||
        device == "PWM_GREEN") {
      applyPwm(device, static_cast<uint8_t>(
                           constrain(document["value"].as<int>(), 0, 100)));
    } else if (device == "RELAY") {
      relayState = document["value"].as<bool>();
      digitalWrite(AppConfig::RELAY_PIN,
                   activeLevel(relayState, AppConfig::RELAY_ACTIVE_HIGH));
      statusPending = true;
    }
  }
}

void updateOutputs() {
  if (AppConfig::DEVICE_MODE != 1) return;
  const uint32_t now = millis();
  if (trafficState == TrafficState::BLINK &&
      now - lastTrafficBlinkMs >= AppConfig::LED_BLINK_INTERVAL_MS) {
    lastTrafficBlinkMs = now;
    trafficBlinkLevel = !trafficBlinkLevel;
    setLeds(trafficBlinkLevel, trafficBlinkLevel, trafficBlinkLevel);
  }
  if (buzzerState == BuzzerState::BLINK &&
      now - lastBuzzerBlinkMs >= AppConfig::BUZZER_BLINK_INTERVAL_MS) {
    lastBuzzerBlinkMs = now;
    buzzerBlinkLevel = !buzzerBlinkLevel;
    setBuzzer(buzzerBlinkLevel);
  }
}

void publishStatus() {
  const bool connected = mqttManager.connected();
  if (connected && !mqttWasConnected) statusPending = true;
  mqttWasConnected = connected;
  const uint32_t now = millis();
  if (!connected ||
      (!statusPending &&
       now - lastStatusMs < AppConfig::STATUS_HEARTBEAT_MS)) {
    return;
  }

  JsonDocument document;
  document["group_id"] = AppConfig::GROUP_ID;
  document["node_id"] = AppConfig::NODE_ID;
  document["online"] = true;
  document["uptime_ms"] = now;
  document["rssi"] = WiFi.RSSI();
  if (AppConfig::DEVICE_MODE == 1) {
    document["traffic"] = trafficStateText();
    document["buzzer"] = buzzerStateText();
  } else {
    JsonObject pwm = document["pwm"].to<JsonObject>();
    pwm["red"] = pwmRed;
    pwm["yellow"] = pwmYellow;
    pwm["green"] = pwmGreen;
    document["relay"] = relayState;
  }

  char payload[256] = {};
  serializeJson(document, payload, sizeof(payload));
  if (mqttManager.publish(statusTopic, payload, true)) {
    statusPending = false;
    lastStatusMs = now;
    Serial.printf("[MQTT] Status %s: %s\n", statusTopic, payload);
  }
}
}

void setup() {
  Serial.begin(115200);

  snprintf(commandTopic, sizeof(commandTopic), "%s/%s/%s/command",
           AppConfig::MQTT_TOPIC_PREFIX, AppConfig::GROUP_ID,
           AppConfig::NODE_ID);
  snprintf(statusTopic, sizeof(statusTopic), "%s/%s/%s/device/status",
           AppConfig::MQTT_TOPIC_PREFIX, AppConfig::GROUP_ID,
           AppConfig::NODE_ID);

  if (AppConfig::DEVICE_MODE == 1) {
    pinMode(AppConfig::LED_RED_PIN, OUTPUT);
    pinMode(AppConfig::LED_YELLOW_PIN, OUTPUT);
    pinMode(AppConfig::LED_GREEN_PIN, OUTPUT);
    pinMode(AppConfig::BUZZER_PIN, OUTPUT);
    setLeds(false, false, false);
    setBuzzer(false);
  } else {
    setupPwmPin(AppConfig::LED_RED_PIN, AppConfig::PWM_RED_CHANNEL);
    setupPwmPin(AppConfig::LED_YELLOW_PIN, AppConfig::PWM_YELLOW_CHANNEL);
    setupPwmPin(AppConfig::LED_GREEN_PIN, AppConfig::PWM_GREEN_CHANNEL);
    writePwm(AppConfig::LED_RED_PIN, AppConfig::PWM_RED_CHANNEL, 0);
    writePwm(AppConfig::LED_YELLOW_PIN, AppConfig::PWM_YELLOW_CHANNEL, 0);
    writePwm(AppConfig::LED_GREEN_PIN, AppConfig::PWM_GREEN_CHANNEL, 0);
    pinMode(AppConfig::RELAY_PIN, OUTPUT);
    digitalWrite(AppConfig::RELAY_PIN,
                 activeLevel(false, AppConfig::RELAY_ACTIVE_HIGH));
  }

  const uint64_t chipId = ESP.getEfuseMac();
  snprintf(clientId, sizeof(clientId), "GESTURE-%s-%s-%04X-%08lX",
           AppConfig::GROUP_ID, AppConfig::NODE_ID,
           static_cast<unsigned int>(chipId & 0xFFFFU),
           static_cast<unsigned long>(esp_random()));

  Serial.printf("[SYSTEM] Mode: %u\n", AppConfig::DEVICE_MODE);
  Serial.printf("[SYSTEM] Group/Node: %s/%s\n", AppConfig::GROUP_ID,
                AppConfig::NODE_ID);
  Serial.printf("[SYSTEM] Subscribe exact: %s\n", commandTopic);
  Serial.printf("[SYSTEM] Status: %s\n", statusTopic);

  mqttManager.setCallback(handleMqttMessage);
  mqttManager.begin(clientId);
  wifiManager.begin();
}

void loop() {
  wifiManager.loop();
  mqttManager.loop(wifiManager.connected());
  updateOutputs();
  publishStatus();
}
