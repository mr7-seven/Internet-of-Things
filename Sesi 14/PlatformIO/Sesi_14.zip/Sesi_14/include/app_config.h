#pragma once

#include <Arduino.h>

namespace AppConfig {
// APP_DEVICE_MODE ditentukan oleh environment node1/node2 pada platformio.ini.
#ifndef APP_DEVICE_MODE
#define APP_DEVICE_MODE 1
#endif
constexpr uint8_t DEVICE_MODE = APP_DEVICE_MODE;

constexpr char WIFI_SSID[] = "NAMA_WIFI";
constexpr char WIFI_PASSWORD[] = "PASSWORD_WIFI";

constexpr char MQTT_HOST[] = "broker.emqx.io";
constexpr uint16_t MQTT_PORT = 1883;
constexpr char MQTT_USERNAME[] = "";
constexpr char MQTT_PASSWORD[] = "";

// Harus sama dengan identity.group_id pada python/config.json dan function
// KONFIGURASI GROUP pada flow Node-RED.
constexpr char GROUP_ID[] = "group_01";
constexpr char MQTT_TOPIC_PREFIX[] = "gesture";
constexpr const char* NODE_ID = DEVICE_MODE == 1 ? "node_01" : "node_02";

static_assert(DEVICE_MODE == 1 || DEVICE_MODE == 2,
              "DEVICE_MODE hanya boleh bernilai 1 atau 2");

constexpr uint32_t WIFI_RECONNECT_INTERVAL_MS = 5000;
constexpr uint32_t WIFI_CONNECT_TIMEOUT_MS = 15000;
constexpr uint32_t MQTT_RECONNECT_INTERVAL_MS = 5000;
constexpr uint32_t MQTT_CONNECT_TIMEOUT_MS = 10000;
constexpr uint32_t STATUS_HEARTBEAT_MS = 10000;

// Pin Node 1 dipertahankan dari firmware gesture asli yang telah diuji.
constexpr uint8_t LED_RED_PIN = 25;
constexpr uint8_t LED_YELLOW_PIN = 26;
constexpr uint8_t LED_GREEN_PIN = 27;
constexpr uint8_t BUZZER_PIN = 33;
constexpr bool LED_ACTIVE_HIGH = true;
constexpr bool BUZZER_ACTIVE_HIGH = true;
constexpr uint32_t LED_BLINK_INTERVAL_MS = 400;
constexpr uint32_t BUZZER_BLINK_INTERVAL_MS = 250;

// Konfigurasi khusus Node 2.
constexpr uint8_t RELAY_PIN = 5;
// true: relay ON saat pin HIGH, false: relay ON saat pin LOW.
constexpr bool RELAY_ACTIVE_HIGH = false;
constexpr uint32_t PWM_FREQUENCY_HZ = 5000;
constexpr uint8_t PWM_RESOLUTION_BITS = 8;
constexpr uint8_t PWM_RED_CHANNEL = 0;
constexpr uint8_t PWM_YELLOW_CHANNEL = 1;
constexpr uint8_t PWM_GREEN_CHANNEL = 2;
}

