#pragma once

#include <Arduino.h>

namespace AppConfig {
constexpr char WIFI_SSID[] = "GANTI_NAMA_WIFI";
constexpr char WIFI_PASSWORD[] = "GANTI_PASSWORD_WIFI";

constexpr char MQTT_HOST[] = "broker.emqx.io";
constexpr uint16_t MQTT_PORT = 1883;
constexpr char MQTT_USERNAME[] = "";
constexpr char MQTT_PASSWORD[] = "";

constexpr char GROUP_ID[] = "kelompok-00";
constexpr char NODE_ID[] = "toll-node-00";
constexpr char MQTT_TOPIC_ROOT[] = "toll";

constexpr uint8_t RFID_SS_PIN = 5;
constexpr uint8_t RFID_RST_PIN = 21;
constexpr uint8_t RFID_SCK_PIN = 18;
constexpr uint8_t RFID_MISO_PIN = 19;
constexpr uint8_t RFID_MOSI_PIN = 23;

constexpr uint8_t LED_RED_PIN = 25;
constexpr uint8_t LED_YELLOW_PIN = 26;
constexpr uint8_t LED_GREEN_PIN = 27;
constexpr uint8_t BUZZER_PIN = 32;
constexpr uint8_t BUTTON_PIN = 33;

constexpr bool BUTTON_ACTIVE_LOW = true;
constexpr bool BUZZER_ACTIVE_HIGH = true;
constexpr uint32_t BUTTON_DEBOUNCE_MS = 40;
constexpr uint32_t BUTTON_LONG_PRESS_MS = 3000;
constexpr uint32_t RFID_SCAN_COOLDOWN_MS = 2000;
constexpr uint32_t RESPONSE_TIMEOUT_MS = 15000;
constexpr uint32_t PAID_DURATION_MS = 10000;
constexpr uint32_t DENIED_DURATION_MS = 1800;

constexpr uint32_t WIFI_RECONNECT_INTERVAL_MS = 3000;
constexpr uint32_t WIFI_CONNECT_TIMEOUT_MS = 10000;
constexpr uint32_t MQTT_RECONNECT_INTERVAL_MS = 5000;
constexpr uint32_t MQTT_CONNECT_TIMEOUT_MS = 10000;
}
