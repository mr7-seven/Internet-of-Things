#include <Arduino.h>
#include <ArduinoJson.h>
#include <SPI.h>
#include <MFRC522v2.h>
#include <MFRC522DriverSPI.h>
#include <MFRC522DriverPinSimple.h>
#include <esp_system.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <cstring>

#include "app_config.h"
#include "mqtt_manager.h"
#include "wifi_manager.h"

namespace {
enum class ReaderMode : uint8_t {
  PAYMENT,
  REGISTRATION
};

enum class AccessState : uint8_t {
  STANDBY,
  WAITING,
  PAID,
  DENIED
};

char eventTopic[128] = {};
char commandTopic[128] = {};
char statusTopic[128] = {};
char clientId[128] = {};
char activeEventId[96] = {};
char completionResult[16] = {};

uint32_t bootId = 0;
uint32_t eventCounter = 0;
uint32_t lastScanMs = 0;
uint32_t stateStartedMs = 0;
uint32_t lastFeedbackMs = 0;

bool readerReady = false;
bool mqttWasConnected = false;
bool completionPending = false;

ReaderMode readerMode = ReaderMode::PAYMENT;
AccessState accessState = AccessState::STANDBY;

WifiManager wifiManager(
    AppConfig::WIFI_SSID,
    AppConfig::WIFI_PASSWORD,
    AppConfig::WIFI_RECONNECT_INTERVAL_MS,
    AppConfig::WIFI_CONNECT_TIMEOUT_MS);

MqttManager mqttManager(
    AppConfig::MQTT_HOST,
    AppConfig::MQTT_PORT,
    commandTopic,
    AppConfig::MQTT_USERNAME,
    AppConfig::MQTT_PASSWORD,
    AppConfig::MQTT_RECONNECT_INTERVAL_MS,
    AppConfig::MQTT_CONNECT_TIMEOUT_MS);

// MFRC522v2 menggunakan objek driver SPI terpisah.
MFRC522DriverPinSimple rfidSelect(AppConfig::RFID_SS_PIN);
MFRC522DriverSPI rfidDriver(
    rfidSelect,
    SPI,
    SPISettings(1000000, MSBFIRST, SPI_MODE0));
MFRC522 rfid(rfidDriver);

struct IncomingCommand {
  char eventId[96];
  char result[16];
  char reason[128];
};

QueueHandle_t commandQueue = nullptr;

struct {
  bool rawPressed = false;
  bool stablePressed = false;
  bool longHandled = false;
  uint32_t changedMs = 0;
  uint32_t pressedMs = 0;
} button;

struct {
  bool active = false;
  bool on = false;
  uint8_t remaining = 0;
  uint16_t onMs = 120;
  uint16_t offMs = 120;
  uint32_t changedMs = 0;
} beeper;

bool buttonPressed() {
  const bool high = digitalRead(AppConfig::BUTTON_PIN) == HIGH;
  return AppConfig::BUTTON_ACTIVE_LOW ? !high : high;
}

void writeBuzzer(bool on) {
  const bool high = AppConfig::BUZZER_ACTIVE_HIGH ? on : !on;
  digitalWrite(AppConfig::BUZZER_PIN, high ? HIGH : LOW);
}

void beep(uint8_t count, uint16_t onMs = 120, uint16_t offMs = 120) {
  if (!count) return;
  beeper.active = true;
  beeper.on = true;
  beeper.remaining = count;
  beeper.onMs = onMs;
  beeper.offMs = offMs;
  beeper.changedMs = millis();
  writeBuzzer(true);
}

void updateBuzzer(uint32_t now) {
  if (!beeper.active) return;

  const uint32_t interval = beeper.on ? beeper.onMs : beeper.offMs;
  if (now - beeper.changedMs < interval) return;

  beeper.changedMs = now;
  if (beeper.on) {
    writeBuzzer(false);
    beeper.on = false;
    if (--beeper.remaining == 0) beeper.active = false;
  } else {
    writeBuzzer(true);
    beeper.on = true;
  }
}

void setLeds(bool red, bool yellow, bool green) {
  digitalWrite(AppConfig::LED_RED_PIN, red ? HIGH : LOW);
  digitalWrite(AppConfig::LED_YELLOW_PIN, yellow ? HIGH : LOW);
  digitalWrite(AppConfig::LED_GREEN_PIN, green ? HIGH : LOW);
}

void standby() {
  accessState = AccessState::STANDBY;
  setLeds(false, true, false);
  Serial.printf("[STANDBY] Mode: %s\n",
                readerMode == ReaderMode::PAYMENT
                    ? "PAYMENT" : "REGISTER");
}

void changeMode(ReaderMode mode) {
  if (accessState != AccessState::STANDBY || completionPending) {
    Serial.println("[BUTTON] Tunggu transaksi selesai");
    return;
  }

  readerMode = mode;
  beep(1);
  Serial.printf("[MODE] %s\n",
                mode == ReaderMode::PAYMENT ? "PAYMENT" : "REGISTER");
}

void updateButton(uint32_t now) {
  const bool pressed = buttonPressed();

  if (pressed != button.rawPressed) {
    button.rawPressed = pressed;
    button.changedMs = now;
  }

  if (now - button.changedMs >= AppConfig::BUTTON_DEBOUNCE_MS &&
      button.stablePressed != button.rawPressed) {
    button.stablePressed = button.rawPressed;

    if (button.stablePressed) {
      button.pressedMs = now;
      button.longHandled = false;
    } else if (!button.longHandled) {
      changeMode(ReaderMode::PAYMENT);
    }
  }

  if (button.stablePressed && button.rawPressed &&
      !button.longHandled &&
      now - button.pressedMs >= AppConfig::BUTTON_LONG_PRESS_MS) {
    button.longHandled = true;
    changeMode(ReaderMode::REGISTRATION);
  }
}

bool publishJson(const char* topic, const JsonDocument& doc) {
  if (!mqttManager.connected()) return false;

  char payload[512] = {};
  if (doc.overflowed() || measureJson(doc) >= sizeof(payload)) {
    Serial.println("[MQTT] Payload terlalu besar");
    return false;
  }

  serializeJson(doc, payload, sizeof(payload));
  if (!mqttManager.publish(topic, payload)) return false;

  Serial.printf("[MQTT] TX %s: %s\n", topic, payload);
  return true;
}

bool publishStatus(const char* status, const char* result = "") {
  JsonDocument doc;
  doc["group_id"] = AppConfig::GROUP_ID;
  doc["node_id"] = AppConfig::NODE_ID;
  doc["event_id"] = activeEventId;
  doc["status"] = status;
  doc["result"] = result;
  doc["uptime_ms"] = millis();
  return publishJson(statusTopic, doc);
}

void sendCard(const char* uid) {
  if (!mqttManager.connected()) {
    Serial.println("[MQTT] Belum terhubung. Angkat dan tap ulang kartu.");
    return;
  }

  snprintf(activeEventId, sizeof(activeEventId), "%s-%08lX-%lu",
           AppConfig::NODE_ID,
           static_cast<unsigned long>(bootId),
           static_cast<unsigned long>(++eventCounter));

  const bool registration = readerMode == ReaderMode::REGISTRATION;
  JsonDocument doc;
  doc["group_id"] = AppConfig::GROUP_ID;
  doc["node_id"] = AppConfig::NODE_ID;
  doc["event_id"] = activeEventId;
  doc["uid"] = uid;
  doc["mode"] = registration ? "REGISTER" : "PAYMENT";
  doc["uptime_ms"] = millis();

  if (!registration) {
    accessState = AccessState::WAITING;
    stateStartedMs = millis();
  }

  if (!publishJson(eventTopic, doc)) {
    activeEventId[0] = '\0';
    standby();
    return;
  }

  if (registration) {
    Serial.println("[REGISTER] UID dikirim. Kembali ke mode PAYMENT.");
    readerMode = ReaderMode::PAYMENT;
    activeEventId[0] = '\0';
    standby();
  } else {
    Serial.println("[PAYMENT] Menunggu keputusan Node-RED...");
  }
}

void scanCard(uint32_t now) {
  if (!readerReady || completionPending ||
      accessState != AccessState::STANDBY ||
      now - lastScanMs < AppConfig::RFID_SCAN_COOLDOWN_MS) {
    return;
  }

  if (!rfid.PICC_IsNewCardPresent()) return;
  if (!rfid.PICC_ReadCardSerial()) return;

  char uid[32] = {};
  size_t position = 0;
  for (byte i = 0;
       i < rfid.uid.size && position + 2 < sizeof(uid);
       ++i) {
    snprintf(uid + position, sizeof(uid) - position,
             "%02X", rfid.uid.uidByte[i]);
    position += 2;
  }

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();

  lastScanMs = now;
  beep(1);
  Serial.printf("[RFID] UID: %s | Mode: %s\n", uid,
                readerMode == ReaderMode::PAYMENT
                    ? "PAYMENT" : "REGISTER");
  sendCard(uid);
}

// Callback MQTT hanya mengantrekan pesan; aktuator diproses di loop().
void handleMqttMessage(const char* topic, const char* payload) {
  if (!commandQueue || strcmp(topic, commandTopic) != 0) return;

  JsonDocument doc;
  if (deserializeJson(doc, payload)) return;

  const char* command = doc["command"] | "";
  const char* eventId = doc["event_id"] | "";
  const char* result = doc["result"] | "";
  const char* reason = doc["reason"] | "";

  if (strcmp(command, "ACCESS_RESULT") != 0) return;
  if (!eventId[0] || strlen(eventId) >= sizeof(IncomingCommand::eventId)) {
    return;
  }
  if (strcmp(result, "PAID") != 0 && strcmp(result, "DENIED") != 0) {
    return;
  }

  IncomingCommand incoming = {};
  snprintf(incoming.eventId, sizeof(incoming.eventId), "%s", eventId);
  snprintf(incoming.result, sizeof(incoming.result), "%s", result);
  snprintf(incoming.reason, sizeof(incoming.reason), "%s", reason);

  if (xQueueSend(commandQueue, &incoming, 0) != pdTRUE) {
    Serial.println("[MQTT] Antrean perintah penuh");
  }
}

void processCommands(uint32_t now) {
  if (!commandQueue) return;

  IncomingCommand incoming = {};
  while (xQueueReceive(commandQueue, &incoming, 0) == pdTRUE) {
    if (accessState != AccessState::WAITING ||
        strcmp(incoming.eventId, activeEventId) != 0) {
      continue;
    }

    snprintf(completionResult, sizeof(completionResult),
             "%s", incoming.result);
    stateStartedMs = now;

    if (strcmp(incoming.result, "PAID") == 0) {
      accessState = AccessState::PAID;
      setLeds(false, false, true);
      Serial.println("[PAID] LED hijau aktif selama 10 detik");
    } else {
      accessState = AccessState::DENIED;
      setLeds(true, false, false);
      beep(3, 140, 140);
      Serial.printf("[DENIED] %s\n", incoming.reason);
    }
  }
}

void finishExecution(const char* result) {
  snprintf(completionResult, sizeof(completionResult), "%s", result);
  completionPending = true;
  lastFeedbackMs = millis() - 1000;
  standby();
}

void updateAccess(uint32_t now) {
  if (accessState == AccessState::WAITING &&
      now - stateStartedMs >= AppConfig::RESPONSE_TIMEOUT_MS) {
    Serial.println("[TIMEOUT] Keputusan belum diterima");
    finishExecution("TIMEOUT");
  } else if (accessState == AccessState::PAID &&
             now - stateStartedMs >= AppConfig::PAID_DURATION_MS) {
    finishExecution("PAID");
  } else if (accessState == AccessState::DENIED &&
             now - stateStartedMs >= AppConfig::DENIED_DURATION_MS &&
             !beeper.active) {
    finishExecution("DENIED");
  }

  if (completionPending && mqttManager.connected() &&
      now - lastFeedbackMs >= 1000) {
    lastFeedbackMs = now;
    if (publishStatus("EXECUTION_COMPLETE", completionResult)) {
      completionPending = false;
      activeEventId[0] = '\0';
    }
  }
}

void initializeReader() {
  // RST ditangani manual karena driver SPI v2 tidak menerima pin RST.
  pinMode(AppConfig::RFID_RST_PIN, OUTPUT);
  digitalWrite(AppConfig::RFID_RST_PIN, LOW);
  delay(2);
  digitalWrite(AppConfig::RFID_RST_PIN, HIGH);
  delay(50);

  SPI.begin(AppConfig::RFID_SCK_PIN,
            AppConfig::RFID_MISO_PIN,
            AppConfig::RFID_MOSI_PIN,
            AppConfig::RFID_SS_PIN);

  rfid.PCD_Init();

  // Alamat VersionReg RC522 = 0x37.
  const byte version = rfidDriver.PCD_ReadRegister(
      static_cast<MFRC522Driver::PCD_Register>(0x37));

  Serial.printf("[RFID] Version register: 0x%02X\n", version);
  readerReady = version != 0x00 && version != 0xFF;

  if (readerReady) {
    Serial.println("[RFID] Respons SPI diterima. Silakan tap kartu.");
  } else {
    Serial.println("[RFID] Tidak ada respons SPI yang valid.");
    Serial.println("[RFID] Periksa 3.3V, GND, SS, SCK, MISO, MOSI, RST.");
  }
}
}

void setup() {
  Serial.begin(115200);

  pinMode(AppConfig::LED_RED_PIN, OUTPUT);
  pinMode(AppConfig::LED_YELLOW_PIN, OUTPUT);
  pinMode(AppConfig::LED_GREEN_PIN, OUTPUT);
  pinMode(AppConfig::BUZZER_PIN, OUTPUT);
  pinMode(AppConfig::BUTTON_PIN,
          AppConfig::BUTTON_ACTIVE_LOW ? INPUT_PULLUP : INPUT_PULLDOWN);

  writeBuzzer(false);
  standby();

  commandQueue = xQueueCreate(4, sizeof(IncomingCommand));
  if (!commandQueue) {
    Serial.println("[SYSTEM] Gagal membuat antrean MQTT");
  }

  bootId = esp_random();

  snprintf(eventTopic, sizeof(eventTopic), "%s/%s/rfid/event",
           AppConfig::MQTT_TOPIC_ROOT, AppConfig::GROUP_ID);
  snprintf(commandTopic, sizeof(commandTopic), "%s/%s/esp32/command",
           AppConfig::MQTT_TOPIC_ROOT, AppConfig::GROUP_ID);
  snprintf(statusTopic, sizeof(statusTopic), "%s/%s/esp32/status",
           AppConfig::MQTT_TOPIC_ROOT, AppConfig::GROUP_ID);
  snprintf(clientId, sizeof(clientId), "ESP32-%s-%s-%08lX",
           AppConfig::GROUP_ID, AppConfig::NODE_ID,
           static_cast<unsigned long>(bootId));

  button.rawPressed = buttonPressed();
  button.stablePressed = button.rawPressed;
  button.pressedMs = millis();

  initializeReader();

  Serial.printf("[SYSTEM] Group: %s\n", AppConfig::GROUP_ID);
  Serial.printf("[SYSTEM] Client: %s\n", clientId);
  Serial.println("[BUTTON] Singkat: PAYMENT | Tahan 3 detik: REGISTER");

  mqttManager.setCallback(handleMqttMessage);
  mqttManager.begin(clientId);
  wifiManager.begin();
}

void loop() {
  wifiManager.loop();
  mqttManager.loop(wifiManager.connected());

  const uint32_t now = millis();
  updateBuzzer(now);
  updateButton(now);
  processCommands(now);
  updateAccess(now);
  scanCard(now);

  const bool connected = mqttManager.connected();
  if (connected && !mqttWasConnected) {
    publishStatus("ONLINE");
  }
  mqttWasConnected = connected;
}