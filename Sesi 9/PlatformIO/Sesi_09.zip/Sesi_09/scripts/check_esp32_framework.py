import re
from pathlib import Path
from SCons.Script import DefaultEnvironment, Exit


env = DefaultEnvironment()


def stop(message):
    print("\n" + "=" * 68)
    print("[FRAMEWORK CHECK] BUILD DIHENTIKAN")
    print(message)
    print("Hapus folder .pio proyek dan paket framework global, lalu build ulang.")
    print("=" * 68 + "\n")
    Exit(1)


framework = env.PioPlatform().get_package_dir("framework-arduinoespressif32")
if not framework:
    stop("Paket framework-arduinoespressif32 tidak ditemukan.")

framework = Path(framework)
version_header = framework / "cores" / "esp32" / "esp_arduino_version.h"
wifi_header = framework / "libraries" / "WiFi" / "src" / "WiFiGeneric.h"
network_header = framework / "libraries" / "Network" / "src" / "Network.h"

if not version_header.is_file():
    stop("esp_arduino_version.h tidak ditemukan; paket framework tidak lengkap.")

version_text = version_header.read_text(encoding="utf-8", errors="ignore")


def read_version_part(name):
    match = re.search(rf"#define\s+{name}\s+(\d+)", version_text)
    return int(match.group(1)) if match else None


major = read_version_part("ESP_ARDUINO_VERSION_MAJOR")
minor = read_version_part("ESP_ARDUINO_VERSION_MINOR")
patch = read_version_part("ESP_ARDUINO_VERSION_PATCH")

if None in (major, minor, patch):
    stop("Versi Arduino-ESP32 tidak dapat dibaca dari paket framework.")

print(f"[FRAMEWORK CHECK] Arduino-ESP32 Core {major}.{minor}.{patch}")

if major != 2:
    stop(
        f"Template ini dikunci untuk Core 2, tetapi Core {major}.{minor}.{patch} "
        "yang terdeteksi."
    )

if wifi_header.is_file():
    wifi_text = wifi_header.read_text(encoding="utf-8", errors="ignore")
    if '#include "Network.h"' in wifi_text and not network_header.is_file():
        stop(
            "Paket framework tercampur: WiFi memerlukan Network.h, tetapi "
            "library Network tidak tersedia."
        )

print("[FRAMEWORK CHECK] Paket framework konsisten dan siap digunakan.\n")
