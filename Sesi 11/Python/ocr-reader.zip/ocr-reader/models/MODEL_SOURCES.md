# Model resmi yang disertakan

Penerbit: PaddlePaddle/PaddleOCR. Model diunduh pada 6 Oktober 2026
dari tautan pada dokumentasi OCR v3.3.0:
https://www.paddleocr.ai/v3.3.0/en/version3.x/pipeline_usage/OCR.html

1. PP-OCRv5_mobile_det (deteksi teks)
   https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/PP-OCRv5_mobile_det_infer.tar
   SHA-256 arsip resmi:
   50446e5d01ac2a73d5319c89513281f6578414c888c602f9af13f93feefffc58

2. en_PP-OCRv5_mobile_rec (pengenalan teks Latin/angka)
   https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0/en_PP-OCRv5_mobile_rec_infer.tar
   SHA-256 arsip resmi:
   e595b4cf2ffad19fbb5a61ba345d63939577a3ab8717b6e5995642590c9101b4

Bobot tidak dilatih atau dimodifikasi oleh proyek ini. Ketiga file inference
di setiap folder dipertahankan seperti dari arsip. Model adalah OCR umum,
bukan detektor kendaraan atau detektor objek plat khusus.
PaddleOCR dirilis dengan Apache License 2.0; salinan lisensi proyek upstream
disertakan sebagai LICENSE-PaddleOCR.txt.
