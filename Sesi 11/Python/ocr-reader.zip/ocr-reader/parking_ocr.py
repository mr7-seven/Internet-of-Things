"""One window, one webcam, one node MQTT capture channel, CPU-only PaddleOCR."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import queue
import sys
import threading
import time
import traceback
import uuid
from parking_protocol import ScanSession, prepare_capture
from parking_runtime import OcrWorker, ResultStore, latest, load_config

ROOT=Path(__file__).resolve().parent
WINDOW='SMART PARKING'


def utc():return datetime.now(timezone.utc).isoformat(timespec='seconds')
def wall_ms():return int(time.time()*1000)


class MqttLink:
    def __init__(self,config,node_id):
        import paho.mqtt.client as mqtt
        self.config=config;self.node_id=node_id;self.base='parking/'+config['group_id']
        self.events=queue.Queue(maxsize=64);self.connected=threading.Event()
        self.client=mqtt.Client(callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
            client_id=config['client_id_prefix']+'-'+config['group_id']+'-'+uuid.uuid4().hex[:10],
            protocol=mqtt.MQTTv311,clean_session=True)
        if config.get('username'):self.client.username_pw_set(config['username'],config.get('password',''))
        if config.get('tls'):self.client.tls_set()
        self.client.will_set(self.base+'/'+self.node_id+'/python_status',json.dumps(
            {'online':False,'node_id':self.node_id,'ready':False,'timestamp':utc(),'group_id':self.config['group_id']}),qos=1,retain=False)
        self.client.on_connect=self.on_connect;self.client.on_disconnect=self.on_disconnect
        self.client.on_message=self.on_message;self.client.reconnect_delay_set(1,10)

    def on_connect(self,client,userdata,flags,reason_code,properties):
        if reason_code.is_failure:
            print('[MQTT] Connection refused:',reason_code);return
        client.subscribe([(f'{self.base}/{n}/{suffix}',1)
            for n in (self.node_id,) for suffix in ('capture','feedback')])
        self.connected.set();print('[MQTT] Connected:',self.base,flush=True)

    def on_disconnect(self,client,userdata,disconnect_flags,reason_code,properties):
        self.connected.clear();print('[MQTT] Disconnected:',reason_code,flush=True)

    def on_message(self,client,userdata,message):
        try:
            p=json.loads(message.payload.decode('utf-8'))
            parts=message.topic.split('/');node_id=parts[-2];kind=parts[-1]
            if node_id!=self.node_id or p.get('node_id')!=node_id or p.get('group_id')!=self.config['group_id']:return
            self.events.put_nowait((kind,p))
        except (ValueError,AttributeError,queue.Full):
            print('[MQTT] Invalid payload or input queue full',flush=True)

    def start(self):
        self.client.connect_async(self.config['host'],self.config['port'],keepalive=15)
        self.client.loop_start()

    def publish(self,node_id,suffix,payload,retain=False):
        if not self.connected.is_set():return False
        result=self.client.publish(f'{self.base}/{node_id}/{suffix}',json.dumps(payload),qos=1,retain=retain)
        return result.rc==0

    def close(self):
        if self.connected.is_set():
            info=self.client.publish(self.base+'/'+self.node_id+'/python_status',json.dumps(
                {'online':False,'node_id':self.node_id,'ready':False,'timestamp':utc(),'group_id':self.config['group_id']}),qos=1,retain=False)
            try:info.wait_for_publish(timeout=2)
            except RuntimeError:pass
        self.client.disconnect();self.client.loop_stop()


class Camera(threading.Thread):
    def __init__(self,cv2,index,settings):
        super().__init__(name='webcam-'+str(index),daemon=True)
        self.cv2=cv2;self.index=index;self.settings=settings
        self.cap=None;self.frame=None;self.captured_at=0;self.attempt=0;self.error='Waiting for camera'
        self.current=(None,0);self.stop_event=threading.Event()

    def read(self,now):
        self.frame,self.captured_at=self.current

    def grab(self,now):
        cv2=self.cv2
        if self.cap is None:
            if now-self.attempt<3:return
            self.attempt=now
            backends=[cv2.CAP_ANY]
            if os.name=='nt':
                backends={'auto':[cv2.CAP_DSHOW,cv2.CAP_MSMF],
                          'dshow':[cv2.CAP_DSHOW],'msmf':[cv2.CAP_MSMF]}[self.settings['backend']]
            for backend in backends:
                cap=cv2.VideoCapture(self.index,backend)
                if cap.isOpened():
                    fourcc=self.settings.get('fourcc','')
                    if len(fourcc)==4:cap.set(cv2.CAP_PROP_FOURCC,cv2.VideoWriter_fourcc(*fourcc))
                    cap.set(cv2.CAP_PROP_FRAME_WIDTH,self.settings['width'])
                    cap.set(cv2.CAP_PROP_FRAME_HEIGHT,self.settings['height'])
                    cap.set(cv2.CAP_PROP_FPS,self.settings.get('fps',15))
                    cap.set(cv2.CAP_PROP_BUFFERSIZE,1)
                    ok,first=cap.read()
                    if ok and first is not None:
                        self.cap=cap;self.current=(first,time.perf_counter());self.error=None;return
                cap.release()
            if self.cap is None:self.error='Camera not available';return
        ok,frame=self.cap.read()
        if not ok or frame is None:
            self.error='Camera disconnected';self.current=(None,0);self.release_capture();return
        self.current=(frame,time.perf_counter());self.error=None

    def release_capture(self):
        if self.cap is not None:self.cap.release()
        self.cap=None

    def run(self):
        try:
            while not self.stop_event.is_set():
                try:self.grab(time.perf_counter())
                except Exception as error:
                    self.error=str(error);self.current=(None,0);self.release_capture()
                self.stop_event.wait(.01)
        finally:self.release_capture()

    def close(self):
        self.stop_event.set()
        if self.ident:self.join(timeout=2)


def pixel_roi(frame,roi):
    height,width=frame.shape[:2];x,y,w,h=roi
    x0,y0=int(x*width),int(y*height)
    return x0,y0,max(1,min(width,int((x+w)*width))-x0),max(1,min(height,int((y+h)*height))-y0)


def draw_text(cv2,image,text,pos,color=(255,255,255),scale=.58):
    text=str(text).encode('ascii','replace').decode('ascii')
    cv2.putText(image,text,pos,cv2.FONT_HERSHEY_SIMPLEX,scale,(0,0,0),3)
    cv2.putText(image,text,pos,cv2.FONT_HERSHEY_SIMPLEX,scale,color,1)


def draw_system_status(frame,mqtt,config,node_id):
    """Tambahkan footer status tanpa menutupi area frame kamera."""
    import cv2
    display=cv2.copyMakeBorder(frame,0,30,0,0,cv2.BORDER_CONSTANT,value=(24,28,32))
    connected=mqtt.connected.is_set()
    status_color=(40,200,90) if connected else (40,70,230)
    text_color=(225,230,235)
    y=frame.shape[0]+20
    cv2.circle(display,(14,y-4),4,status_color,-1,cv2.LINE_AA)
    cv2.putText(display,f"MQTT {'ONLINE' if connected else 'OFFLINE'}",(25,y),
                cv2.FONT_HERSHEY_SIMPLEX,.43,status_color,1,cv2.LINE_AA)
    identity_text=f"GROUP {config['mqtt']['group_id']}  |  NODE {node_id}"
    scale=.43
    # Keep long group IDs clear of the MQTT indicator on the 640px preview.
    available=max(1,display.shape[1]-145-12)
    while cv2.getTextSize(identity_text,cv2.FONT_HERSHEY_SIMPLEX,scale,1)[0][0]>available and scale>.20:
        scale-=.01
    (text_width,_),_=cv2.getTextSize(identity_text,cv2.FONT_HERSHEY_SIMPLEX,scale,1)
    cv2.putText(display,identity_text,(max(145,display.shape[1]-text_width-12),y),
                cv2.FONT_HERSHEY_SIMPLEX,scale,text_color,1,cv2.LINE_AA)
    return display


def save_capture(cv2,np,output,request_id,frame,roi,result):
    x,y,w,h=pixel_roi(frame,roi)
    output.mkdir(parents=True,exist_ok=True)
    image_path=output/(request_id+'_raw.jpg')
    cv2.imencode('.jpg',frame)[1].tofile(str(image_path))
    cv2.imencode('.jpg',frame[y:y+h,x:x+w])[1].tofile(str(output/(request_id+'_plate.jpg')))
    result['snapshot_path']=str(image_path.resolve())
    (output/(request_id+'.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=ROOT/'config.json')
    parser.add_argument('--role',choices=('entry','exit'),help='Overrides config.role')
    parser.add_argument('--camera',type=int,help='Overrides camera.index; normally 0 on each laptop')
    args=parser.parse_args()
    if sys.version_info[:2]!=(3,10) or sys.maxsize<=2**32:raise RuntimeError('Use Python 3.10 64-bit')
    config=load_config(args.config)
    role=args.role or config['role'];node_id='node1' if role=='entry' else 'node2'
    index=args.camera if args.camera is not None else config['camera']['index']
    if index<0:raise ValueError('Camera index must be >=0')
    import cv2
    import numpy as np
    window=WINDOW+' - '+role.upper()+' / '+node_id
    mqtt=MqttLink(config['mqtt'],node_id)
    output=ROOT/config['output_dir']/config['mqtt']['group_id']/node_id;output.mkdir(parents=True,exist_ok=True)
    store=ResultStore(output/'ocr_delivery.sqlite')
    camera=Camera(cv2,index,config['camera']);worker=OcrWorker(node_id,config['ocr'],ROOT)
    roi=config['camera']['roi'];session=None;submitted=0;captured_until=0;capture_notified=False
    last_send={};last_health=0;drag={};error_printed=False
    #panel_w,panel_h,top,footer=960,540,38,32
    panel_w,panel_h,top,footer=640,360,38,0

    def finish(result,frame=None):
        nonlocal session
        if frame is not None:save_capture(cv2,np,output,result['request_id'],frame,roi,result)
        store.put(result,wall_ms());mqtt.publish(node_id,'ocr_result',store.get(result['request_id']))
        last_send[result['request_id']]=time.perf_counter();session=None
        print('[OCR RESULT]',node_id,result['request_id'],result['status'],result.get('plate'),flush=True)

    def mouse(event,x,y,flags,param):
        nonlocal roi
        if not top<=y<top+panel_h or session is not None:return
        x=max(0,min(panel_w-1,x));y-=top
        if event==cv2.EVENT_LBUTTONDOWN:drag.update(x=x,y=y)
        if event==cv2.EVENT_LBUTTONUP and drag:
            x0,x1=sorted((drag['x'],x));y0,y1=sorted((drag['y'],y))
            if x1-x0>20 and y1-y0>15:
                roi=[x0/panel_w,y0/panel_h,(x1-x0)/panel_w,(y1-y0)/panel_h]
                print('ROI updated; S saves configuration',flush=True)
            drag.clear()

    try:
        cv2.namedWindow(window,cv2.WINDOW_AUTOSIZE);cv2.setMouseCallback(window,mouse)
        camera.start();worker.start();mqtt.start()
        print(f'ONE camera / ONE window / {role} / {node_id} / index {index}. Drag ROI; S save; Q quit.',flush=True)
        while True:
            now=time.perf_counter();camera.read(now)
            ready=worker.ready.is_set() and not worker.error and camera.frame is not None and now-camera.captured_at<=config['ocr']['max_frame_age']
            if now-last_health>=5:
                mqtt.publish(node_id,'python_status',{'online':True,'ready':bool(ready),'node_id':node_id,
                    'camera_index':index,'timestamp':utc(),'group_id':config['mqtt']['group_id']});last_health=now
            if worker.error and not error_printed:
                print('[WORKER ERROR]',worker.error,file=sys.stderr);error_printed=True
            for _ in range(16):
                try:kind,command=mqtt.events.get_nowait()
                except queue.Empty:break
                if command.get('node_id')!=node_id:continue
                if kind=='feedback':
                    request_id=command.get('request_id')
                    cached=store.get(request_id) if isinstance(request_id,str) else None
                    if cached and cached['node_id']==node_id:
                        store.acknowledge(request_id)
                        print('[NODE-RED]',node_id,command.get('status'),command.get('message'),flush=True)
                    if session and session.command['request_id']==request_id:session=None
                    continue
                try:command=prepare_capture(command,config['mqtt']['group_id'],wall_ms())
                except ValueError as error:print('[COMMAND REJECTED]',error,flush=True);continue
                cached=store.get(command['request_id'])
                if cached:
                    if cached['node_id']==node_id and cached['action']==role:mqtt.publish(node_id,'ocr_result',cached)
                    continue
                if command['expires_ms']<=wall_ms():continue
                if session:
                    if session.command['request_id']!=command['request_id']:print('[BUSY] ignored overlapping request',command['request_id'],flush=True)
                    continue
                if not ready:
                    finish(ScanSession(command,config['ocr'],now).result('CAMERA_ERROR',message='Camera/OCR not ready'));continue
                session=ScanSession(command,config['ocr'],now);submitted=0;capture_notified=False
            try:request_id,captured_at,frame,detections=worker.results.get_nowait()
            except queue.Empty:pass
            else:
                if session and session.command['request_id']==request_id:
                    event=session.observe(detections,captured_at,now)
                    if event:finish(session.result('READ',event.text,event.score,message='Stable OCR'),frame)
            if session:
                if worker.error or (not ready and now-session.started>2):
                    finish(session.result('CAMERA_ERROR',message='Camera or OCR disconnected'))
                elif now>=session.deadline or wall_ms()>=session.command['expires_ms']:
                    finish(session.result('OCR_FAILED',message='Plat tidak terbaca stabil sebelum timeout'))
                elif now>=session.not_before and now-submitted>=config['ocr']['sample_interval'] and camera.frame is not None and camera.captured_at>=session.not_before:
                    frame=camera.frame.copy()
                    if not capture_notified:
                        snapshot=output/(session.command['request_id']+'_raw.jpg')
                        ok,encoded=cv2.imencode('.jpg',frame)
                        if not ok:raise RuntimeError('Cannot encode captured frame')
                        encoded.tofile(str(snapshot));captured_until=now+2;capture_notified=True
                        print('[CAPTURED]',node_id,session.command['request_id'],flush=True)
                    latest(worker.tasks,(session.command['request_id'],camera.captured_at,frame,pixel_roi(frame,roi)));submitted=now
            if mqtt.connected.is_set():
                for result,saved_ms in store.pending():
                    if result['node_id']!=node_id or wall_ms()-saved_ms>config['result_delivery_timeout']*1000:continue
                    if now-last_send.get(result['request_id'],0)>=config['result_retry_seconds']:
                        mqtt.publish(node_id,'ocr_result',result);last_send[result['request_id']]=now
            canvas=np.full((top+panel_h+footer,panel_w,3),25,dtype=np.uint8)
            frame=camera.frame
            if frame is None:frame=np.zeros((panel_h,panel_w,3),dtype=np.uint8)
            view=cv2.resize(frame,(panel_w,panel_h));x,y,w,h=roi
            cv2.rectangle(view,(int(x*panel_w),int(y*panel_h)),(int((x+w)*panel_w),int((y+h)*panel_h)),(255,180,0),2)
            canvas[top:top+panel_h]=view
            draw_text(cv2,canvas,f'{role.upper()} | {node_id} | camera {index}',(12,25),(0,230,170))
            if now<captured_until:draw_text(cv2,canvas,'CAPTURED',(18,top+panel_h-18),(0,255,0),.85)
            if not ready:draw_text(cv2,canvas,camera.error or 'Camera / OCR loading...',(18,top+36),(0,180,255),.55)
            display_frame=draw_system_status(canvas,mqtt,config,node_id)
            cv2.imshow(window,display_frame);key=cv2.waitKey(20)&0xFF
            if key in (27,ord('q')) or cv2.getWindowProperty(window,cv2.WND_PROP_VISIBLE)<1:break
            if key==ord('s'):
                config['camera']['roi']=roi
                args.config.write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8');print('ROI configuration saved',flush=True)
    finally:
        worker.stop_event.set();camera.close();mqtt.close()
        if worker.ident:worker.join(timeout=2)
        store.close();cv2.destroyAllWindows()


if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('Stopped')
    except Exception:traceback.print_exc();sys.exit(1)
