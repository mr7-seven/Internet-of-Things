"""Offline checks; --ocr exercises one real OCR worker without MQTT/DB mutation."""
import argparse
import importlib.metadata as meta
from pathlib import Path
import sys
import time
from parking_runtime import OcrWorker,load_config,latest
from plate_reader.core import choose_candidate

ROOT=Path(__file__).resolve().parent
EXPECTED={'paddlepaddle':'3.2.2','paddleocr':'3.3.2','paddlex':'3.3.10',
          'opencv-contrib-python':'4.10.0.84','numpy':'1.26.4','paho-mqtt':'2.1.0'}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--ocr',action='store_true');a=p.parse_args()
    assert sys.version_info[:2]==(3,10) and sys.maxsize>2**32,'Use Python 3.10 64-bit'
    for name,expected in EXPECTED.items():
        actual=meta.version(name);print(name,actual);assert actual==expected,f'{name}: expected {expected}'
    for name in ('paddlepaddle-gpu','opencv-python','opencv-python-headless','opencv-contrib-python-headless'):
        try:meta.version(name)
        except meta.PackageNotFoundError:continue
        raise RuntimeError('Conflicting package: '+name)
    cfg=load_config(ROOT/'config.json');print('Group:',cfg['mqtt']['group_id'],'| one camera index:',cfg['camera']['index'])
    if a.ocr:
        import cv2
        workers={n:OcrWorker(n,cfg['ocr'],ROOT) for n in ('node1',)}
        image=cv2.imread(str(ROOT/'examples/demo_plate.png'));assert image is not None
        try:
            for worker in workers.values():worker.start()
            for worker in workers.values():
                assert worker.ready.wait(60),'Model initialization timeout'
                assert not worker.error,worker.error
            for i in range(3):
                for n,worker in workers.items():latest(worker.tasks,(f'{n}-smoke',time.perf_counter(),image.copy(),(0,0,image.shape[1],image.shape[0])))
                for n,worker in workers.items():
                    packet=worker.results.get(timeout=20);candidate=choose_candidate(packet[3])
                    assert candidate and candidate.text=='DA 1234 AB',(n,candidate)
                    print(n,'read',i+1,candidate.text)
        finally:
            for worker in workers.values():worker.stop_event.set()
            for worker in workers.values():worker.join(timeout=3)
        assert all(not worker.is_alive() for worker in workers.values()),'Worker cleanup failed'
        print('One CPU OCR worker passed')
    print('Checks passed; real camera/MQTT test is separate')


if __name__=='__main__':main()
