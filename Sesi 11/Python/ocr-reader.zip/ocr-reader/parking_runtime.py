"""One OCR worker per laptop; all durable result handling stays in main thread."""
import json
import queue
import sqlite3
import threading
import traceback
from pathlib import Path
from types import SimpleNamespace
from parking_protocol import GROUP


def load_config(path):
    config=json.loads(Path(path).read_text(encoding='utf-8'))
    if not GROUP.fullmatch(config['mqtt']['group_id']):
        raise ValueError('group_id: use 1..40 letters, digits, underscore or hyphen')
    camera=config['camera'];ocr=config['ocr']
    if config.get('role') not in ('entry','exit'):
        raise ValueError('role must be entry or exit')
    if not isinstance(camera['index'],int) or camera['index']<0:
        raise ValueError('camera.index must be a non-negative integer')
    if camera['backend'] not in ('auto','dshow','msmf'):
        raise ValueError('Camera backend must be auto/dshow/msmf')
    if min(camera['width'],camera['height'],ocr['cpu_threads'],ocr['stable_reads'])<1:
        raise ValueError('Dimensions, thread count and stable_reads must be positive')
    if not .70<=ocr['min_score']<=1:
        raise ValueError('min_score must be 0.70..1 (Node-RED also enforces 0.70)')
    if not 1<=ocr['scan_timeout']<=20 or ocr['settle_seconds']<0 or ocr['sample_interval']<.1:
        raise ValueError('Invalid scan timing: timeout 1..20, settle >=0, interval >=0.1')
    if ocr['settle_seconds']>=ocr['scan_timeout'] or ocr['max_frame_age']<=0:
        raise ValueError('settle must be shorter than scan timeout; frame age must be positive')
    for key in ('roi',):
        x,y,w,h=camera[key]
        if not (0<=x<1 and 0<=y<1 and w>0 and h>0 and x+w<=1 and y+h<=1):
            raise ValueError('Invalid normalized ROI: '+key)
    return config


def latest(q,value):
    try:q.put_nowait(value)
    except queue.Full:
        try:q.get_nowait()
        except queue.Empty:pass
        q.put_nowait(value)


class OcrWorker(threading.Thread):
    def __init__(self,node_id,settings,root):
        super().__init__(name='ocr-'+node_id,daemon=True)
        self.node_id=node_id;self.settings=settings;self.root=Path(root)
        self.tasks=queue.Queue(maxsize=1);self.results=queue.Queue(maxsize=1)
        self.ready=threading.Event();self.stop_event=threading.Event();self.error=None

    def run(self):
        try:
            from plate_reader.engine import OcrEngine
            settings=self.settings
            args=SimpleNamespace(cpu_threads=settings['cpu_threads'],max_side=settings['max_side'],
                min_score=settings['min_score'],mkldnn=settings['mkldnn'],
                det_model_dir=self.root/'models/PP-OCRv5_mobile_det_infer',
                rec_model_dir=self.root/'models/en_PP-OCRv5_mobile_rec_infer')
            engine=OcrEngine(args);self.ready.set()
            while not self.stop_event.is_set():
                try:request_id,captured_at,frame,roi=self.tasks.get(timeout=.1)
                except queue.Empty:continue
                x,y,w,h=roi
                detections=engine.read(frame[y:y+h,x:x+w].copy())
                for d in detections:d.polygon=[[px+x,py+y] for px,py in d.polygon]
                latest(self.results,(request_id,captured_at,frame,detections))
        except Exception:
            self.error=traceback.format_exc();self.ready.set()


class ResultStore:
    def __init__(self,path):
        self.conn=sqlite3.connect(path)
        self.conn.execute('CREATE TABLE IF NOT EXISTS result_cache(request_id TEXT PRIMARY KEY, result_json TEXT NOT NULL, saved_ms INTEGER NOT NULL, acknowledged INTEGER NOT NULL DEFAULT 0)')
        self.conn.commit()

    def get(self,request_id):
        row=self.conn.execute('SELECT result_json FROM result_cache WHERE request_id=?',(request_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def put(self,result,now_ms):
        # First result wins; a QoS duplicate must never overwrite an earlier OCR.
        self.conn.execute('INSERT OR IGNORE INTO result_cache(request_id,result_json,saved_ms) VALUES(?,?,?)',
                          (result['request_id'],json.dumps(result),now_ms));self.conn.commit()

    def acknowledge(self,request_id):
        self.conn.execute('UPDATE result_cache SET acknowledged=1 WHERE request_id=?',(request_id,));self.conn.commit()

    def pending(self):
        return [(json.loads(r[0]),r[1]) for r in self.conn.execute(
            'SELECT result_json,saved_ms FROM result_cache WHERE acknowledged=0')]

    def close(self):self.conn.close()
