"""PaddleOCR 3.3.x public API. All inference is explicitly on CPU."""
from .core import Detection


class OcrEngine:
    def __init__(self, args):
        from paddleocr import PaddleOCR
        options = dict(
            device="cpu",
            text_detection_model_name="PP-OCRv5_mobile_det",
            text_recognition_model_name="en_PP-OCRv5_mobile_rec",
            use_doc_orientation_classify=False,
            use_doc_unwarping=False,
            use_textline_orientation=False,
            enable_mkldnn=args.mkldnn,
            cpu_threads=args.cpu_threads,
            text_det_limit_side_len=args.max_side,
            text_det_limit_type="max",
            text_rec_score_thresh=args.min_score,
        )
        if args.det_model_dir:
            options["text_detection_model_dir"] = str(args.det_model_dir.resolve())
        if args.rec_model_dir:
            options["text_recognition_model_dir"] = str(args.rec_model_dir.resolve())
        self.ocr = PaddleOCR(**options)

    def read(self, bgr_image):
        detections = []
        for result in self.ocr.predict(input=bgr_image):
            # The documented json property returns a dict with the 'res' object.
            payload = result.json["res"]
            texts = payload["rec_texts"]
            scores = payload["rec_scores"]
            polygons = payload["rec_polys"]
            if not (len(texts) == len(scores) == len(polygons)):
                raise RuntimeError("Unexpected OCR result: texts/scores/polygons length differs")
            for text, score, poly in zip(texts, scores, polygons):
                if str(text).strip():
                    detections.append(Detection(str(text).strip(), float(score),
                                                [[float(x), float(y)] for x, y in poly]))
        return detections
