"""Pure Python filtering and temporal confirmation (no OCR dependency)."""
from dataclasses import dataclass
import re
from typing import Optional


@dataclass
class Detection:
    text: str
    score: float
    polygon: list

    @property
    def bounds(self):
        xs, ys = zip(*self.polygon)
        return min(xs), min(ys), max(xs), max(ys)


@dataclass
class Candidate:
    text: str
    score: float
    parts: list


PLATE = re.compile(r"([A-Z]{1,2})([0-9]{1,4})([A-Z]{0,3})")


def normalize(text: str) -> str:
    # Keep OCR's O/0 and I/1 untouched; replacing them can fabricate a plate.
    return re.sub(r"[^A-Z0-9]", "", text.upper())


def format_plate(text: str) -> Optional[str]:
    match = PLATE.fullmatch(normalize(text))
    if not match:
        return None
    return " ".join(group for group in match.groups() if group)


def rows_of(detections):
    rows = []
    for det in sorted(detections, key=lambda d: (d.bounds[1], d.bounds[0])):
        x0, y0, x1, y1 = det.bounds
        center, height = (y0 + y1) / 2, max(1, y1 - y0)
        for row in rows:
            ref = row[0].bounds
            ref_height = max(1, ref[3] - ref[1])
            if abs(center - (ref[1] + ref[3]) / 2) <= 0.5 * min(height, ref_height):
                row.append(det)
                break
        else:
            rows.append([det])
    return [sorted(row, key=lambda d: d.bounds[0]) for row in rows]


def choose_candidate(detections, mode="plate") -> Optional[Candidate]:
    if not detections:
        return None
    rows = rows_of(detections)
    choices = []
    for row in rows:
        if mode == "text":
            choices.append(Candidate(" ".join(d.text for d in row),
                                     min(d.score for d in row), row))
            continue
        # Join up to three adjacent OCR boxes, only within a single text row.
        for start in range(len(row)):
            parts = []
            for det in row[start:start + 3]:
                if parts:
                    prev = parts[-1].bounds
                    cur = det.bounds
                    height = min(prev[3] - prev[1], cur[3] - cur[1])
                    if cur[0] - prev[2] > 2.5 * height:
                        break
                parts.append(det)
                text = format_plate("".join(d.text for d in parts))
                if text:
                    choices.append(Candidate(text, min(d.score for d in parts), parts.copy()))
    if not choices:
        return None
    # Prefer a complete suffix, then confidence, then number of characters.
    # This is a shape heuristic, not proof that text is a registered plate.
    return max(choices, key=lambda c: (bool(re.search(r"[0-9] [A-Z]+$", c.text)),
                                      c.score, len(c.text)))


class Stabilizer:
    def __init__(self, required=3, ttl=1.5):
        self.required = required
        self.ttl = ttl
        self.reset()

    def reset(self):
        self.pending = ""
        self.count = 0
        self.stable = ""
        self.last_seen = None
        self.last_emitted = ""

    def expire(self, now):
        if self.last_seen is not None and now - self.last_seen > self.ttl:
            self.reset()

    def update(self, candidate, now):
        self.expire(now)
        if candidate is None:
            self.pending, self.count, self.stable = "", 0, ""
            return None
        self.last_seen = now
        if candidate.text == self.pending:
            self.count += 1
        else:
            self.pending, self.count, self.stable = candidate.text, 1, ""
        if self.count >= self.required:
            self.stable = candidate.text
            if self.last_emitted != self.stable:
                self.last_emitted = self.stable
                return candidate
        return None
