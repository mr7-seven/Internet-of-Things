"""Webcam OCR for one plate in a selected area."""
