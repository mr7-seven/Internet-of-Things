import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def bundled_model(name):
    path = ROOT / "models" / name
    return path if path.is_dir() else None


def roi_value(value):
    try:
        values = tuple(float(x) for x in value.split(","))
    except ValueError as error:
        raise argparse.ArgumentTypeError("ROI must be x,y,width,height") from error
    if len(values) != 4:
        raise argparse.ArgumentTypeError("ROI must contain four values")
    x, y, w, h = values
    if not (0 <= x < 1 and 0 <= y < 1 and w > 0 and h > 0 and x + w <= 1 and y + h <= 1):
        raise argparse.ArgumentTypeError("ROI uses normalized 0..1 coordinates, within the frame")
    return values


def parser():
    p = argparse.ArgumentParser(description="Plate/text OCR, Python 3.10 + PaddleOCR 3.x, CPU")
    p.add_argument("--camera", type=int, default=0)
    p.add_argument("--backend", choices=("auto", "dshow", "msmf"), default="auto")
    p.add_argument("--width", type=int, default=1280)
    p.add_argument("--height", type=int, default=720)
    p.add_argument("--image", type=Path, help="Read an image instead of opening a webcam")
    p.add_argument("--roi", type=roi_value, default=(0.15, 0.35, 0.70, 0.30))
    p.add_argument("--full-frame", action="store_true")
    p.add_argument("--mode", choices=("plate", "text"), default="plate")
    p.add_argument("--interval", type=float, default=0.4, help="Minimum interval between submitted frames")
    p.add_argument("--min-score", type=float, default=0.70)
    p.add_argument("--stable-reads", type=int, default=3)
    p.add_argument("--ttl", type=float, default=1.5, help="Maximum OCR result age in seconds")
    p.add_argument("--cpu-threads", type=int, default=4)
    p.add_argument("--max-side", type=int, default=960)
    p.add_argument("--mkldnn", action="store_true", help="Optional acceleration; disabled by default")
    p.add_argument("--det-model-dir", type=Path,
                   default=bundled_model("PP-OCRv5_mobile_det_infer"))
    p.add_argument("--rec-model-dir", type=Path,
                   default=bundled_model("en_PP-OCRv5_mobile_rec_infer"))
    p.add_argument("--output", type=Path, default=Path("output"))
    p.add_argument("--no-display", action="store_true", help="Image mode only")
    return p


def parse_args(argv=None):
    p = parser()
    args = p.parse_args(argv)
    if min(args.width, args.height, args.stable_reads, args.cpu_threads) < 1:
        p.error("width, height, stable-reads, cpu-threads must be positive")
    if args.max_side < 64 or args.interval < 0.05 or args.ttl <= 0:
        p.error("max-side >= 64, interval >= 0.05, ttl > 0 required")
    if not 0 <= args.min_score <= 1:
        p.error("min-score must be between 0 and 1")
    if args.no_display and args.image is None:
        p.error("--no-display requires --image")
    for path in (args.det_model_dir, args.rec_model_dir):
        if path and not path.is_dir():
            p.error(f"Model directory does not exist: {path}")
    return args
