"""Validated wire messages and scan state; no camera/network imports."""
import re
import math
from plate_reader.core import Stabilizer, choose_candidate

ID = re.compile(r"[A-Za-z0-9_-]{1,96}")
GROUP = re.compile(r"[A-Za-z0-9_-]{1,40}")


def validate_capture(message):
    if not isinstance(message, dict) or not isinstance(message.get('request_id'), str) or not ID.fullmatch(message['request_id']):
        raise ValueError('Invalid request_id')
    action = {'node1': 'entry', 'node2': 'exit'}.get(message.get('node_id'))
    if action is None or message.get('action') != action:
        raise ValueError('node_id/action mismatch')
    expires = message.get('expires_ms')
    if not isinstance(expires, (int, float)) or isinstance(expires, bool) or not math.isfinite(expires):
        raise ValueError('expires_ms required')
    return message


def prepare_capture(message, group, now_ms):
    """ESP32 uses uptime age; no clock synchronization required on the MCU."""
    if not isinstance(message, dict) or message.get('group_id') != group:
        raise ValueError('group_id mismatch')
    age=message.get('age_ms',0)
    if not isinstance(age,int) or isinstance(age,bool) or not 0<=age<45000:
        raise ValueError('Capture request expired or invalid age_ms')
    command={**message,'expires_ms':now_ms+35000-age}
    return validate_capture(command)


class ScanSession:
    def __init__(self, command, settings, started):
        self.command = validate_capture(command)
        self.settings = settings
        self.started = started
        self.deadline = started + settings['scan_timeout']
        self.not_before = started + settings['settle_seconds']
        self.stabilizer = Stabilizer(settings['stable_reads'], settings['max_frame_age'])
        self.finished = False
        self.last_frame_at = -1

    def observe(self, detections, captured_at, now):
        if self.finished or captured_at < self.not_before or now >= self.deadline:
            return None
        if captured_at <= self.last_frame_at:
            return None
        self.last_frame_at = captured_at
        if now - captured_at > self.settings['max_frame_age']:
            self.stabilizer.reset()
            return None
        candidate = choose_candidate(detections)
        return self.stabilizer.update(candidate, now)

    def result(self, status, plate=None, score=None, snapshot_path=None, message=None):
        self.finished = True
        return dict(group_id=self.command['group_id'], expires_ms=self.command['expires_ms'],
                    request_id=self.command['request_id'], node_id=self.command['node_id'],
                    action=self.command['action'], status=status, plate=plate, score=score,
                    snapshot_path=snapshot_path, message=message)
