Import("env")
import json
from pathlib import Path
platform = env.PioPlatform()
path = platform.get_package_dir("framework-arduinoespressif32")
if path:
    version = json.loads((Path(path)/"package.json").read_text())["version"]
    if not version.startswith("3.20017."):
        raise RuntimeError("Proyek memakai Arduino ESP32 2.0.17 seperti template yang diuji; periksa platform_packages")
