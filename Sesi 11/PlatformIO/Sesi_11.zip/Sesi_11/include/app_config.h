#pragma once
#include <Arduino.h>
#ifndef PARKING_NODE_ROLE
#define PARKING_NODE_ROLE 1
#endif
namespace AppConfig {
constexpr char WIFI_SSID[] = "NAMA_WIFI";
constexpr char WIFI_PASSWORD[] = "PASSWORD_WIFI";
constexpr char MQTT_HOST[] = "broker.emqx.io";
constexpr uint16_t MQTT_PORT = 1883;
constexpr char MQTT_USERNAME[] = "";
constexpr char MQTT_PASSWORD[] = "";
constexpr char GROUP_ID[] = "kelompok-00";
constexpr char MQTT_TOPIC_ROOT[] = "parking";
#if PARKING_NODE_ROLE == 1
constexpr char NODE_ID[] = "node1";
constexpr char ACTION[] = "entry";
#elif PARKING_NODE_ROLE == 2
constexpr char NODE_ID[] = "node2";
constexpr char ACTION[] = "exit";
#else
#error "PARKING_NODE_ROLE harus 1 atau 2"
#endif
constexpr uint8_t LED_RED = 25;
constexpr uint8_t LED_YELLOW = 26;
constexpr uint8_t LED_GREEN = 27;
constexpr bool LED_ACTIVE_HIGH = true;
constexpr uint8_t BUTTON_PIN = 33;
constexpr bool BUTTON_ACTIVE_LOW = true;
constexpr uint32_t BUTTON_DEBOUNCE_MS = 40;
constexpr uint8_t BUZZER_PIN = 32;
constexpr bool BUZZER_ACTIVE_HIGH = true;
constexpr bool PASSIVE_BUZZER = false;
constexpr uint16_t BUZZER_HZ = 2000;
constexpr uint32_t WIFI_RECONNECT_INTERVAL_MS = 3000;
constexpr uint32_t WIFI_CONNECT_TIMEOUT_MS = 10000;
constexpr uint32_t MQTT_RECONNECT_INTERVAL_MS = 5000;
constexpr uint32_t MQTT_CONNECT_TIMEOUT_MS = 10000;
constexpr uint32_t CAPTURE_RETRY_MS = 2500;
constexpr uint32_t TRANSACTION_TIMEOUT_MS = 45000;
}
