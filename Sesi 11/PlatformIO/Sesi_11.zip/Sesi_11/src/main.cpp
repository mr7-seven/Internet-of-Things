#include <Arduino.h>
#include <ArduinoJson.h>
#include <esp_system.h>
#include <cstring>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include "app_config.h"
#include "wifi_manager.h"
#include "mqtt_manager.h"
using namespace AppConfig;
namespace {
char captureTopic[128]={}, feedbackTopic[128]={}, statusTopic[128]={}, clientId[96]={};
WifiManager wifiManager(WIFI_SSID,WIFI_PASSWORD,WIFI_RECONNECT_INTERVAL_MS,WIFI_CONNECT_TIMEOUT_MS);
MqttManager mqttManager(MQTT_HOST,MQTT_PORT,feedbackTopic,MQTT_USERNAME,MQTT_PASSWORD,
                        MQTT_RECONNECT_INTERVAL_MS,MQTT_CONNECT_TIMEOUT_MS);
struct Feedback {char request[97];char status[20];char plate[24];char message[180];};
QueueHandle_t feedbackQueue=nullptr;
String requestId;
uint32_t bootId=0,sequenceId=0,startedMs=0,lastRequestMs=0,lastHealthMs=0;
bool busy=false,wasConnected=false;
enum class Pattern { NONE,PRESS,ENTRY_OK,EXIT_OK,DENIED };
Pattern pattern=Pattern::NONE;
uint32_t patternStartMs=0;
void traffic(bool red,bool yellow,bool green) {
 digitalWrite(LED_RED,red==LED_ACTIVE_HIGH?HIGH:LOW);
 digitalWrite(LED_YELLOW,yellow==LED_ACTIVE_HIGH?HIGH:LOW);
 digitalWrite(LED_GREEN,green==LED_ACTIVE_HIGH?HIGH:LOW);
}
void buzzer(bool on) {
 if(PASSIVE_BUZZER) {if(on)tone(BUZZER_PIN,BUZZER_HZ);else noTone(BUZZER_PIN);}
 else digitalWrite(BUZZER_PIN,on==BUZZER_ACTIVE_HIGH?HIGH:LOW);
}
void startPattern(Pattern value) {pattern=value;patternStartMs=millis();}
void updateIndicators() {
 const uint32_t elapsed=millis()-patternStartMs;
 if(pattern==Pattern::PRESS) {
  traffic(false,true,false);buzzer(elapsed<120);
  if(elapsed>=120){pattern=Pattern::NONE;buzzer(false);}
 } else if(pattern==Pattern::ENTRY_OK) {
  traffic(false,false,true);buzzer(elapsed<150);
  if(elapsed>=600){pattern=Pattern::NONE;buzzer(false);}
 } else if(pattern==Pattern::EXIT_OK || pattern==Pattern::DENIED) {
  const bool denied=pattern==Pattern::DENIED;
  if(elapsed<1800){const bool on=elapsed%600<300;traffic(denied&&on,false,!denied&&on);buzzer(denied&&on);}
  else {pattern=Pattern::NONE;buzzer(false);traffic(false,false,true);}
 } else {traffic(false,busy,!busy);buzzer(false);}
}
void publishHealth() {
 if(!mqttManager.connected())return;
 JsonDocument doc;doc["group_id"]=GROUP_ID;doc["node_id"]=NODE_ID;
 doc["online"]=true;doc["busy"]=busy;doc["uptime_ms"]=millis();
 char payload[256];serializeJson(doc,payload,sizeof(payload));
 mqttManager.publish(statusTopic,payload);lastHealthMs=millis();
}
void publishCapture() {
 if(!busy||!mqttManager.connected())return;
 JsonDocument doc;doc["group_id"]=GROUP_ID;doc["node_id"]=NODE_ID;doc["action"]=ACTION;
 doc["request_id"]=requestId;doc["age_ms"]=millis()-startedMs;
 char payload[384];serializeJson(doc,payload,sizeof(payload));
 const bool sent=mqttManager.publish(captureTopic,payload);
 lastRequestMs=millis();Serial.printf("[CAPTURE] %s id=%s sent=%s\n",captureTopic,requestId.c_str(),sent?"YES":"NO");
}
void handleMqttMessage(const char* topic,const char* payload) {
 if(std::strcmp(topic,feedbackTopic)!=0)return;
 JsonDocument doc;if(deserializeJson(doc,payload))return;
 if(std::strcmp(doc["group_id"]|"",GROUP_ID)||std::strcmp(doc["node_id"]|"",NODE_ID)||std::strcmp(doc["action"]|"",ACTION))return;
 Feedback item={};
 snprintf(item.request,sizeof(item.request),"%s",doc["request_id"]|"");
 snprintf(item.status,sizeof(item.status),"%s",doc["status"]|"");
 snprintf(item.plate,sizeof(item.plate),"%s",doc["plate"]|"-");
 snprintf(item.message,sizeof(item.message),"%s",doc["message"]|"");
 // Async callback only enqueues; LED, buzzer and transaction state stay in loop().
 if(feedbackQueue)xQueueSend(feedbackQueue,&item,0);
}
void receiveFeedback() {
 Feedback item;
 while(xQueueReceive(feedbackQueue,&item,0)==pdTRUE) {
  if(!busy||requestId!=item.request)continue;
  const bool accepted=(PARKING_NODE_ROLE==1 && !strcmp(item.status,"ENTERED"))||
                      (PARKING_NODE_ROLE==2 && !strcmp(item.status,"EXITED"));
  const bool denied=!strcmp(item.status,"FULL")||!strcmp(item.status,"DUPLICATE")||
     !strcmp(item.status,"NOT_FOUND")||!strcmp(item.status,"OCR_FAILED")||
     !strcmp(item.status,"TIMEOUT")||!strcmp(item.status,"ERROR");
  if(!accepted&&!denied)continue;
  busy=false;Serial.printf("[FEEDBACK] %s | %s | %s\n",item.status,item.plate,item.message);
  startPattern(accepted?(PARKING_NODE_ROLE==1?Pattern::ENTRY_OK:Pattern::EXIT_OK):Pattern::DENIED);
  publishHealth();
 }
}
bool buttonPressed(){return (digitalRead(BUTTON_PIN)==LOW)==BUTTON_ACTIVE_LOW;}
bool rawPressed=false,stablePressed=false;
uint32_t changedMs=0;
void updateButton(uint32_t now) {
 const bool pressed=buttonPressed();
 if(pressed!=rawPressed){rawPressed=pressed;changedMs=now;}
 if(now-changedMs<BUTTON_DEBOUNCE_MS||stablePressed==rawPressed)return;
 stablePressed=rawPressed;
 if(!stablePressed)return;
 if(busy||pattern!=Pattern::NONE){Serial.println("[BUTTON] Masih memproses");return;}
 if(!wifiManager.connected()||!mqttManager.connected()){
  Serial.println("[BUTTON] WiFi/MQTT belum tersambung");startPattern(Pattern::DENIED);return;
 }
 char id[97];snprintf(id,sizeof(id),"%s-%012llX-%08lX-%lu",NODE_ID,
  (unsigned long long)(ESP.getEfuseMac()&0xFFFFFFFFFFFFULL),(unsigned long)bootId,(unsigned long)++sequenceId);
 requestId=id;busy=true;startedMs=now;startPattern(Pattern::PRESS);
 publishCapture();publishHealth();
}
}
void setup() {
 Serial.begin(115200);
 const uint8_t pins[]={LED_RED,LED_YELLOW,LED_GREEN,BUZZER_PIN};for(uint8_t p:pins)pinMode(p,OUTPUT);
 pinMode(BUTTON_PIN,BUTTON_ACTIVE_LOW?INPUT_PULLUP:INPUT_PULLDOWN);
 rawPressed=stablePressed=buttonPressed();traffic(false,false,true);buzzer(false);
 feedbackQueue=xQueueCreate(8,sizeof(Feedback));if(!feedbackQueue){Serial.println("[ERROR] Queue allocation");while(true)delay(1000);}
 bootId=esp_random();
 snprintf(captureTopic,sizeof(captureTopic),"%s/%s/%s/capture",MQTT_TOPIC_ROOT,GROUP_ID,NODE_ID);
 snprintf(feedbackTopic,sizeof(feedbackTopic),"%s/%s/%s/feedback",MQTT_TOPIC_ROOT,GROUP_ID,NODE_ID);
 snprintf(statusTopic,sizeof(statusTopic),"%s/%s/%s/status",MQTT_TOPIC_ROOT,GROUP_ID,NODE_ID);
 snprintf(clientId,sizeof(clientId),"ESP32-%s-%s-%012llX-%08lX",GROUP_ID,NODE_ID,
  (unsigned long long)(ESP.getEfuseMac()&0xFFFFFFFFFFFFULL),(unsigned long)bootId);
 Serial.printf("[SYSTEM] group=%s node=%s action=%s\n[CAPTURE TOPIC] %s\n",GROUP_ID,NODE_ID,ACTION,captureTopic);
 mqttManager.setCallback(handleMqttMessage);mqttManager.begin(clientId);wifiManager.begin();
}
void loop() {
 wifiManager.loop();mqttManager.loop(wifiManager.connected());
 receiveFeedback();
 const uint32_t now=millis();
 const bool connected=wifiManager.connected()&&mqttManager.connected();
 if(connected&&!wasConnected){publishHealth();if(busy)publishCapture();}
 wasConnected=connected;
 updateButton(now);
 if(busy&&now-startedMs>=TRANSACTION_TIMEOUT_MS){busy=false;startPattern(Pattern::DENIED);publishHealth();Serial.println("[TIMEOUT] Periksa dashboard sebelum mengulang");}
 if(busy&&now-lastRequestMs>=CAPTURE_RETRY_MS)publishCapture();
 if(connected&&now-lastHealthMs>=5000)publishHealth();
 updateIndicators();
}
