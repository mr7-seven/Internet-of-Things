## 1. ESP32 PlatformIO — pilih environment

Dari folder `esp32`:

```powershell
pio run -e parking_node1 -t upload --upload-port COM5
pio run -e parking_node2 -t upload --upload-port COM6
pio device monitor -p COM5 -b 115200
```

Atau pilih environment melalui PlatformIO Project Tasks di VS Code.
COM5/COM6 adalah contoh. Env node1 memilih entry, node2 memilih exit, tanpa
mengedit NODE_ID atau main.cpp. Firmware sama seperti v2; tidak ada dua kamera
pada ESP32. Platform **6.9.0**, Arduino Core **2.0.17**, ArduinoJson **7.4.3**,
AsyncTCP **1.1.1**, AsyncMqttClient **0.9.0**. Urutan dependency dan script penjaga
versi framework tetap disertakan.

| Perangkat setiap node | GPIO |
|---|---:|
| LED merah / kuning / hijau | 25 / 26 / 27 |
| Push button ke GND (INPUT_PULLUP) | 33 |
| Buzzer aktif / input modul | 32 |

Gunakan resistor LED dan driver/modul buzzer sesuai perangkat. Default active
HIGH; opsi polarity/buzzer pasif ada dalam app_config.h. Semua GND terhubung.

| Kondisi | Entry node1 | Exit node2 |
|---|---|---|
| Standby | Hijau | Hijau |
| Button | Beep 1×, lalu kuning selama proses | Sama |
| Sukses | Hijau + beep 1× | Hijau blink 3×, lalu hijau tetap |
| Penuh / gagal / plat tidak cocok | Merah + buzzer 3×, lalu hijau | Sama |

Debounce 40 ms, button saat busy diabaikan, indikator memakai millis(). Callback
MQTT memasukkan feedback ke antrean; main loop memperbarui state/LED/buzzer.

## 2. Topik

Ganti `<group>` dengan group_id; `<node>` node1 untuk entry, node2 untuk exit.

| Topik | Pengirim → penerima |
|---|---|
| `parking/<group>/<node>/capture` | ESP32 → Python **node tersebut saja** |
| `parking/<group>/<node>/ocr_result` | Python → Node-RED **master** |
| `parking/<group>/<node>/feedback` | Master → ESP32 dan Python node tersebut |
| `parking/<group>/<node>/status` | ESP32 → master |
| `parking/<group>/<node>/python_status` | Python node tersebut → master |
| `parking/<group>/state` | Master → semua dashboard, retained |

Capture langsung dari ESP32; Node-RED tidak menerbitkan capture ulang.

```json
{"group_id":"kelompok-00","node_id":"node1","action":"entry","request_id":"node1-test-1","age_ms":0}
```
