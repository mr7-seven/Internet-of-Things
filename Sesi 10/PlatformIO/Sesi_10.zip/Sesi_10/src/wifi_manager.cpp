#include "wifi_manager.h"

WifiManager* WifiManager::instance_ = nullptr;

WifiManager::WifiManager(const char* ssid,
                         const char* password,
                         uint32_t reconnectIntervalMs,
                         uint32_t connectTimeoutMs)
    : ssid_(ssid),
      password_(password),
      reconnectIntervalMs_(reconnectIntervalMs),
      connectTimeoutMs_(connectTimeoutMs) {}

void WifiManager::begin() {
  instance_ = this;
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(false);
  WiFi.persistent(false);
  WiFi.onEvent(handleEvent);
  connect();
}

void WifiManager::loop() {
  if (connected()) return;

  const uint32_t now = millis();
  if (connecting_ && now - connectStartedMs_ >= connectTimeoutMs_) {
    connecting_ = false;
    WiFi.disconnect(false, false);
    Serial.println("[WIFI] Connection timeout");
  }

  if (!connecting_ && now - lastAttemptMs_ >= reconnectIntervalMs_) {
    connect();
  }
}

bool WifiManager::connected() const {
  return WiFi.status() == WL_CONNECTED;
}

void WifiManager::connect() {
  lastAttemptMs_ = millis();
  connectStartedMs_ = lastAttemptMs_;
  connecting_ = true;
  Serial.printf("[WIFI] Connecting to %s\n", ssid_);
  WiFi.begin(ssid_, password_);
}

void WifiManager::handleEvent(WiFiEvent_t event) {
  if (instance_ == nullptr) return;

  switch (event) {
    case ARDUINO_EVENT_WIFI_STA_GOT_IP:
      instance_->connecting_ = false;
      Serial.printf("[WIFI] Connected, IP: %s\n",
                    WiFi.localIP().toString().c_str());
      break;

    case ARDUINO_EVENT_WIFI_STA_DISCONNECTED:
      instance_->connecting_ = false;
      instance_->lastAttemptMs_ = millis();
      Serial.println("[WIFI] Disconnected");
      break;

    default:
      break;
  }
}

