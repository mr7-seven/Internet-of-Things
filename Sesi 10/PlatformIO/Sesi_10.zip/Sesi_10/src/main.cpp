#include <Arduino.h>
#include <ArduinoJson.h>
#include <SPI.h>
#include <WiFi.h>
#include <esp_system.h>
#include <cstring>
#include <MFRC522v2.h>
#include <MFRC522DriverSPI.h>
#include <MFRC522DriverPinSimple.h>
#include "app_config.h"
#include "wifi_manager.h"
#include "mqtt_manager.h"

WifiManager wifiManager(AppConfig::WIFI_SSID, AppConfig::WIFI_PASSWORD,
    AppConfig::WIFI_RECONNECT_INTERVAL_MS, AppConfig::WIFI_CONNECT_TIMEOUT_MS);
char scanTopic[128], statusTopic[128], ackTopic[128];
MqttManager mqttManager(AppConfig::MQTT_HOST, AppConfig::MQTT_PORT, ackTopic,
    AppConfig::MQTT_USERNAME, AppConfig::MQTT_PASSWORD,
    AppConfig::MQTT_RECONNECT_INTERVAL_MS, AppConfig::MQTT_CONNECT_TIMEOUT_MS);
MFRC522DriverPinSimple chipSelect(AppConfig::RFID_SS_PIN);
SPISettings rfidSettings(1000000, MSBFIRST, SPI_MODE0);
MFRC522DriverSPI rfidDriver(chipSelect, SPI, rfidSettings);
MFRC522 rfid(rfidDriver);

enum class ReaderMode { Scan, Register };
ReaderMode readerMode = ReaderMode::Scan;
bool readerReady = false, beepActive = false, statusDirty = true;
bool awaitingStatusAck = false;
bool rejectionActive = false, rejectionBeepOn = false;
uint8_t rejectionBeeps = 0;
uint32_t rejectionChangedAt = 0;
uint32_t beepStarted = 0, lastPoll = 0, lastUidAt = 0, lastStatusTx = 0;
uint32_t eventCounter = 0;
char bootId[17], clientId[128], lastUid[21] = "";
struct PendingScan {
  char eventId[96];
  char uid[21];
  uint32_t sentAt;
  ReaderMode mode;
  bool active;
};
PendingScan pendingScans[8] = {};
const uint32_t SCAN_ACK_TIMEOUT_MS = 30000;
portMUX_TYPE ackMux = portMUX_INITIALIZER_UNLOCKED;
char ackQueue[4][384];
uint8_t ackRead = 0, ackWrite = 0, ackCount = 0;
void setOutput(uint8_t pin, bool on, bool activeHigh);

void rememberScan(const char* eventId, const char* uid, ReaderMode mode, uint32_t now) {
  uint8_t slot = 0;
  uint32_t oldestAge = 0;
  for (uint8_t i = 0; i < 8; ++i) {
    if (!pendingScans[i].active || now - pendingScans[i].sentAt >= SCAN_ACK_TIMEOUT_MS) {
      slot = i;
      break;
    }
    const uint32_t age = now - pendingScans[i].sentAt;
    if (age >= oldestAge) { oldestAge = age; slot = i; }
  }
  PendingScan& scan = pendingScans[slot];
  snprintf(scan.eventId, sizeof(scan.eventId), "%s", eventId);
  snprintf(scan.uid, sizeof(scan.uid), "%s", uid);
  scan.sentAt = now;
  scan.mode = mode;
  scan.active = true;
}

PendingScan* findPendingScan(const char* eventId, uint32_t now) {
  if (!eventId[0]) return nullptr;
  for (uint8_t i = 0; i < 8; ++i) {
    PendingScan& scan = pendingScans[i];
    if (!scan.active) continue;
    if (now - scan.sentAt >= SCAN_ACK_TIMEOUT_MS) { scan.active = false; continue; }
    if (!strcmp(scan.eventId, eventId)) return &scan;
  }
  return nullptr;
}

void queueMqttAck(const char* topic, const char* payload) {
  if (!topic || !payload || strcmp(topic, ackTopic) != 0) return;
  const size_t length = strnlen(payload, sizeof(ackQueue[0]));
  if (length >= sizeof(ackQueue[0])) return;
  portENTER_CRITICAL(&ackMux);
  if (ackCount == 4) {
    ackRead = (ackRead + 1) % 4;
    --ackCount;
  }
  memcpy(ackQueue[ackWrite], payload, length + 1);
  ackWrite = (ackWrite + 1) % 4;
  ++ackCount;
  portEXIT_CRITICAL(&ackMux);
}
void processMqttAck() {
  char payload[384];
  portENTER_CRITICAL(&ackMux);
  const bool available = ackCount != 0;
  if (available) {
    memcpy(payload, ackQueue[ackRead], sizeof(payload));
    ackRead = (ackRead + 1) % 4;
    --ackCount;
  }
  portEXIT_CRITICAL(&ackMux);
  if (!available) return;
  JsonDocument doc;
  if (deserializeJson(doc, payload) || !doc.is<JsonObject>()) return;
  const char* group = doc["group_id"] | "";
  const char* node = doc["node_id"] | "";
  if (strcmp(group, AppConfig::GROUP_ID) || strcmp(node, AppConfig::NODE_ID)) return;
  const char* type = doc["type"] | "";
  const char* result = doc["result"] | "";
  if (strcmp(type, "status") == 0) {
    const char* mode = doc["mode"] | "";
    if (!strcmp(result, "RECEIVED") && !strcmp(mode, readerMode == ReaderMode::Scan ? "SCAN" : "REGISTER")) {
      awaitingStatusAck = false;
      Serial.printf("[ACK] Status diterima Node-RED | Mode: %s\n", mode);
    }
  } else if (strcmp(type, "scan") == 0) {
    const char* eventId = doc["event_id"] | "";
    const char* state = doc["state"] | "";
    PendingScan* scan = findPendingScan(eventId, millis());
    if (!scan) {
      Serial.printf("[ACK] Scan diabaikan, event_id tidak cocok atau kedaluwarsa: %s\n", eventId);
      return;
    }
    const bool scanMode = scan->mode == ReaderMode::Scan;
    Serial.printf("[ACK] UID=%s | Scan %s | Hasil: %s | Status: %s\n",
                  scan->uid, eventId, result, state);
    scan->active = false;
    if (scanMode &&
        (!strcmp(result, "UNKNOWN_UID") || !strcmp(result, "INACTIVE_UID"))) {
      rejectionActive = true;
      rejectionBeepOn = true;
      rejectionBeeps = 0;
      rejectionChangedAt = millis();
      beepActive = false;
      setOutput(AppConfig::BUZZER_PIN, true, AppConfig::BUZZER_ACTIVE_HIGH);
      Serial.printf("[RFID] Akses ditolak: %s\n", result);
    }
  }
}

const char* modeName() {
  return readerMode == ReaderMode::Scan ? "SCAN" : "REGISTER";
}
void setOutput(uint8_t pin, bool on, bool activeHigh) {
  digitalWrite(pin, on == activeHigh ? HIGH : LOW);
}
void beep() {
  if (rejectionActive) return;
  setOutput(AppConfig::BUZZER_PIN, true, AppConfig::BUZZER_ACTIVE_HIGH);
  beepStarted = millis();
  beepActive = true;
}
void updateBuzzer(uint32_t now) {
  if (rejectionActive) {
    if (now - rejectionChangedAt < AppConfig::BEEP_DURATION_MS) return;
    rejectionChangedAt = now;
    if (rejectionBeepOn) {
      setOutput(AppConfig::BUZZER_PIN, false, AppConfig::BUZZER_ACTIVE_HIGH);
      rejectionBeepOn = false;
      if (++rejectionBeeps == 3) rejectionActive = false;
    } else {
      setOutput(AppConfig::BUZZER_PIN, true, AppConfig::BUZZER_ACTIVE_HIGH);
      rejectionBeepOn = true;
    }
    return;
  }
  if (beepActive && now - beepStarted >= AppConfig::BEEP_DURATION_MS) {
    setOutput(AppConfig::BUZZER_PIN, false, AppConfig::BUZZER_ACTIVE_HIGH);
    beepActive = false;
  }
}
void updateLeds() {
  const bool fault = !readerReady || !mqttManager.connected();
  setOutput(AppConfig::LED_RED_PIN, fault || rejectionActive, AppConfig::LED_ACTIVE_HIGH);
  setOutput(AppConfig::LED_YELLOW_PIN, !rejectionActive && readerMode == ReaderMode::Register,
            AppConfig::LED_ACTIVE_HIGH);
  setOutput(AppConfig::LED_GREEN_PIN, !rejectionActive && readerMode == ReaderMode::Scan,
            AppConfig::LED_ACTIVE_HIGH);
}
void selectMode(ReaderMode mode) {
  readerMode = mode;
  lastUid[0] = '\0';
  statusDirty = true;
  beep();
  Serial.printf("[MODE] %s\n", modeName());
}
void updateButton(uint32_t now) {
  static bool rawPrevious = HIGH, stable = HIGH, longHandled = false;
  static uint32_t changedAt = 0, pressedAt = 0;
  const bool raw = digitalRead(AppConfig::BUTTON_PIN);
  if (raw != rawPrevious) { rawPrevious = raw; changedAt = now; }
  if (raw != stable && now - changedAt >= AppConfig::BUTTON_DEBOUNCE_MS) {
    stable = raw;
    if (stable == LOW) { pressedAt = now; longHandled = false; }
    else if (!longHandled) selectMode(ReaderMode::Scan);
  }
  if (stable == LOW && !longHandled && now - pressedAt >= AppConfig::BUTTON_LONG_PRESS_MS) {
    longHandled = true;
    selectMode(ReaderMode::Register);
  }
}
bool publishJson(const char* topic, const JsonDocument& doc) {
  char payload[512];
  if (measureJson(doc) >= sizeof(payload)) {
    Serial.println("[MQTT] Payload melebihi buffer");
    return false;
  }
  serializeJson(doc, payload, sizeof(payload));
  if (!mqttManager.publish(topic, payload, false)) return false;
  Serial.printf("[MQTT] TX %s: %s\n", topic, payload);
  return true;
}
void publishStatus(uint32_t now) {
  static bool wasConnected = false;
  const bool connected = mqttManager.connected();
  if (!connected) {
    wasConnected = false;
    awaitingStatusAck = false;
    return;
  }
  if (!wasConnected) {
    wasConnected = true;
    statusDirty = true;
  }
  if (!statusDirty && (!awaitingStatusAck || now - lastStatusTx < 5000)) return;
  static uint32_t lastAttempt = 0;
  if (now - lastAttempt < 250) return;
  lastAttempt = now;
  JsonDocument doc;
  doc["group_id"] = AppConfig::GROUP_ID;
  doc["node_id"] = AppConfig::NODE_ID;
  doc["status"] = "ONLINE";
  doc["mode"] = modeName();
  doc["reader_ready"] = readerReady;
  doc["rssi"] = WiFi.RSSI();
  doc["uptime_ms"] = now;
  if (publishJson(statusTopic, doc)) {
    statusDirty = false;
    awaitingStatusAck = true;
    lastStatusTx = now;
  }
}
void readRfid(uint32_t now) {
  if (!readerReady || now - lastPoll < AppConfig::RFID_POLL_MS) return;
  lastPoll = now;
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;
  char uid[21] = "";
  const uint8_t size = rfid.uid.size;
  if (size == 4 || size == 7 || size == 10) {
    for (uint8_t i = 0; i < size; ++i)
      snprintf(uid + i * 2, sizeof(uid) - i * 2, "%02X", rfid.uid.uidByte[i]);
  }
  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
  if (!uid[0]) return;
  if (strcmp(uid, lastUid) == 0 && now - lastUidAt < AppConfig::RFID_REPEAT_GUARD_MS) return;
  snprintf(lastUid, sizeof(lastUid), "%s", uid);
  lastUidAt = now;
  beep();
  Serial.printf("[RFID] UID=%s | MODE=%s\n", uid, modeName());
  if (!mqttManager.connected()) {
    Serial.println("[MQTT] Offline: tap tidak dikirim. Tap ulang setelah terhubung.");
    return;
  }
  char eventId[96];
  snprintf(eventId, sizeof(eventId), "%s-%s-%lu", AppConfig::NODE_ID, bootId,
           static_cast<unsigned long>(++eventCounter));
  JsonDocument doc;
  doc["group_id"] = AppConfig::GROUP_ID;
  doc["node_id"] = AppConfig::NODE_ID;
  doc["uid"] = uid;
  doc["mode"] = modeName();
  doc["event_id"] = eventId;
  if (publishJson(scanTopic, doc)) rememberScan(eventId, uid, readerMode, now);
  else Serial.println("[MQTT] Gagal memasukkan pesan ke antrean kirim");
}
void setup() {
  Serial.begin(115200);
  for (uint8_t pin : {AppConfig::LED_RED_PIN, AppConfig::LED_YELLOW_PIN, AppConfig::LED_GREEN_PIN}) {
    pinMode(pin, OUTPUT);
    setOutput(pin, false, AppConfig::LED_ACTIVE_HIGH);
  }
  pinMode(AppConfig::BUZZER_PIN, OUTPUT);
  setOutput(AppConfig::BUZZER_PIN, false, AppConfig::BUZZER_ACTIVE_HIGH);
  pinMode(AppConfig::BUTTON_PIN, INPUT_PULLUP);
  pinMode(AppConfig::RFID_RST_PIN, OUTPUT);
  // Jeda hanya untuk reset hardware sekali saat boot; loop memakai millis.
  digitalWrite(AppConfig::RFID_RST_PIN, LOW);
  delay(2);
  digitalWrite(AppConfig::RFID_RST_PIN, HIGH);
  delay(50);
  SPI.begin(AppConfig::RFID_SCK_PIN, AppConfig::RFID_MISO_PIN,
            AppConfig::RFID_MOSI_PIN, AppConfig::RFID_SS_PIN);
  rfid.PCD_Init();
  const uint8_t version = rfidDriver.PCD_ReadRegister(MFRC522Constants::VersionReg);
  readerReady = version != 0x00 && version != 0xFF;
  Serial.printf("[RFID] Version=0x%02X | %s\n", version, readerReady ? "READY" : "PERIKSA KABEL / 3.3V");
  snprintf(scanTopic, sizeof(scanTopic), "webgis/%s/rfid/scan", AppConfig::GROUP_ID);
  snprintf(statusTopic, sizeof(statusTopic), "webgis/%s/node/%s/status", AppConfig::GROUP_ID, AppConfig::NODE_ID);
  snprintf(ackTopic, sizeof(ackTopic), "webgis/%s/node/%s/ack", AppConfig::GROUP_ID, AppConfig::NODE_ID);
  wifiManager.begin();
  snprintf(bootId, sizeof(bootId), "%08lX%08lX", static_cast<unsigned long>(esp_random()),
           static_cast<unsigned long>(esp_random()));
  snprintf(clientId, sizeof(clientId), "gis-%s-%s-%s-%s", AppConfig::GROUP_ID,
           AppConfig::NODE_ID, AppConfig::NIM, bootId);
  mqttManager.setCallback(queueMqttAck);
  mqttManager.begin(clientId);
  Serial.printf("[MQTT] Client ID=%s\n[MODE] %s\n", clientId, modeName());
  updateLeds();
}
void loop() {
  const uint32_t now = millis();
  wifiManager.loop();
  mqttManager.loop(wifiManager.connected());
  for (uint8_t i = 0; i < 4; ++i) processMqttAck();
  updateButton(now);
  updateBuzzer(now);
  updateLeds();
  publishStatus(now);
  readRfid(now);
}
