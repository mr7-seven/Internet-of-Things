#include "mqtt_manager.h"

#include <cstring>
#include <utility>

MqttManager::MqttManager(const char* host,
                         uint16_t port,
                         const char* subscribeTopic,
                         const char* username,
                         const char* password,
                         uint32_t reconnectIntervalMs,
                         uint32_t connectTimeoutMs)
    : host_(host),
      port_(port),
      subscribeTopic_(subscribeTopic),
      username_(username),
      password_(password),
      reconnectIntervalMs_(reconnectIntervalMs),
      connectTimeoutMs_(connectTimeoutMs) {}

void MqttManager::begin(const char* clientId) {
  client_.setServer(host_, port_);
  client_.setClientId(clientId);

  if (username_ != nullptr && std::strlen(username_) > 0) {
    client_.setCredentials(username_, password_ == nullptr ? "" : password_);
  }

  client_.onConnect([this](bool sessionPresent) {
    onConnect(sessionPresent);
  });
  client_.onDisconnect([this](AsyncMqttClientDisconnectReason reason) {
    onDisconnect(reason);
  });
  client_.onMessage(
      [this](char* topic, char* payload,
             AsyncMqttClientMessageProperties properties, size_t length,
             size_t index, size_t total) {
        onMessage(topic, payload, properties, length, index, total);
      });
}

void MqttManager::loop(bool networkAvailable) {
  const uint32_t now = millis();

  if (!networkAvailable) {
    networkWasAvailable_ = false;
    connecting_ = false;
    return;
  }

  if (!networkWasAvailable_) {
    networkWasAvailable_ = true;
    lastAttemptMs_ = now - reconnectIntervalMs_;
  }

  if (connected()) return;

  if (connecting_ && now - connectStartedMs_ >= connectTimeoutMs_) {
    connecting_ = false;
    lastAttemptMs_ = now;
    Serial.println("[MQTT] Connection timeout");
  }

  if (!connecting_ && now - lastAttemptMs_ >= reconnectIntervalMs_) {
    connect();
  }
}

void MqttManager::setCallback(MessageCallback callback) {
  callback_ = std::move(callback);
}

bool MqttManager::publish(const char* topic,
                          const char* payload,
                          bool retain) {
  if (!connected() || topic == nullptr || payload == nullptr) return false;

  const uint16_t packetId =
      client_.publish(topic, 0, retain, payload, std::strlen(payload));
  return packetId != 0;
}

bool MqttManager::connected() const {
  return client_.connected();
}

void MqttManager::connect() {
  lastAttemptMs_ = millis();
  connectStartedMs_ = lastAttemptMs_;
  connecting_ = true;
  Serial.printf("[MQTT] Connecting to %s:%u\n", host_, port_);
  client_.connect();
}

void MqttManager::onConnect(bool sessionPresent) {
  connecting_ = false;
  Serial.printf("[MQTT] Connected, session: %s\n",
                sessionPresent ? "present" : "new");
  client_.subscribe(subscribeTopic_, 0);
  Serial.printf("[MQTT] Subscribed: %s\n", subscribeTopic_);
}

void MqttManager::onDisconnect(AsyncMqttClientDisconnectReason reason) {
  connecting_ = false;
  lastAttemptMs_ = millis();
  Serial.printf("[MQTT] Disconnected, reason: %u\n",
                static_cast<unsigned int>(reason));
}

void MqttManager::onMessage(char* topic,
                            char* payload,
                            AsyncMqttClientMessageProperties properties,
                            size_t length,
                            size_t index,
                            size_t total) {
  (void)properties;

  if (index == 0) {
    incomingTopic_ = topic == nullptr ? "" : topic;
    incomingPayload_ = "";
    incomingPayload_.reserve(total + 1);
    incomingTotal_ = total;
  }

  for (size_t i = 0; i < length; ++i) {
    incomingPayload_ += payload[i];
  }

  if (index + length == incomingTotal_ && callback_) {
    callback_(incomingTopic_.c_str(), incomingPayload_.c_str());
  }
}

