#pragma once

#include <Arduino.h>
#include <WiFi.h>

class WifiManager {
 public:
  WifiManager(const char* ssid,
              const char* password,
              uint32_t reconnectIntervalMs,
              uint32_t connectTimeoutMs);

  void begin();
  void loop();
  bool connected() const;

 private:
  static WifiManager* instance_;
  static void handleEvent(WiFiEvent_t event);

  void connect();

  const char* ssid_;
  const char* password_;
  uint32_t reconnectIntervalMs_;
  uint32_t connectTimeoutMs_;
  uint32_t lastAttemptMs_ = 0;
  uint32_t connectStartedMs_ = 0;
  bool connecting_ = false;
};

