#pragma once

#include <Arduino.h>
#include <AsyncMqttClient.h>
#include <functional>

class MqttManager {
 public:
  using MessageCallback = std::function<void(const char*, const char*)>;

  MqttManager(const char* host,
              uint16_t port,
              const char* subscribeTopic,
              const char* username,
              const char* password,
              uint32_t reconnectIntervalMs,
              uint32_t connectTimeoutMs);

  void begin(const char* clientId);
  void loop(bool networkAvailable);
  void setCallback(MessageCallback callback);
  bool publish(const char* topic, const char* payload, bool retain = false);
  bool connected() const;

 private:
  void connect();
  void onConnect(bool sessionPresent);
  void onDisconnect(AsyncMqttClientDisconnectReason reason);
  void onMessage(char* topic,
                 char* payload,
                 AsyncMqttClientMessageProperties properties,
                 size_t length,
                 size_t index,
                 size_t total);

  AsyncMqttClient client_;
  const char* host_;
  uint16_t port_;
  const char* subscribeTopic_;
  const char* username_;
  const char* password_;
  uint32_t reconnectIntervalMs_;
  uint32_t connectTimeoutMs_;
  uint32_t lastAttemptMs_ = 0;
  uint32_t connectStartedMs_ = 0;
  bool connecting_ = false;
  bool networkWasAvailable_ = false;
  String incomingTopic_;
  String incomingPayload_;
  size_t incomingTotal_ = 0;
  MessageCallback callback_;
};

