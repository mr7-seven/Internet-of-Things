#pragma once
#include <Arduino.h>

namespace AppConfig {
constexpr char WIFI_SSID[] = "IoT";
constexpr char WIFI_PASSWORD[] = "1234567890";
constexpr char MQTT_HOST[] = "broker.hivemq.com";
constexpr uint16_t MQTT_PORT = 1883;
constexpr char MQTT_USERNAME[] = "";
constexpr char MQTT_PASSWORD[] = "";
constexpr char GROUP_ID[] = "kelompok-00";
constexpr char NODE_ID[] = "node-00";
constexpr char NIM[] = "12345";
static_assert(sizeof(GROUP_ID) <= 25, "GROUP_ID maksimal 24 karakter");
static_assert(sizeof(NODE_ID) <= 25, "NODE_ID maksimal 24 karakter");
static_assert(sizeof(NIM) <= 25, "NIM maksimal 24 karakter");

constexpr uint32_t WIFI_RECONNECT_INTERVAL_MS = 3000;
constexpr uint32_t WIFI_CONNECT_TIMEOUT_MS = 10000;
constexpr uint32_t MQTT_RECONNECT_INTERVAL_MS = 5000;
constexpr uint32_t MQTT_CONNECT_TIMEOUT_MS = 10000;
constexpr uint32_t HEARTBEAT_INTERVAL_MS = 5000;
constexpr uint32_t BUTTON_DEBOUNCE_MS = 40;
constexpr uint32_t BUTTON_LONG_PRESS_MS = 3000;
constexpr uint32_t RFID_POLL_MS = 30;
constexpr uint32_t RFID_REPEAT_GUARD_MS = 2200;
constexpr uint32_t BEEP_DURATION_MS = 200;

constexpr uint8_t RFID_SS_PIN = 5;
constexpr uint8_t RFID_RST_PIN = 22;
constexpr uint8_t RFID_SCK_PIN = 18;
constexpr uint8_t RFID_MISO_PIN = 19;
constexpr uint8_t RFID_MOSI_PIN = 23;
constexpr uint8_t LED_RED_PIN = 25;
constexpr uint8_t LED_YELLOW_PIN = 26;
constexpr uint8_t LED_GREEN_PIN = 27;
constexpr uint8_t BUZZER_PIN = 32;
constexpr uint8_t BUTTON_PIN = 33;
constexpr bool LED_ACTIVE_HIGH = true;
constexpr bool BUZZER_ACTIVE_HIGH = true;
}
