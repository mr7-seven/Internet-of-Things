#pragma once

#include <Arduino.h>

#ifndef AQUAPONIC_NODE_ROLE
#define AQUAPONIC_NODE_ROLE 1
#endif

namespace AppConfig {

constexpr char WIFI_SSID[] = "GANTI_NAMA_WIFI";
constexpr char WIFI_PASSWORD[] = "GANTI_PASSWORD_WIFI";

constexpr char MQTT_HOST[] = "broker.emqx.io";
constexpr uint16_t MQTT_PORT = 1883;
constexpr char MQTT_USERNAME[] = "";
constexpr char MQTT_PASSWORD[] = "";

constexpr char GROUP_ID[] = "kelompok-00";
constexpr char MQTT_TOPIC_ROOT[] = "aquaponic";

#if AQUAPONIC_NODE_ROLE == 1

constexpr char NODE_ID[] = "node-perikanan";
constexpr char NODE_TYPE[] = "fisheries";

#elif AQUAPONIC_NODE_ROLE == 2

constexpr char NODE_ID[] = "node-hidroponik";
constexpr char NODE_TYPE[] = "hydroponic";

#elif AQUAPONIC_NODE_ROLE == 3

constexpr char NODE_ID[] = "node-energi";
constexpr char NODE_TYPE[] = "energy";

#else

#error "AQUAPONIC_NODE_ROLE harus bernilai 1, 2, atau 3"

#endif

constexpr uint8_t BUTTON_PIN = 33;
constexpr bool BUTTON_ACTIVE_LOW = true;
constexpr bool DEFAULT_MACHINE_ON = false;
constexpr uint32_t BUTTON_DEBOUNCE_MS = 40;

constexpr uint32_t TELEMETRY_INTERVAL_MS = 5000;

constexpr uint32_t WIFI_RECONNECT_INTERVAL_MS = 3000;
constexpr uint32_t WIFI_CONNECT_TIMEOUT_MS = 10000;

constexpr uint32_t MQTT_RECONNECT_INTERVAL_MS = 5000;
constexpr uint32_t MQTT_CONNECT_TIMEOUT_MS = 10000;

}