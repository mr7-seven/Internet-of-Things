# ESP32 Aquaponic Solar Multinode

Satu source code untuk tiga ESP32. Environment PlatformIO menentukan identitas dan parameter node.

## Konfigurasi

Ubah Wi-Fi, broker, dan `GROUP_ID` pada `include/app_config.h`. Semua ESP32 milik satu kelompok harus menggunakan `GROUP_ID` yang sama. Kredensial MQTT boleh dibiarkan kosong jika broker tidak memakai autentikasi.

Push button memakai GPIO 33 ke GND dengan `INPUT_PULLUP`. Setiap tekan akan men-toggle status mesin ON/OFF. Telemetri dikirim setiap 5 detik menggunakan `millis()`.

## Build dan upload

```bash
pio run -e node_kolam
pio run -e node_kolam -t upload

pio run -e node_hidroponik -t upload
pio run -e node_solar -t upload
```

Gunakan `pio device monitor -b 115200` untuk Serial Monitor.

## MQTT

| Environment | Publish topic | Subscribe topic |
| --- | --- | --- |
| `node_kolam` | `aquaponic/kelompok-01/node-kolam/telemetry` | `aquaponic/kelompok-01/node-kolam/command` |
| `node_hidroponik` | `aquaponic/kelompok-01/node-hidroponik/telemetry` | `aquaponic/kelompok-01/node-hidroponik/command` |
| `node_solar` | `aquaponic/kelompok-01/node-solar/telemetry` | `aquaponic/kelompok-01/node-solar/command` |

Perintah MQTT opsional:

```json
{"machine_status":"ON"}
```

Status dari tombol dan perintah MQTT memakai state yang sama. Data simulasi memakai bounded random walk agar perubahan antarsampel halus dan cocok divisualisasikan di Grafana.

Subscribe seluruh node dalam satu kelompok di Node-RED:

```text
aquaponic/kelompok-01/+/telemetry
```

Subscribe seluruh kelompok dan seluruh node:

```text
aquaponic/+/+/telemetry
```

Timestamp sebaiknya ditambahkan oleh Node-RED atau database ketika pesan diterima karena ESP32 pada template ini tidak menjalankan sinkronisasi NTP.
