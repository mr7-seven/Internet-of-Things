#include <Arduino.h>
#include <ArduinoJson.h>
#include <esp_system.h>
#include <cstring>

#include "app_config.h"
#include "mqtt_manager.h"
#include "wifi_manager.h"

namespace {
char telemetryTopic[96] = {};
char commandTopic[96] = {};
char clientId[80] = {};

WifiManager wifiManager(AppConfig::WIFI_SSID,
                        AppConfig::WIFI_PASSWORD,
                        AppConfig::WIFI_RECONNECT_INTERVAL_MS,
                        AppConfig::WIFI_CONNECT_TIMEOUT_MS);

MqttManager mqttManager(AppConfig::MQTT_HOST,
                        AppConfig::MQTT_PORT,
                        commandTopic,
                        AppConfig::MQTT_USERNAME,
                        AppConfig::MQTT_PASSWORD,
                        AppConfig::MQTT_RECONNECT_INTERVAL_MS,
                        AppConfig::MQTT_CONNECT_TIMEOUT_MS);

bool machineOn = AppConfig::DEFAULT_MACHINE_ON;
bool rawButtonPressed = false;
bool stableButtonPressed = false;
uint32_t buttonChangedMs = 0;
uint32_t lastTelemetryMs = 0;
uint32_t sequenceNumber = 0;

float pondDo = 6.40F;
float pondPh = 7.00F;
float pondWaterTemp = 27.00F;
float pondAmmonia = 0.08F;

float hydroPh = 6.20F;
float hydroTds = 850.0F;
float hydroWaterTemp = 26.00F;
float hydroWaterLevel = 72.0F;

float pvPower = 285.0F;
float batterySoc = 78.0F;
float batteryVoltage = 13.10F;
float loadPower = 95.0F;
float energyKwh = 1.250F;

float clampValue(float value, float minimum, float maximum) {
  if (value < minimum) return minimum;
  if (value > maximum) return maximum;
  return value;
}

float randomWalk(float value, float step, float minimum, float maximum) {
  const float delta = static_cast<float>(random(-1000, 1001)) / 1000.0F;
  return clampValue(value + delta * step, minimum, maximum);
}

float roundTo(float value, float multiplier) {
  return roundf(value * multiplier) / multiplier;
}

bool readButtonPressed() {
  const bool pinHigh = digitalRead(AppConfig::BUTTON_PIN) == HIGH;
  return AppConfig::BUTTON_ACTIVE_LOW ? !pinHigh : pinHigh;
}

void updateButton(uint32_t now) {
  const bool pressed = readButtonPressed();

  if (pressed != rawButtonPressed) {
    rawButtonPressed = pressed;
    buttonChangedMs = now;
  }

  if (now - buttonChangedMs < AppConfig::BUTTON_DEBOUNCE_MS ||
      stableButtonPressed == rawButtonPressed) {
    return;
  }

  stableButtonPressed = rawButtonPressed;
  if (stableButtonPressed) {
    machineOn = !machineOn;
    lastTelemetryMs = now - AppConfig::TELEMETRY_INTERVAL_MS;
    Serial.printf("[BUTTON] Machine: %s\n", machineOn ? "ON" : "OFF");
  }
}

void updateSimulation() {
#if AQUAPONIC_NODE_ROLE == 1
  pondDo = randomWalk(pondDo, machineOn ? 0.10F : 0.05F, 3.50F, 9.00F);
  pondPh = randomWalk(pondPh, 0.025F, 6.40F, 7.60F);
  pondWaterTemp = randomWalk(pondWaterTemp, 0.08F, 24.00F, 31.00F);
  pondAmmonia = randomWalk(pondAmmonia, machineOn ? 0.008F : 0.015F, 0.00F, 0.80F);
#elif AQUAPONIC_NODE_ROLE == 2
  hydroPh = randomWalk(hydroPh, 0.025F, 5.50F, 7.00F);
  hydroTds = randomWalk(hydroTds, 8.0F, 550.0F, 1300.0F);
  hydroWaterTemp = randomWalk(hydroWaterTemp, 0.08F, 23.00F, 30.00F);
  hydroWaterLevel = randomWalk(hydroWaterLevel, machineOn ? 0.30F : 0.70F, 25.0F, 95.0F);
#elif AQUAPONIC_NODE_ROLE == 3
  pvPower = randomWalk(pvPower, 10.0F, 0.0F, 500.0F);
  batterySoc = randomWalk(batterySoc, machineOn ? 0.30F : 0.15F, 20.0F, 100.0F);
  batteryVoltage = randomWalk(batteryVoltage, 0.04F, 11.80F, 14.40F);
  loadPower = randomWalk(loadPower, machineOn ? 4.0F : 1.0F, 5.0F, 250.0F);
  energyKwh += pvPower * (AppConfig::TELEMETRY_INTERVAL_MS / 3600000.0F) / 1000.0F;
#endif
}

void addNodeParameters(JsonDocument& document) {
#if AQUAPONIC_NODE_ROLE == 1
  document["do_mg_l"] = roundTo(pondDo, 100.0F);
  document["ph"] = roundTo(pondPh, 100.0F);
  document["water_temp_c"] = roundTo(pondWaterTemp, 100.0F);
  document["ammonia_mg_l"] = roundTo(pondAmmonia, 1000.0F);
  document["aerator_status"] = machineOn ? "ON" : "OFF";
#elif AQUAPONIC_NODE_ROLE == 2
  document["ph"] = roundTo(hydroPh, 100.0F);
  document["tds_ppm"] = roundTo(hydroTds, 1.0F);
  document["water_temp_c"] = roundTo(hydroWaterTemp, 100.0F);
  document["water_level_pct"] = roundTo(hydroWaterLevel, 10.0F);
  document["pump_status"] = machineOn ? "ON" : "OFF";
#elif AQUAPONIC_NODE_ROLE == 3
  document["pv_power_w"] = roundTo(pvPower, 10.0F);
  document["battery_soc_pct"] = roundTo(batterySoc, 10.0F);
  document["battery_voltage_v"] = roundTo(batteryVoltage, 100.0F);
  document["load_power_w"] = roundTo(loadPower, 10.0F);
  document["energy_kwh"] = roundTo(energyKwh, 1000.0F);
#endif
}

void publishTelemetry() {
  updateSimulation();

  JsonDocument document;
  document["group_id"] = AppConfig::GROUP_ID;
  document["node_id"] = AppConfig::NODE_ID;
  document["node_type"] = AppConfig::NODE_TYPE;
  document["machine_status"] = machineOn ? "ON" : "OFF";
  document["sequence"] = ++sequenceNumber;
  document["uptime_ms"] = millis();
  addNodeParameters(document);

  char payload[384] = {};
  const size_t length = serializeJson(document, payload, sizeof(payload));
  if (length == 0 || length >= sizeof(payload) - 1) {
    Serial.println("[MQTT] Payload buffer terlalu kecil");
    return;
  }

  if (mqttManager.publish(telemetryTopic, payload)) {
    Serial.printf("[MQTT] TX %s: %s\n", telemetryTopic, payload);
  }
}

void handleMqttMessage(const char* topic, const char* payload) {
  JsonDocument document;
  const DeserializationError error = deserializeJson(document, payload);
  if (error) {
    Serial.printf("[MQTT] Invalid JSON: %s\n", error.c_str());
    return;
  }

  const char* requestedState = document["machine_status"] | "";
  if (strcmp(requestedState, "ON") == 0) {
    machineOn = true;
  } else if (strcmp(requestedState, "OFF") == 0) {
    machineOn = false;
  } else {
    Serial.println("[COMMAND] Expected: {\"machine_status\":\"ON\"}");
    return;
  }

  lastTelemetryMs = millis() - AppConfig::TELEMETRY_INTERVAL_MS;
  Serial.printf("[COMMAND] %s from %s\n", requestedState, topic);
}
}

void setup() {
  Serial.begin(115200);
  pinMode(AppConfig::BUTTON_PIN,
          AppConfig::BUTTON_ACTIVE_LOW ? INPUT_PULLUP : INPUT_PULLDOWN);

  const uint64_t chipId = ESP.getEfuseMac();
  const uint32_t randomPart = esp_random();
  snprintf(telemetryTopic, sizeof(telemetryTopic), "%s/%s/%s/telemetry",
           AppConfig::MQTT_TOPIC_ROOT,
           AppConfig::GROUP_ID,
           AppConfig::NODE_ID);
  snprintf(commandTopic, sizeof(commandTopic), "%s/%s/%s/command",
           AppConfig::MQTT_TOPIC_ROOT,
           AppConfig::GROUP_ID,
           AppConfig::NODE_ID);
  snprintf(clientId, sizeof(clientId), "ESP32-%s-%s-%04X-%08lX",
           AppConfig::GROUP_ID,
           AppConfig::NODE_ID,
           static_cast<unsigned int>(chipId & 0xFFFFU),
           static_cast<unsigned long>(randomPart));

  randomSeed(randomPart ^ static_cast<uint32_t>(chipId));
  rawButtonPressed = readButtonPressed();
  stableButtonPressed = rawButtonPressed;

  Serial.printf("[SYSTEM] Node: %s (%s)\n", AppConfig::NODE_ID, AppConfig::NODE_TYPE);
  Serial.printf("[SYSTEM] Client ID: %s\n", clientId);
  Serial.printf("[SYSTEM] Telemetry: %s\n", telemetryTopic);
  Serial.printf("[SYSTEM] Command: %s\n", commandTopic);

  mqttManager.setCallback(handleMqttMessage);
  mqttManager.begin(clientId);
  wifiManager.begin();
}

void loop() {
  wifiManager.loop();
  mqttManager.loop(wifiManager.connected());

  const uint32_t now = millis();
  updateButton(now);

  if (mqttManager.connected() &&
      now - lastTelemetryMs >= AppConfig::TELEMETRY_INTERVAL_MS) {
    lastTelemetryMs = now;
    publishTelemetry();
  }
}
