# ESP32 Wi-Fi MQTT Template

Template PlatformIO untuk ESP32 dengan koneksi Wi-Fi dan MQTT non-blocking,
reconnect berbasis event/millis, ArduinoJson 7, autentikasi opsional, data sensor
acak, dan kontrol LED traffic light.

## Konfigurasi

Ubah hanya `include/app_config.h` untuk proyek baru:

- `WIFI_SSID` dan `WIFI_PASSWORD`
- `MQTT_HOST` dan `MQTT_PORT`
- `MQTT_USERNAME` dan `MQTT_PASSWORD` jika broker memakai autentikasi
- `NIM`
- `MQTT_SENSOR_TOPIC_PREFIX` dan `MQTT_ACTUATOR_TOPIC_PREFIX` jika diperlukan

Topik otomatis dibentuk dari prefix dan `NIM`, sehingga perubahan NIM tidak
perlu diulang pada bagian lain.

Jika broker tanpa autentikasi, biarkan username dan password kosong.

## MQTT

Data sensor dikirim setiap 1 detik:

```json
{"node_id":"12345","temperature":28.42,"humidity":65.17}
```

Kontrol LED:

```json
{"color":"red","state":"ON"}
```

Nilai `color`: `red`, `yellow`, atau `green`. Nilai `state`: `ON` atau `OFF`.

## Perintah

```bash
pio run
pio run -t upload
pio device monitor
```

## Jika sebelumnya pernah memakai Core 3

Apabila muncul `Network.h: No such file or directory`, paket framework global
PlatformIO sedang tercampur atau tidak lengkap. Tutup VS Code, hapus folder:

```text
C:\Users\<username>\.platformio\packages\framework-arduinoespressif32
```

Hapus juga folder `.pio` di dalam proyek, kemudian jalankan kembali:

```bash
pio run
```

PlatformIO akan mengunduh ulang Arduino-ESP32 2.0.17 sesuai versi yang dikunci
di `platformio.ini`.

Template menjalankan `scripts/check_esp32_framework.py` sebelum proses compile.
Pemeriksaan ini menampilkan versi Core yang benar-benar digunakan dan
menghentikan build dengan pesan yang jelas jika Core bukan versi 2 atau paket
framework terdeteksi tercampur.

Konfigurasi `app_config.h` memakai `constexpr` standar C++11 sehingga tidak
memerlukan `inline constexpr` atau flag C++17 pada Arduino-ESP32 Core 2.
