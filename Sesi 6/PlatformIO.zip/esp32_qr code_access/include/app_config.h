#pragma once

#include <Arduino.h>

namespace AppConfig {
constexpr char WIFI_SSID[] = "NAMA_WIFI";
constexpr char WIFI_PASSWORD[] = "PASSWORD_WIFI";

constexpr char MQTT_HOST[] = "broker.emqx.io";
constexpr uint16_t MQTT_PORT = 1883;
constexpr char MQTT_USERNAME[] = "";
constexpr char MQTT_PASSWORD[] = "";

constexpr char NIM[] = "NIM MAHASISWA";
constexpr char MQTT_ACTUATOR_TOPIC_PREFIX[] = "data/iot/actuator/";
constexpr char MQTT_FEEDBACK_TOPIC_PREFIX[] = "data/iot/status/";

constexpr uint32_t WIFI_RECONNECT_INTERVAL_MS = 5000;
constexpr uint32_t WIFI_CONNECT_TIMEOUT_MS = 15000;
constexpr uint32_t MQTT_RECONNECT_INTERVAL_MS = 5000;
constexpr uint32_t MQTT_CONNECT_TIMEOUT_MS = 10000;

constexpr uint8_t LED_RED_PIN = 25;
constexpr uint8_t LED_YELLOW_PIN = 26;
constexpr uint8_t LED_GREEN_PIN = 27;
constexpr uint8_t BUZZER_PIN = 33;
constexpr bool BUZZER_ACTIVE_HIGH = true;

constexpr uint32_t BUZZER_ON_MS = 200;
constexpr uint32_t BUZZER_OFF_MS = 200;
constexpr uint32_t GRANTED_ACTIVE_MS = 10000;
constexpr uint32_t DENIED_HOLD_MS = 1000;
constexpr uint8_t DENIED_BEEP_COUNT = 3;
}

