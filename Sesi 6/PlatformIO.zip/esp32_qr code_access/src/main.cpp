#include <Arduino.h>
#include <ArduinoJson.h>
#include <esp_system.h>
#include <cstring>

#include "app_config.h"
#include "mqtt_manager.h"
#include "wifi_manager.h"

namespace {
enum class AccessState : uint8_t {
  STANDBY,
  GRANTED_ENTRY_BEEP,
  GRANTED_ACTIVE,
  GRANTED_EXIT_BEEP,
  DENIED_BEEP_ON,
  DENIED_BEEP_OFF,
  DENIED_HOLD
};

char actuatorTopic[96] = {};
char feedbackTopic[96] = {};
char clientId[64] = {};
AccessState accessState = AccessState::STANDBY;
uint32_t stateStartedMs = 0;
uint8_t deniedBeepCompleted = 0;
String activeEventId;
bool standbyFeedbackPending = false;

WifiManager wifiManager(AppConfig::WIFI_SSID,
                        AppConfig::WIFI_PASSWORD,
                        AppConfig::WIFI_RECONNECT_INTERVAL_MS,
                        AppConfig::WIFI_CONNECT_TIMEOUT_MS);

MqttManager mqttManager(AppConfig::MQTT_HOST,
                        AppConfig::MQTT_PORT,
                        actuatorTopic,
                        AppConfig::MQTT_USERNAME,
                        AppConfig::MQTT_PASSWORD,
                        AppConfig::MQTT_RECONNECT_INTERVAL_MS,
                        AppConfig::MQTT_CONNECT_TIMEOUT_MS);

void setBuzzer(bool active) {
  const uint8_t level =
      active == AppConfig::BUZZER_ACTIVE_HIGH ? HIGH : LOW;
  digitalWrite(AppConfig::BUZZER_PIN, level);
}

void setLeds(bool red, bool yellow, bool green) {
  digitalWrite(AppConfig::LED_RED_PIN, red ? HIGH : LOW);
  digitalWrite(AppConfig::LED_YELLOW_PIN, yellow ? HIGH : LOW);
  digitalWrite(AppConfig::LED_GREEN_PIN, green ? HIGH : LOW);
}

void enterStandby(bool sendFeedback = true) {
  setBuzzer(false);
  setLeds(false, true, false);
  accessState = AccessState::STANDBY;
  stateStartedMs = millis();
  if (sendFeedback) standbyFeedbackPending = true;
  Serial.println("[ACCESS] Standby");
}

void startGranted() {
  setLeds(false, false, true);
  setBuzzer(true);
  accessState = AccessState::GRANTED_ENTRY_BEEP;
  stateStartedMs = millis();
  Serial.println("[ACCESS] Granted");
}

void startDenied() {
  setLeds(true, false, false);
  setBuzzer(true);
  deniedBeepCompleted = 0;
  accessState = AccessState::DENIED_BEEP_ON;
  stateStartedMs = millis();
  Serial.println("[ACCESS] Denied");
}

struct AccessCommand {
  String access;
  String eventId;
};

AccessCommand readAccessCommand(const char* payload) {
  JsonDocument document;
  const DeserializationError error = deserializeJson(document, payload);
  AccessCommand command;

  if (!error) {
    const char* value = document["access"] | "";
    if (value[0] == '\0') value = document["status"] | "";
    if (value[0] == '\0') value = document["result"] | "";
    if (value[0] == '\0') value = document["color"] | "";
    command.access = value;
    command.eventId = static_cast<const char*>(document["event_id"] | "");
    if (command.eventId.isEmpty()) {
      command.eventId = static_cast<const char*>(document["eventId"] | "");
    }
  } else {
    command.access = payload;
  }

  command.access.trim();
  command.access.toUpperCase();
  command.eventId.trim();
  if (command.access == "GREEN") command.access = "GRANTED";
  if (command.access == "RED") command.access = "DENIED";
  return command;
}

void handleMqttMessage(const char* topic, const char* payload) {
  const AccessCommand command = readAccessCommand(payload);

  if (command.access == "GRANTED") {
    activeEventId = command.eventId;
    standbyFeedbackPending = false;
    startGranted();
  } else if (command.access == "DENIED") {
    activeEventId = command.eventId;
    standbyFeedbackPending = false;
    startDenied();
  } else {
    Serial.printf("[ACCESS] Invalid command from %s: %s\n", topic, payload);
  }
}

void publishStandbyFeedback() {
  if (!standbyFeedbackPending || !mqttManager.connected()) return;

  JsonDocument document;
  document["device"] = "access_control";
  document["node_id"] = AppConfig::NIM;
  document["status"] = "STANDBY";
  document["event_id"] = activeEventId;

  char payload[192] = {};
  serializeJson(document, payload, sizeof(payload));

  if (mqttManager.publish(feedbackTopic, payload)) {
    standbyFeedbackPending = false;
    Serial.printf("[MQTT] Feedback %s: %s\n", feedbackTopic, payload);
  }
}

void updateAccessSequence() {
  const uint32_t now = millis();
  const uint32_t elapsed = now - stateStartedMs;

  switch (accessState) {
    case AccessState::STANDBY:
      break;

    case AccessState::GRANTED_ENTRY_BEEP:
      if (elapsed >= AppConfig::BUZZER_ON_MS) {
        setBuzzer(false);
        accessState = AccessState::GRANTED_ACTIVE;
        stateStartedMs = now;
      }
      break;

    case AccessState::GRANTED_ACTIVE:
      if (elapsed >= AppConfig::GRANTED_ACTIVE_MS) {
        setBuzzer(true);
        accessState = AccessState::GRANTED_EXIT_BEEP;
        stateStartedMs = now;
      }
      break;

    case AccessState::GRANTED_EXIT_BEEP:
      if (elapsed >= AppConfig::BUZZER_ON_MS) enterStandby(true);
      break;

    case AccessState::DENIED_BEEP_ON:
      if (elapsed >= AppConfig::BUZZER_ON_MS) {
        setBuzzer(false);
        ++deniedBeepCompleted;
        stateStartedMs = now;
        accessState = deniedBeepCompleted >= AppConfig::DENIED_BEEP_COUNT
                          ? AccessState::DENIED_HOLD
                          : AccessState::DENIED_BEEP_OFF;
      }
      break;

    case AccessState::DENIED_BEEP_OFF:
      if (elapsed >= AppConfig::BUZZER_OFF_MS) {
        setBuzzer(true);
        accessState = AccessState::DENIED_BEEP_ON;
        stateStartedMs = now;
      }
      break;

    case AccessState::DENIED_HOLD:
      if (elapsed >= AppConfig::DENIED_HOLD_MS) enterStandby(true);
      break;
  }
}
}

void setup() {
  Serial.begin(115200);

  pinMode(AppConfig::LED_RED_PIN, OUTPUT);
  pinMode(AppConfig::LED_YELLOW_PIN, OUTPUT);
  pinMode(AppConfig::LED_GREEN_PIN, OUTPUT);
  pinMode(AppConfig::BUZZER_PIN, OUTPUT);
  enterStandby(false);

  const uint64_t chipId = ESP.getEfuseMac();
  const uint32_t randomPart = esp_random();

  snprintf(actuatorTopic, sizeof(actuatorTopic), "%s%s",
           AppConfig::MQTT_ACTUATOR_TOPIC_PREFIX, AppConfig::NIM);
  snprintf(feedbackTopic, sizeof(feedbackTopic), "%s%s",
           AppConfig::MQTT_FEEDBACK_TOPIC_PREFIX, AppConfig::NIM);
  snprintf(clientId, sizeof(clientId), "QR-%s-%04X-%08lX",
           AppConfig::NIM,
           static_cast<unsigned int>(chipId & 0xFFFFU),
           static_cast<unsigned long>(randomPart));

  Serial.printf("[SYSTEM] Client ID: %s\n", clientId);
  Serial.printf("[SYSTEM] Subscribe: %s\n", actuatorTopic);
  Serial.printf("[SYSTEM] Feedback: %s\n", feedbackTopic);

  mqttManager.setCallback(handleMqttMessage);
  mqttManager.begin(clientId);
  wifiManager.begin();
}

void loop() {
  wifiManager.loop();
  mqttManager.loop(wifiManager.connected());
  updateAccessSequence();
  publishStandbyFeedback();
}
