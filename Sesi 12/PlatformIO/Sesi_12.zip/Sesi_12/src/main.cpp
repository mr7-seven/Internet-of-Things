
#include <Arduino.h>
#include <ArduinoJson.h>
#include <WiFi.h>
#include <esp_system.h>
#include <cstring>

#include "app_config.h"
#include "mqtt_manager.h"
#include "wifi_manager.h"

WifiManager wifiManager(AppConfig::WIFI_SSID,
                        AppConfig::WIFI_PASSWORD,
                        AppConfig::WIFI_RECONNECT_INTERVAL_MS,
                        AppConfig::WIFI_CONNECT_TIMEOUT_MS);

char commandTopic[128];
char statusTopic[128];
char clientId[96];

MqttManager mqttManager(AppConfig::MQTT_HOST,
                        AppConfig::MQTT_PORT,
                        commandTopic,
                        AppConfig::MQTT_USERNAME,
                        AppConfig::MQTT_PASSWORD,
                        AppConfig::MQTT_RECONNECT_INTERVAL_MS,
                        AppConfig::MQTT_CONNECT_TIMEOUT_MS);

enum class AccessState : uint8_t { Idle, Recognized, Unknown };
AccessState accessState = AccessState::Idle;

portMUX_TYPE commandMux = portMUX_INITIALIZER_UNLOCKED;
char pendingCommand[384] = "";
bool commandAvailable = false;
bool blinkOn = false;
bool mqttWasConnected = false;
bool transitionBeepActive = false;
uint32_t lastBlinkAt = 0;
uint32_t lastStatusAt = 0;
uint32_t transitionBeepUntil = 0;

constexpr uint32_t TRANSITION_BEEP_MS = 150;
// Kirim status segera setelah MQTT tersambung, lalu heartbeat setiap 10 detik.
// Nilai ini sengaja diletakkan di main.cpp agar interval status mudah diubah.
constexpr uint32_t STATUS_HEARTBEAT_MS = 10000;

void setOutput(uint8_t pin, bool on, bool activeHigh) {
  digitalWrite(pin, on == activeHigh ? HIGH : LOW);
}

const char* stateName() {
  switch (accessState) {
    case AccessState::Recognized:
      return "recognized";
    case AccessState::Unknown:
      return "unknown";
    default:
      return "idle";
  }
}

void applyOutputs(uint32_t now) {
  if (accessState == AccessState::Unknown) {
    if (now - lastBlinkAt >= AppConfig::UNKNOWN_BLINK_INTERVAL_MS) {
      lastBlinkAt = now;
      blinkOn = !blinkOn;
    }
    setOutput(AppConfig::LED_RED_PIN, true, AppConfig::LED_ACTIVE_HIGH);
    setOutput(AppConfig::LED_YELLOW_PIN, false, AppConfig::LED_ACTIVE_HIGH);
    setOutput(AppConfig::LED_GREEN_PIN, false, AppConfig::LED_ACTIVE_HIGH);
    setOutput(AppConfig::BUZZER_PIN, blinkOn, AppConfig::BUZZER_ACTIVE_HIGH);
    return;
  }

  blinkOn = false;
  if (transitionBeepActive &&
      static_cast<int32_t>(now - transitionBeepUntil) >= 0) {
    transitionBeepActive = false;
  }
  setOutput(AppConfig::BUZZER_PIN,
            transitionBeepActive,
            AppConfig::BUZZER_ACTIVE_HIGH);
  setOutput(AppConfig::LED_RED_PIN, false, AppConfig::LED_ACTIVE_HIGH);
  setOutput(AppConfig::LED_GREEN_PIN,
            accessState == AccessState::Recognized,
            AppConfig::LED_ACTIVE_HIGH);
  setOutput(AppConfig::LED_YELLOW_PIN,
            accessState == AccessState::Idle,
            AppConfig::LED_ACTIVE_HIGH);
}

void queueCommand(const char* topic, const char* payload) {
  if (topic == nullptr || payload == nullptr || std::strcmp(topic, commandTopic) != 0) {
    return;
  }
  const size_t length = strnlen(payload, sizeof(pendingCommand));
  if (length >= sizeof(pendingCommand)) {
    Serial.println("[MQTT] Perintah diabaikan: payload terlalu panjang");
    return;
  }
  portENTER_CRITICAL(&commandMux);
  std::memcpy(pendingCommand, payload, length + 1);
  commandAvailable = true;
  portEXIT_CRITICAL(&commandMux);
}

void processCommand() {
  char payload[sizeof(pendingCommand)];
  portENTER_CRITICAL(&commandMux);
  const bool available = commandAvailable;
  if (available) {
    std::memcpy(payload, pendingCommand, sizeof(payload));
    commandAvailable = false;
  }
  portEXIT_CRITICAL(&commandMux);
  if (!available) return;

  JsonDocument doc;
  const DeserializationError error = deserializeJson(doc, payload);
  if (error || !doc.is<JsonObject>()) {
    Serial.printf("[MQTT] JSON tidak valid: %s\n", error.c_str());
    return;
  }

  const char* groupId = doc["id_group"] | "";
  const char* nodeId = doc["node_id"] | "";
  if (std::strcmp(groupId, AppConfig::GROUP_ID) != 0 ||
      std::strcmp(nodeId, AppConfig::NODE_ID) != 0) {
    Serial.println("[MQTT] Perintah bukan untuk kelompok/node ini");
    return;
  }

  const char* state = doc["state"] | "";
  AccessState nextState;
  if (std::strcmp(state, "recognized") == 0) {
    nextState = AccessState::Recognized;
  } else if (std::strcmp(state, "unknown") == 0) {
    nextState = AccessState::Unknown;
  } else if (std::strcmp(state, "idle") == 0) {
    nextState = AccessState::Idle;
  } else {
    Serial.printf("[MQTT] State tidak dikenal: %s\n", state);
    return;
  }

  if (nextState != accessState) {
    const AccessState previousState = accessState;
    accessState = nextState;
    const uint32_t now = millis();

    // Beep satu kali hanya saat indikator berpindah kuning <-> hijau.
    const bool yellowGreenTransition =
        (previousState == AccessState::Idle &&
         nextState == AccessState::Recognized) ||
        (previousState == AccessState::Recognized &&
         nextState == AccessState::Idle);
    if (yellowGreenTransition) {
      transitionBeepActive = true;
      transitionBeepUntil = now + TRANSITION_BEEP_MS;
    } else {
      transitionBeepActive = false;
    }

    // Saat merah, mulai beep segera lalu lanjut berkedip non-blocking.
    blinkOn = nextState == AccessState::Unknown;
    lastBlinkAt = now;
    Serial.printf("[AKSES] State berubah menjadi %s\n", stateName());
  }
}

bool publishStatus(uint32_t now) {
  if (!mqttManager.connected()) return false;
  JsonDocument doc;
  doc["id_group"] = AppConfig::GROUP_ID;
  doc["node_id"] = AppConfig::NODE_ID;
  doc["state"] = "online";
  doc["access_state"] = stateName();
  doc["rssi"] = WiFi.RSSI();
  doc["uptime_ms"] = now;

  char payload[256];
  if (measureJson(doc) >= sizeof(payload)) return false;
  serializeJson(doc, payload, sizeof(payload));
  const bool sent = mqttManager.publish(statusTopic, payload, true);
  if (sent) Serial.printf("[MQTT] Status: %s\n", payload);
  return sent;
}

void setup() {
  Serial.begin(115200);
  delay(200);

  pinMode(AppConfig::LED_RED_PIN, OUTPUT);
  pinMode(AppConfig::LED_YELLOW_PIN, OUTPUT);
  pinMode(AppConfig::LED_GREEN_PIN, OUTPUT);
  pinMode(AppConfig::BUZZER_PIN, OUTPUT);
  applyOutputs(millis());

  snprintf(commandTopic,
           sizeof(commandTopic),
           "%s/%s/esp32/cmd",
           AppConfig::GROUP_ID,
           AppConfig::NODE_ID);
  snprintf(statusTopic,
           sizeof(statusTopic),
           "%s/%s/esp32/status",
           AppConfig::GROUP_ID,
           AppConfig::NODE_ID);

  const uint64_t chipId = ESP.getEfuseMac();
  snprintf(clientId,
           sizeof(clientId),
           "face-door-%s-%s-%04X%08X",
           AppConfig::GROUP_ID,
           AppConfig::NODE_ID,
           static_cast<uint16_t>(chipId >> 32),
           static_cast<uint32_t>(chipId));

  mqttManager.setCallback(queueCommand);
  mqttManager.begin(clientId);
  wifiManager.begin();

  Serial.printf("[TOPIC] Subscribe: %s\n", commandTopic);
  Serial.printf("[TOPIC] Publish  : %s\n", statusTopic);
}

void loop() {
  const uint32_t now = millis();
  wifiManager.loop();
  mqttManager.loop(wifiManager.connected());
  processCommand();
  applyOutputs(now);

  const bool connected = mqttManager.connected();
  if (connected &&
      (!mqttWasConnected || now - lastStatusAt >= STATUS_HEARTBEAT_MS)) {
    if (publishStatus(now)) lastStatusAt = now;
  }
  mqttWasConnected = connected;
}