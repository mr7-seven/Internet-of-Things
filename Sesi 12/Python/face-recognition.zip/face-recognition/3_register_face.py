from __future__ import annotations

import time
import uuid

import cv2

from face_system.config import load_config, open_camera
from face_system.database import EmbeddingDatabase
from face_system.mqtt_runtime import MqttRuntime
from face_system.vision import draw_yolo_box, extract_faces


def draw_system_status(frame, mqtt: MqttRuntime, config: dict):
    """Tambahkan footer status tanpa menutupi area frame kamera."""
    footer_height = 30
    display = cv2.copyMakeBorder(
        frame,
        0,
        footer_height,
        0,
        0,
        cv2.BORDER_CONSTANT,
        value=(24, 28, 32),
    )
    connected = mqtt.connected.is_set()
    status_color = (40, 200, 90) if connected else (40, 70, 230)
    text_color = (225, 230, 235)
    y = frame.shape[0] + 20

    cv2.circle(display, (14, y - 4), 4, status_color, -1, cv2.LINE_AA)
    cv2.putText(
        display,
        f"MQTT {'ONLINE' if connected else 'OFFLINE'}",
        (25, y),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.43,
        status_color,
        1,
        cv2.LINE_AA,
    )
    identity = config["identity"]
    identity_text = f"GROUP {identity['id_group']}  |  NODE {identity['node_id']}"
    (text_width, _), _ = cv2.getTextSize(
        identity_text, cv2.FONT_HERSHEY_SIMPLEX, 0.43, 1
    )
    cv2.putText(
        display,
        identity_text,
        (max(145, display.shape[1] - text_width - 12), y),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.43,
        text_color,
        1,
        cv2.LINE_AA,
    )
    return display


def main() -> None:
    config = load_config()
    database = EmbeddingDatabase(config)
    mqtt = MqttRuntime(config, database.update_profiles)
    mqtt.start()
    camera = open_camera(config)
    publish_key = str(config["registration"]["publish_key"]).lower()
    current = None
    print(f"[REGISTRASI] Tekan {publish_key.upper()} untuk mengirim face_id; Q untuk keluar.")

    try:
        while True:
            ok, frame = camera.read()
            if not ok:
                time.sleep(0.05)
                continue
            faces = extract_faces(frame, config)
            current = None
            message = "Arahkan satu wajah ke kamera"

            if len(faces) == 1:
                face = faces[0]
                if not face.is_real:
                    result = {"face_id": "unknown", "confidence": 0.0, "distance": 1.0}
                else:
                    result = database.identify(face.crop_bgr)
                current = result if result["face_id"] != "unknown" else None
                if current:
                    label = f"{database.display_name(current['face_id'])} {current['confidence']:.1f}%"
                    draw_yolo_box(frame, face.box, label, (0, 190, 0))
                    message = f"Tekan {publish_key.upper()} untuk kirim {current['face_id']}"
                else:
                    draw_yolo_box(frame, face.box, "unknown", (0, 0, 255))
                    message = "Wajah tidak dikenal / confidence rendah"
            elif len(faces) > 1:
                message = "Registrasi ditolak: lebih dari satu wajah"
                for face in faces:
                    draw_yolo_box(frame, face.box, "multiple faces", (0, 0, 255))

            cv2.putText(frame, message, (15, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.62, (255, 255, 255), 2)
            display_frame = draw_system_status(frame, mqtt, config)
            cv2.imshow("3 - Registrasi Face ID", display_frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), ord("Q")):
                break
            if key == ord(publish_key) and current:
                payload = {
                    "state": "registration",
                    "event_id": str(uuid.uuid4()),
                    "face_id": current["face_id"],
                    "confidence": round(float(current["confidence"]), 2),
                    "distance": round(float(current["distance"]), 5),
                }
                if mqtt.publish("face_register", payload):
                    print(f"[MQTT] face_id terkirim: {current['face_id']}")
                else:
                    print("[MQTT] Belum terhubung; face_id tidak terkirim.")
    finally:
        camera.release()
        cv2.destroyAllWindows()
        mqtt.stop()


if __name__ == "__main__":
    main()
