from __future__ import annotations

import time
import uuid

import cv2

from face_system.config import load_config, open_camera
from face_system.database import EmbeddingDatabase
from face_system.mqtt_runtime import MqttRuntime
from face_system.vision import draw_yolo_box, extract_faces


def draw_instruction_panel(
    frame, text: str, accent_color: tuple[int, int, int]
) -> None:
    """Tampilkan instruksi yang kontras di kiri atas frame."""
    font = cv2.FONT_HERSHEY_SIMPLEX
    scale = 0.62
    thickness = 2
    (text_width, text_height), baseline = cv2.getTextSize(
        text, font, scale, thickness
    )
    x1, y1 = 10, 10
    x2 = min(frame.shape[1] - 10, x1 + text_width + 28)
    y2 = y1 + text_height + baseline + 24

    overlay = frame.copy()
    cv2.rectangle(overlay, (x1, y1), (x2, y2), (10, 15, 20), -1)
    cv2.addWeighted(overlay, 0.82, frame, 0.18, 0, frame)
    cv2.rectangle(frame, (x1, y1), (x2, y2), accent_color, 2, cv2.LINE_AA)
    cv2.circle(frame, (x1 + 13, y1 + 17), 5, accent_color, -1, cv2.LINE_AA)
    cv2.putText(
        frame,
        text,
        (x1 + 25, y1 + 23),
        font,
        scale,
        (255, 255, 255),
        thickness,
        cv2.LINE_AA,
    )


def draw_system_status(frame, mqtt: MqttRuntime, config: dict):
    """Tambahkan footer status tanpa menutupi area frame kamera."""
    footer_height = 30
    display = cv2.copyMakeBorder(
        frame,
        0,
        footer_height,
        0,
        0,
        cv2.BORDER_CONSTANT,
        value=(24, 28, 32),
    )
    connected = mqtt.connected.is_set()
    status_color = (40, 200, 90) if connected else (40, 70, 230)
    text_color = (225, 230, 235)
    y = frame.shape[0] + 20

    cv2.circle(display, (14, y - 4), 4, status_color, -1, cv2.LINE_AA)
    cv2.putText(
        display,
        f"MQTT {'ONLINE' if connected else 'OFFLINE'}",
        (25, y),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.43,
        status_color,
        1,
        cv2.LINE_AA,
    )
    identity = config["identity"]
    identity_text = f"GROUP {identity['id_group']}  |  NODE {identity['node_id']}"
    (text_width, _), _ = cv2.getTextSize(
        identity_text, cv2.FONT_HERSHEY_SIMPLEX, 0.43, 1
    )
    cv2.putText(
        display,
        identity_text,
        (max(145, display.shape[1] - text_width - 12), y),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.43,
        text_color,
        1,
        cv2.LINE_AA,
    )
    return display


def draw_temporary_notice(frame, text: str, color: tuple[int, int, int]) -> None:
    """Tampilkan notifikasi ringkas di bagian bawah frame kamera."""
    font = cv2.FONT_HERSHEY_SIMPLEX
    scale = 0.55
    thickness = 2
    (text_width, text_height), baseline = cv2.getTextSize(
        text, font, scale, thickness
    )
    padding_x, padding_y = 14, 10
    box_width = min(frame.shape[1] - 20, text_width + (padding_x * 2))
    x1 = max(10, (frame.shape[1] - box_width) // 2)
    x2 = x1 + box_width
    y2 = frame.shape[0] - 12
    y1 = y2 - text_height - baseline - (padding_y * 2)
    cv2.rectangle(frame, (x1, y1), (x2, y2), color, -1, cv2.LINE_AA)
    text_x = x1 + max(padding_x, (box_width - text_width) // 2)
    text_y = y2 - padding_y - baseline
    cv2.putText(
        frame,
        text,
        (text_x, text_y),
        font,
        scale,
        (255, 255, 255),
        thickness,
        cv2.LINE_AA,
    )


def main() -> None:
    config = load_config()
    database = EmbeddingDatabase(config)
    mqtt = MqttRuntime(config, database.update_profiles)
    mqtt.start()
    camera = open_camera(config)
    publish_key = str(config["registration"]["publish_key"]).lower()
    current = None
    notice_text = ""
    notice_color = (0, 0, 200)
    notice_until = 0.0
    print(f"[REGISTRASI] Tekan {publish_key.upper()} untuk mengirim face_id; Q untuk keluar.")

    try:
        while True:
            ok, frame = camera.read()
            if not ok:
                time.sleep(0.05)
                continue
            faces = extract_faces(frame, config)
            current = None
            message = "Arahkan satu wajah ke kamera"
            instruction_color = (0, 210, 255)

            if len(faces) == 1:
                face = faces[0]
                if not face.is_real:
                    result = {"face_id": "unknown", "confidence": 0.0, "distance": 1.0}
                else:
                    result = database.identify(face.crop_bgr)
                current = result if result["face_id"] != "unknown" else None
                if current:
                    label = f"{database.display_name(current['face_id'])} {current['confidence']:.1f}%"
                    draw_yolo_box(frame, face.box, label, (0, 190, 0))
                    message = f"Tekan {publish_key.upper()} untuk kirim {current['face_id']}"
                    instruction_color = (30, 210, 80)
                else:
                    draw_yolo_box(frame, face.box, "unknown", (0, 0, 255))
                    message = "Wajah tidak dikenal / confidence rendah"
                    instruction_color = (30, 40, 230)
            elif len(faces) > 1:
                message = "Registrasi ditolak: lebih dari satu wajah"
                instruction_color = (30, 40, 230)
                for face in faces:
                    draw_yolo_box(frame, face.box, "multiple faces", (0, 0, 255))

            draw_instruction_panel(frame, message, instruction_color)
            if notice_text and time.monotonic() < notice_until:
                draw_temporary_notice(frame, notice_text, notice_color)
            elif notice_text:
                notice_text = ""
            display_frame = draw_system_status(frame, mqtt, config)
            cv2.imshow("3 - Registrasi Face ID", display_frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), ord("Q")):
                break
            if key == ord(publish_key):
                if current:
                    payload = {
                        "state": "registration",
                        "event_id": str(uuid.uuid4()),
                        "face_id": current["face_id"],
                        "confidence": round(float(current["confidence"]), 2),
                        "distance": round(float(current["distance"]), 5),
                    }
                    if mqtt.publish("face_register", payload):
                        print(f"[MQTT] face_id terkirim: {current['face_id']}")
                        notice_text = "BERHASIL: DATA REGISTRASI TERKIRIM"
                        notice_color = (20, 155, 75)
                    else:
                        print("[MQTT] Belum terhubung; face_id tidak terkirim.")
                        notice_text = "GAGAL: MQTT TIDAK TERHUBUNG"
                        notice_color = (30, 40, 210)
                else:
                    print("[REGISTRASI] Gagal: wajah belum dikenali.")
                    notice_text = "GAGAL: WAJAH BELUM DIKENALI"
                    notice_color = (30, 40, 210)
                notice_until = time.monotonic() + 3.0
    finally:
        camera.release()
        cv2.destroyAllWindows()
        mqtt.stop()


if __name__ == "__main__":
    main()
