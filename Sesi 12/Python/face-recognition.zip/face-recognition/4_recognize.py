from __future__ import annotations

import queue
import threading
import time
import uuid
from copy import deepcopy
from dataclasses import dataclass
from typing import Any

import cv2

from face_system.config import load_config, open_camera
from face_system.database import EmbeddingDatabase
from face_system.mqtt_runtime import MqttRuntime
from face_system.state_filter import StableState, StateFilter
from face_system.vision import draw_yolo_box, extract_faces


@dataclass
class InferenceResult:
    sequence: int
    faces: list[dict[str, Any]]
    state: str
    face_id: str
    face_ids: list[str]
    confidence: float
    reason: str


def draw_system_status(frame, mqtt: MqttRuntime, config: dict[str, Any]):
    """Tambahkan footer status tanpa menutupi area frame kamera."""
    footer_height = 30
    display = cv2.copyMakeBorder(
        frame,
        0,
        footer_height,
        0,
        0,
        cv2.BORDER_CONSTANT,
        value=(24, 28, 32),
    )
    connected = mqtt.connected.is_set()
    status_color = (40, 200, 90) if connected else (40, 70, 230)
    text_color = (225, 230, 235)
    y = frame.shape[0] + 20

    cv2.circle(display, (14, y - 4), 4, status_color, -1, cv2.LINE_AA)
    cv2.putText(
        display,
        f"MQTT {'ONLINE' if connected else 'OFFLINE'}",
        (25, y),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.43,
        status_color,
        1,
        cv2.LINE_AA,
    )
    identity = config["identity"]
    identity_text = f"GROUP {identity['id_group']}  |  NODE {identity['node_id']}"
    (text_width, _), _ = cv2.getTextSize(
        identity_text, cv2.FONT_HERSHEY_SIMPLEX, 0.43, 1
    )
    cv2.putText(
        display,
        identity_text,
        (max(145, display.shape[1] - text_width - 12), y),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.43,
        text_color,
        1,
        cv2.LINE_AA,
    )
    return display


def iou(a, b) -> float:
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    left, top = max(ax, bx), max(ay, by)
    right, bottom = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    intersection = max(0, right - left) * max(0, bottom - top)
    union = aw * ah + bw * bh - intersection
    return intersection / union if union else 0.0


class InferenceWorker:
    def __init__(self, config: dict[str, Any], database: EmbeddingDatabase) -> None:
        self.config = config
        self.database = database
        self.input: queue.Queue[tuple[int, Any]] = queue.Queue(maxsize=1)
        self.output: queue.Queue[InferenceResult] = queue.Queue(maxsize=1)
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, name="face-inference", daemon=True)
        self.previous: list[dict[str, Any]] = []
        self.processed = 0

    def start(self) -> None:
        self.thread.start()

    def submit(self, sequence: int, frame) -> None:
        try:
            self.input.put_nowait((sequence, frame.copy()))
        except queue.Full:
            pass

    def latest(self) -> InferenceResult | None:
        result = None
        while True:
            try:
                result = self.output.get_nowait()
            except queue.Empty:
                return result

    def stop(self) -> None:
        self.stop_event.set()
        self.thread.join(timeout=3.0)

    def _reuse_prediction(self, box) -> dict[str, Any] | None:
        matches = [item for item in self.previous if iou(box, item["box"]) >= 0.45]
        return max(matches, key=lambda item: iou(box, item["box"]), default=None)

    def _run(self) -> None:
        scale = float(self.config["performance"]["process_scale"])
        embed_every = max(1, int(self.config["performance"]["embed_every_n_frames"]))
        scaled_config = deepcopy(self.config)
        scaled_config["performance"]["min_face_size"] = max(
            32, int(self.config["performance"]["min_face_size"] * scale)
        )
        while not self.stop_event.is_set():
            try:
                sequence, frame = self.input.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                small = cv2.resize(frame, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
                detected = extract_faces(small, scaled_config)
                self.processed += 1
                embed_due = self.processed % embed_every == 0 or not self.previous
                rendered: list[dict[str, Any]] = []
                for face in detected:
                    sx, sy, sw, sh = face.box
                    box = tuple(int(value / scale) for value in (sx, sy, sw, sh))
                    reused = self._reuse_prediction(box) if not embed_due else None
                    if not face.is_real:
                        prediction = {"face_id": "unknown", "confidence": 0.0, "distance": 1.0, "recognized": False}
                    elif reused is not None:
                        prediction = {key: reused[key] for key in ("face_id", "confidence", "distance", "recognized")}
                    else:
                        prediction = self.database.identify(face.crop_bgr)
                    rendered.append({"box": box, **prediction})

                reason = ""
                if not rendered:
                    state, face_id, face_ids, confidence = "idle", "", [], 0.0
                else:
                    recognized_faces = [item for item in rendered if item["recognized"]]
                    unknown_faces = [item for item in rendered if not item["recognized"]]

                    # Prioritas status agregat:
                    # 1. Minimal satu unknown  -> unknown (LED merah + buzzer).
                    # 2. Semua wajah terdaftar -> recognized, termasuk multiwajah.
                    if unknown_faces:
                        state, face_id, face_ids = "unknown", "", []
                        confidence = max(float(item["confidence"]) for item in unknown_faces)
                        reason = "contains_unknown"
                    else:
                        face_ids = sorted({str(item["face_id"]) for item in recognized_faces})
                        face_id = "|".join(face_ids)
                        confidence = min(float(item["confidence"]) for item in recognized_faces)
                        state = "recognized"
                        if len(face_ids) > 1:
                            reason = "multiple_recognized"
                self.previous = rendered
                result = InferenceResult(
                    sequence, rendered, state, face_id, face_ids, confidence, reason
                )
            except Exception as exc:
                print(f"[INFERENSI] Gagal memproses frame: {exc}")
                result = InferenceResult(
                    sequence, [], "idle", "", [], 0.0, "inference_error"
                )
            if self.output.full():
                try:
                    self.output.get_nowait()
                except queue.Empty:
                    pass
            self.output.put_nowait(result)


def user_statuses(database: EmbeddingDatabase, state: StableState) -> list[dict[str, str]]:
    if state.state == "idle":
        return [{"face_id": item, "status": "idle"} for item in database.face_ids]
    if state.state == "recognized":
        recognized_ids = {item for item in state.face_id.split("|") if item}
        return [
            {"face_id": item, "status": "available" if item in recognized_ids else "unavailable"}
            for item in database.face_ids
        ]
    return [{"face_id": item, "status": "unavailable"} for item in database.face_ids]


def publish_state(mqtt: MqttRuntime, database: EmbeddingDatabase, state: StableState, confidence: float, reason: str, heartbeat: bool) -> None:
    recognized_ids = (
        [item for item in state.face_id.split("|") if item]
        if state.state == "recognized"
        else []
    )
    payload = {
        "state": state.state,
        "event_id": str(uuid.uuid4()),
        # face_id dipertahankan untuk kompatibilitas flow lama; face_ids berisi
        # seluruh pengguna yang dikenali pada frame stabil yang sama.
        "face_id": recognized_ids[0] if recognized_ids else None,
        "face_ids": recognized_ids,
        "confidence": round(confidence, 2),
        "reason": reason or None,
        "heartbeat": heartbeat,
        "users": user_statuses(database, state),
    }
    mqtt.publish("face_status", payload)
    mqtt.publish(
        "esp32_cmd",
        {
            "state": state.state,
            "face_id": recognized_ids[0] if recognized_ids else None,
            "face_ids": recognized_ids,
            "confidence": round(confidence, 2),
        },
    )
    print(f"[STATE] {state.key} | MQTT {'heartbeat' if heartbeat else 'change'}")


def main() -> None:
    config = load_config()
    database = EmbeddingDatabase(config)
    mqtt = MqttRuntime(config, database.update_profiles)
    mqtt.start()
    camera = open_camera(config)
    filter_cfg = config["filter"]
    state_filter = StateFilter(
        int(filter_cfg["confirm_frames"]),
        int(filter_cfg["unknown_confirm_frames"]),
        int(filter_cfg["lost_confirm_frames"]),
        float(filter_cfg["hold_time_seconds"]),
    )
    worker = InferenceWorker(config, database)
    worker.start()

    sequence = 0
    last_result = InferenceResult(0, [], "idle", "", [], 0.0, "")
    last_processed_sequence = -1
    last_publish = 0.0
    heartbeat_seconds = float(config["mqtt"]["heartbeat_seconds"])
    fps, frame_counter, fps_started = 0.0, 0, time.monotonic()
    print("[SISTEM] Pengenalan aktif. Tekan Q untuk keluar.")

    try:
        while True:
            ok, frame = camera.read()
            if not ok:
                time.sleep(0.05)
                continue
            sequence += 1
            worker.submit(sequence, frame)
            latest = worker.latest()
            if latest is not None:
                last_result = latest

            changed = False
            if last_result.sequence != last_processed_sequence:
                last_processed_sequence = last_result.sequence
                stable, changed = state_filter.update(last_result.state, last_result.face_id)
            else:
                stable = state_filter.stable

            now = time.monotonic()
            heartbeat = now - last_publish >= heartbeat_seconds
            if changed or heartbeat:
                publish_state(
                    mqtt, database, stable, last_result.confidence, last_result.reason, heartbeat and not changed
                )
                last_publish = now

            for item in last_result.faces:
                recognized = bool(item["recognized"])
                color = (0, 190, 0) if recognized else (0, 0, 255)
                label = (
                    f"{database.display_name(item['face_id'])} {item['confidence']:.1f}%"
                    if recognized else "unknown"
                )
                draw_yolo_box(frame, item["box"], label, color)

            frame_counter += 1
            elapsed = now - fps_started
            if elapsed >= 1.0:
                fps = frame_counter / elapsed
                frame_counter, fps_started = 0, now
            cv2.putText(frame, f"FPS {fps:.1f} | {stable.key}", (15, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.62, (255, 255, 255), 2)
            display_frame = draw_system_status(frame, mqtt, config)
            cv2.imshow("4 - Face Security System", display_frame)
            if cv2.waitKey(1) & 0xFF in (ord("q"), ord("Q")):
                break
    finally:
        worker.stop()
        camera.release()
        cv2.destroyAllWindows()
        mqtt.stop()


if __name__ == "__main__":
    main()
