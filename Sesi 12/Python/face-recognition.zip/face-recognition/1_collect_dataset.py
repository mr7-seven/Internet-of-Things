from __future__ import annotations

import argparse
import re
import time
from copy import deepcopy
from pathlib import Path

import cv2

from face_system.config import load_config, open_camera
from face_system.vision import draw_yolo_box, extract_faces


def valid_face_id(value: str) -> str:
    value = value.strip().upper()
    if not re.fullmatch(r"FACE-[A-Z0-9_-]{1,20}", value):
        raise argparse.ArgumentTypeError("Gunakan format seperti FACE-0001.")
    return value


def main() -> None:
    parser = argparse.ArgumentParser(description="Mengumpulkan dataset wajah bertahap.")
    parser.add_argument("--face-id", type=valid_face_id, help="Contoh: FACE-0001")
    args = parser.parse_args()
    face_id = args.face_id or valid_face_id(input("Masukkan face_id (contoh FACE-0001): "))

    config = load_config()
    target = int(config["dataset"]["target_total"])
    stages = config["dataset"]["stages"]
    if sum(int(item["count"]) for item in stages) != target:
        raise ValueError("Jumlah count pada dataset.stages harus sama dengan target_total.")

    output_dir = Path(config["paths"]["dataset"]) / face_id
    output_dir.mkdir(parents=True, exist_ok=True)
    existing = len(list(output_dir.glob("*.jpg")))
    next_index = existing + 1
    saved = 0
    stage_index = 0
    stage_saved = 0
    last_capture = 0.0
    interval = int(config["dataset"]["capture_interval_ms"]) / 1000.0
    blur_threshold = float(config["dataset"]["blur_threshold"])
    camera = open_camera(config)

    print(f"[DATASET] Target {target} gambar baru untuk {face_id}. Tekan Q untuk berhenti.")
    try:
        while saved < target:
            ok, frame = camera.read()
            if not ok:
                print("[KAMERA] Frame gagal dibaca; mencoba kembali.")
                time.sleep(0.05)
                continue

            faces = extract_faces(frame, config)
            stage = stages[stage_index]
            instruction = str(stage["instruction"])
            info = "Pastikan tepat satu wajah terlihat"
            color = (0, 0, 255)

            if len(faces) == 1:
                face = faces[0]
                sharpness = cv2.Laplacian(
                    cv2.cvtColor(face.crop_bgr, cv2.COLOR_BGR2GRAY), cv2.CV_64F
                ).var()
                if not face.is_real:
                    info = "Anti-spoof: wajah tidak dinilai nyata"
                elif sharpness < blur_threshold:
                    info = f"Gambar blur ({sharpness:.0f}); tahan posisi"
                else:
                    color = (0, 190, 0)
                    info = instruction
                    now = time.monotonic()
                    if now - last_capture >= interval:
                        filename = output_dir / f"{face_id}_{next_index:04d}.jpg"
                        if cv2.imwrite(str(filename), face.crop_bgr):
                            saved += 1
                            stage_saved += 1
                            next_index += 1
                            last_capture = now
                            if stage_saved >= int(stage["count"]) and saved < target:
                                stage_index += 1
                                stage_saved = 0
                    draw_yolo_box(frame, face.box, f"{face_id} | tajam {sharpness:.0f}", color)
            elif len(faces) > 1:
                info = "Lebih dari satu wajah terdeteksi"

            progress = int(100 * saved / target)
            cv2.rectangle(frame, (20, frame.shape[0] - 34), (frame.shape[1] - 20, frame.shape[0] - 16), (70, 70, 70), -1)
            fill = 20 + int((frame.shape[1] - 40) * saved / target)
            cv2.rectangle(frame, (20, frame.shape[0] - 34), (fill, frame.shape[0] - 16), color, -1)
            cv2.putText(frame, f"{info} | {saved}/{target} ({progress}%)", (15, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.62, color, 2)
            cv2.imshow("1 - Pengumpulan Dataset Wajah", frame)
            if cv2.waitKey(1) & 0xFF in (ord("q"), ord("Q")):
                break
    finally:
        camera.release()
        cv2.destroyAllWindows()

    print(f"[SELESAI] {saved} gambar baru disimpan di {output_dir}")
    if saved < target:
        print("[INFO] Pengumpulan dihentikan sebelum target. Jalankan lagi untuk menambah sampel.")


if __name__ == "__main__":
    main()
