from __future__ import annotations

import argparse
import re
import time
from copy import deepcopy
from pathlib import Path

import cv2

from face_system.config import load_config, open_camera
from face_system.vision import draw_yolo_box, extract_faces


# Batasi pengambilan maksimal sekitar 2-3 gambar per detik agar variasi pose
# lebih terkontrol dan gambar tidak tersimpan terlalu rapat.
MIN_CAPTURE_INTERVAL_MS = 350
DISPLAY_DELAY_MS = 30


def draw_instruction_panel(
    frame,
    instruction: str,
    face_id: str,
    saved: int,
    target: int,
    stage_number: int,
    stage_total: int,
    accent_color: tuple[int, int, int],
) -> None:
    """Tampilkan instruksi dan progres pada panel kontras di kiri atas."""
    overlay = frame.copy()
    x1, y1 = 10, 10
    x2, y2 = frame.shape[1] - 10, 78
    cv2.rectangle(overlay, (x1, y1), (x2, y2), (8, 12, 18), -1)
    cv2.addWeighted(overlay, 0.84, frame, 0.16, 0, frame)
    cv2.rectangle(frame, (x1, y1), (x2, y2), accent_color, 2, cv2.LINE_AA)
    cv2.rectangle(frame, (x1, y1), (x1 + 6, y2), accent_color, -1)

    cv2.putText(
        frame,
        instruction,
        (x1 + 18, y1 + 27),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.62,
        (255, 255, 255),
        2,
        cv2.LINE_AA,
    )
    detail = (
        f"{face_id}  |  Tahap {stage_number}/{stage_total}  |  "
        f"Tersimpan {saved}/{target}"
    )
    cv2.putText(
        frame,
        detail,
        (x1 + 18, y1 + 54),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.48,
        (210, 225, 235),
        1,
        cv2.LINE_AA,
    )


def valid_face_id(value: str) -> str:
    value = value.strip().upper()
    if not re.fullmatch(r"FACE-[A-Z0-9_-]{1,20}", value):
        raise argparse.ArgumentTypeError("Gunakan format seperti FACE-0001.")
    return value


def main() -> None:
    parser = argparse.ArgumentParser(description="Mengumpulkan dataset wajah bertahap.")
    parser.add_argument("--face-id", type=valid_face_id, help="Contoh: FACE-0001")
    args = parser.parse_args()
    face_id = args.face_id or valid_face_id(input("Masukkan face_id (contoh FACE-0001): "))

    config = load_config()
    target = int(config["dataset"]["target_total"])
    stages = config["dataset"]["stages"]
    if sum(int(item["count"]) for item in stages) != target:
        raise ValueError("Jumlah count pada dataset.stages harus sama dengan target_total.")

    output_dir = Path(config["paths"]["dataset"]) / face_id
    output_dir.mkdir(parents=True, exist_ok=True)
    existing = len(list(output_dir.glob("*.jpg")))
    next_index = existing + 1
    saved = 0
    stage_index = 0
    stage_saved = 0
    last_capture = 0.0
    configured_interval_ms = int(config["dataset"]["capture_interval_ms"])
    capture_interval_ms = max(configured_interval_ms, MIN_CAPTURE_INTERVAL_MS)
    interval = capture_interval_ms / 1000.0
    blur_threshold = float(config["dataset"]["blur_threshold"])
    camera = open_camera(config)

    print(f"[DATASET] Target {target} gambar baru untuk {face_id}. Tekan Q untuk berhenti.")
    print(f"[DATASET] Interval pengambilan gambar: {capture_interval_ms} ms.")
    try:
        while saved < target:
            ok, frame = camera.read()
            if not ok:
                print("[KAMERA] Frame gagal dibaca; mencoba kembali.")
                time.sleep(0.05)
                continue

            faces = extract_faces(frame, config)
            stage = stages[stage_index]
            instruction = str(stage["instruction"])
            info = "Pastikan tepat satu wajah terlihat"
            color = (0, 0, 255)

            if len(faces) == 1:
                face = faces[0]
                sharpness = cv2.Laplacian(
                    cv2.cvtColor(face.crop_bgr, cv2.COLOR_BGR2GRAY), cv2.CV_64F
                ).var()
                if not face.is_real:
                    info = "Anti-spoof: wajah tidak dinilai nyata"
                elif sharpness < blur_threshold:
                    info = f"Gambar blur ({sharpness:.0f}); tahan posisi"
                else:
                    color = (0, 190, 0)
                    info = instruction
                    now = time.monotonic()
                    if now - last_capture >= interval:
                        filename = output_dir / f"{face_id}_{next_index:04d}.jpg"
                        if cv2.imwrite(str(filename), face.crop_bgr):
                            saved += 1
                            stage_saved += 1
                            next_index += 1
                            last_capture = now
                            if stage_saved >= int(stage["count"]) and saved < target:
                                stage_index += 1
                                stage_saved = 0
                    draw_yolo_box(frame, face.box, f"{face_id} | tajam {sharpness:.0f}", color)
            elif len(faces) > 1:
                info = "Lebih dari satu wajah terdeteksi"

            cv2.rectangle(frame, (20, frame.shape[0] - 34), (frame.shape[1] - 20, frame.shape[0] - 16), (70, 70, 70), -1)
            fill = 20 + int((frame.shape[1] - 40) * saved / target)
            cv2.rectangle(frame, (20, frame.shape[0] - 34), (fill, frame.shape[0] - 16), color, -1)
            draw_instruction_panel(
                frame,
                info,
                face_id,
                saved,
                target,
                stage_index + 1,
                len(stages),
                color,
            )
            cv2.imshow("1 - Pengumpulan Dataset Wajah", frame)
            if cv2.waitKey(DISPLAY_DELAY_MS) & 0xFF in (ord("q"), ord("Q")):
                break
    finally:
        camera.release()
        cv2.destroyAllWindows()

    print(f"[SELESAI] {saved} gambar baru disimpan di {output_dir}")
    if saved < target:
        print("[INFO] Pengumpulan dihentikan sebelum target. Jalankan lagi untuk menambah sampel.")


if __name__ == "__main__":
    main()
