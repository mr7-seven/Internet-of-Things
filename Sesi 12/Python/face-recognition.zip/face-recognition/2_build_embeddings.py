from __future__ import annotations

import pickle
from collections import Counter
from pathlib import Path

import cv2
import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split

from face_system.config import load_config
from face_system.vision import represent, resolve_threshold


IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png"}


def remove_outliers(vectors: np.ndarray) -> np.ndarray:
    centroid = vectors.mean(axis=0)
    centroid /= max(float(np.linalg.norm(centroid)), 1e-12)
    distances = 1.0 - vectors @ centroid
    median = float(np.median(distances))
    mad = float(np.median(np.abs(distances - median)))
    limit = median + max(3.0 * mad, 0.04)
    keep = distances <= limit
    if int(keep.sum()) < min(3, len(vectors)):
        keep[:] = True
    return keep


def predict(probe: np.ndarray, train_x: np.ndarray, train_y: np.ndarray, threshold: float) -> str:
    distances = 1.0 - train_x @ probe
    best_label, best_score = "unknown", float("inf")
    for label in np.unique(train_y):
        score = float(np.median(np.sort(distances[train_y == label])[:3]))
        if score < best_score:
            best_label, best_score = str(label), score
    return best_label if best_score <= threshold else "unknown"


def suggested_threshold(vectors: np.ndarray, labels: np.ndarray, fallback: float) -> float:
    genuine, impostor = [], []
    for index, probe in enumerate(vectors):
        distances = 1.0 - vectors @ probe
        distances[index] = np.inf
        same = distances[labels == labels[index]]
        other = distances[labels != labels[index]]
        if np.isfinite(same).any():
            genuine.append(float(np.min(same)))
        if np.isfinite(other).any():
            impostor.append(float(np.min(other)))
    if not genuine or not impostor:
        return fallback
    upper_genuine = float(np.percentile(genuine, 95))
    lower_impostor = float(np.percentile(impostor, 5))
    if upper_genuine >= lower_impostor:
        return fallback
    return float(np.clip((upper_genuine + lower_impostor) / 2.0, 0.05, 0.95))


def main() -> None:
    config = load_config()
    dataset_dir = Path(config["paths"]["dataset"])
    image_paths = [
        path for path in sorted(dataset_dir.glob("*/*"))
        if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS
    ]
    labels_found = sorted({path.parent.name for path in image_paths})
    if len(labels_found) < 1:
        raise RuntimeError(
            "Dataset belum tersedia. Jalankan 1_collect_dataset.py terlebih dahulu."
        )

    raw_vectors: list[np.ndarray] = []
    raw_labels: list[str] = []
    print(f"[EMBEDDING] Memproses {len(image_paths)} gambar dari {len(labels_found)} orang.")
    for index, path in enumerate(image_paths, start=1):
        image = cv2.imread(str(path))
        if image is None:
            print(f"[LEWATI] Gambar rusak: {path}")
            continue
        try:
            raw_vectors.append(represent(image, config))
            raw_labels.append(path.parent.name)
        except Exception as exc:
            print(f"[LEWATI] {path.name}: {exc}")
        if index % 25 == 0 or index == len(image_paths):
            print(f"  {index}/{len(image_paths)}")

    vectors = np.vstack(raw_vectors).astype(np.float32)
    labels = np.asarray(raw_labels, dtype="U64")
    keep_all = np.zeros(len(labels), dtype=bool)
    for face_id in np.unique(labels):
        positions = np.where(labels == face_id)[0]
        keep = remove_outliers(vectors[positions])
        keep_all[positions[keep]] = True
        print(f"[OUTLIER] {face_id}: dipakai {int(keep.sum())}/{len(positions)} sampel")
    vectors, labels = vectors[keep_all], labels[keep_all]

    default_threshold = resolve_threshold(config)
    recommendation = suggested_threshold(vectors, labels, default_threshold)
    threshold = float(config["deepface"].get("threshold") or default_threshold)

    train_x, test_x, train_y, test_y = train_test_split(
        vectors, labels, test_size=0.20, random_state=42, stratify=labels
    )
    predictions = [predict(probe, train_x, train_y, threshold) for probe in test_x]
    accuracy = accuracy_score(test_y, predictions)
    matrix_labels = sorted(set(labels.tolist()) | {"unknown"})
    matrix = confusion_matrix(test_y, predictions, labels=matrix_labels)

    output = Path(config["paths"]["embeddings"])
    output.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "embeddings": vectors,
        "labels": labels,
        "model_name": config["deepface"]["model_name"],
        "detector_backend": config["deepface"]["detector_backend"],
        "distance_metric": config["deepface"]["distance_metric"],
        "threshold": threshold,
        "suggested_threshold": recommendation,
        "sample_counts": dict(Counter(labels.tolist())),
        "evaluation_accuracy": float(accuracy),
        "confusion_labels": matrix_labels,
        "confusion_matrix": matrix,
    }
    with output.open("wb") as handle:
        pickle.dump(data, handle, protocol=pickle.HIGHEST_PROTOCOL)

    print(f"\n[EVALUASI] Akurasi split 80/20: {accuracy * 100:.2f}%")
    print(f"[THRESHOLD] Bawaan/aktif: {threshold:.4f}")
    print(f"[THRESHOLD] Saran berdasarkan dataset: {recommendation:.4f}")
    print("[CONFUSION MATRIX] label:", matrix_labels)
    print(matrix)
    print(f"[SELESAI] Database embedding: {output}")


if __name__ == "__main__":
    main()
