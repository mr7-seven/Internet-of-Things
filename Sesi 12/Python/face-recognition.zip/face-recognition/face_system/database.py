from __future__ import annotations

import json
import pickle
from pathlib import Path
from typing import Any

import numpy as np

from .vision import confidence_from_distance, represent, resolve_threshold


class EmbeddingDatabase:
    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        path = Path(config["paths"]["embeddings"])
        if not path.exists():
            raise FileNotFoundError(
                "Database embedding belum tersedia. Jalankan: python 2_build_embeddings.py"
            )
        with path.open("rb") as handle:
            data = pickle.load(handle)

        expected = config["deepface"]
        for key in ("model_name", "detector_backend", "distance_metric"):
            if data.get(key) != expected[key]:
                raise ValueError(
                    f"Konfigurasi {key} berubah ({data.get(key)} -> {expected[key]}). "
                    "Bangun ulang embedding dengan 2_build_embeddings.py."
                )
        self.embeddings = np.asarray(data["embeddings"], dtype=np.float32)
        self.labels = np.asarray(data["labels"], dtype=str)
        self.face_ids = sorted(set(self.labels.tolist()))
        self.threshold = float(config["deepface"].get("threshold") or data.get("threshold") or resolve_threshold(config))
        self.profiles = self._load_profiles()

    def _load_profiles(self) -> dict[str, str]:
        path = Path(self.config["paths"]["profiles"])
        if not path.exists():
            return {}
        try:
            with path.open("r", encoding="utf-8") as handle:
                raw = json.load(handle)
            return {str(key): str(value) for key, value in raw.items()}
        except (OSError, ValueError):
            return {}

    def display_name(self, face_id: str) -> str:
        name = self.profiles.get(face_id, "").strip()
        #return f"{name}/{face_id}" if name else face_id
        return name if name else face_id

    def update_profiles(self, payload: dict[str, Any]) -> None:
        profiles = payload.get("profiles", {})
        if not isinstance(profiles, dict):
            return
        self.profiles = {str(key): str(value) for key, value in profiles.items()}
        path = Path(self.config["paths"]["profiles"])
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as handle:
            json.dump(self.profiles, handle, ensure_ascii=False, indent=2)

    def identify(self, crop_bgr) -> dict[str, Any]:
        probe = represent(crop_bgr, self.config)
        distances = 1.0 - self.embeddings @ probe
        best_id, best_distance = "unknown", float("inf")
        for face_id in self.face_ids:
            own = np.sort(distances[self.labels == face_id])[:3]
            score = float(np.median(own))
            if score < best_distance:
                best_id, best_distance = face_id, score
        recognized = best_distance <= self.threshold
        return {
            "face_id": best_id if recognized else "unknown",
            "distance": best_distance,
            "confidence": confidence_from_distance(best_distance, self.threshold),
            "recognized": recognized,
        }
