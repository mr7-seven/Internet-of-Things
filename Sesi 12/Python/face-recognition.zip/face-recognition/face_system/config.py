from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]


def load_config() -> dict[str, Any]:
    path = ROOT / "config.json"
    with path.open("r", encoding="utf-8") as handle:
        config: dict[str, Any] = json.load(handle)

    identity = config["identity"]
    for key in ("id_group", "node_id"):
        value = str(identity.get(key, ""))
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,24}", value):
            raise ValueError(f"identity.{key} hanya boleh berisi huruf, angka, _ atau - (maks. 24).")

    for key in ("dataset", "embeddings", "profiles"):
        config["paths"][key] = str((ROOT / config["paths"][key]).resolve())
    return config


def mqtt_topics(config: dict[str, Any]) -> dict[str, str]:
    base = f"{config['identity']['id_group']}/{config['identity']['node_id']}"
    return {
        "face_status": f"{base}/face/status",
        "face_register": f"{base}/face/register",
        "face_profiles": f"{base}/face/profiles",
        "esp32_cmd": f"{base}/esp32/cmd",
        "esp32_status": f"{base}/esp32/status",
        "camera_status": f"{base}/camera/status",
    }


def open_camera(config: dict[str, Any]):
    import cv2
    import os

    camera_cfg = config["camera"]
    backend = cv2.CAP_DSHOW if os.name == "nt" else cv2.CAP_ANY
    capture = cv2.VideoCapture(int(camera_cfg["index"]), backend)
    capture.set(cv2.CAP_PROP_FRAME_WIDTH, int(camera_cfg["width"]))
    capture.set(cv2.CAP_PROP_FRAME_HEIGHT, int(camera_cfg["height"]))
    capture.set(cv2.CAP_PROP_FPS, int(camera_cfg["fps"]))
    capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    if not capture.isOpened():
        raise RuntimeError(
            f"Kamera index {camera_cfg['index']} gagal dibuka. Periksa izin kamera dan config.json."
        )
    return capture

