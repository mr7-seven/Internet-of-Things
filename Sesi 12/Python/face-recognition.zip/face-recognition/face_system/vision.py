from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

os.environ.setdefault("CUDA_VISIBLE_DEVICES", "-1")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
os.environ.setdefault("TF_USE_LEGACY_KERAS", "1")
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "1")

import cv2
import numpy as np
from deepface import DeepFace
from deepface.modules.verification import find_threshold


@dataclass
class DetectedFace:
    crop_bgr: np.ndarray
    box: tuple[int, int, int, int]
    detector_confidence: float
    is_real: bool


def resolve_threshold(config: dict[str, Any]) -> float:
    configured = config["deepface"].get("threshold")
    if configured is not None:
        return float(configured)
    return float(
        find_threshold(
            config["deepface"]["model_name"],
            config["deepface"]["distance_metric"],
        )
    )


def extract_faces(frame_bgr: np.ndarray, config: dict[str, Any]) -> list[DetectedFace]:
    deep_cfg = config["deepface"]
    try:
        results = DeepFace.extract_faces(
            img_path=frame_bgr,
            detector_backend=deep_cfg["detector_backend"],
            enforce_detection=True,
            align=True,
            anti_spoofing=bool(deep_cfg.get("anti_spoofing", False)),
        )
    except (ValueError, RuntimeError):
        return []

    faces: list[DetectedFace] = []
    minimum = int(config["performance"]["min_face_size"])
    for result in results:
        area = result.get("facial_area", {})
        x, y = int(area.get("x", 0)), int(area.get("y", 0))
        w, h = int(area.get("w", 0)), int(area.get("h", 0))
        if min(w, h) < minimum:
            continue
        face_rgb = np.asarray(result["face"])
        if face_rgb.dtype != np.uint8:
            face_rgb = np.clip(face_rgb * 255.0, 0, 255).astype(np.uint8)
        crop_bgr = cv2.cvtColor(face_rgb, cv2.COLOR_RGB2BGR)
        faces.append(
            DetectedFace(
                crop_bgr=crop_bgr,
                box=(x, y, w, h),
                detector_confidence=float(result.get("confidence", 0.0)),
                is_real=bool(result.get("is_real", True)),
            )
        )
    return faces


def represent(face_bgr: np.ndarray, config: dict[str, Any]) -> np.ndarray:
    result = DeepFace.represent(
        img_path=face_bgr,
        model_name=config["deepface"]["model_name"],
        detector_backend="skip",
        enforce_detection=False,
        align=True,
        normalization="base",
    )
    vector = np.asarray(result[0]["embedding"], dtype=np.float32)
    return vector / max(float(np.linalg.norm(vector)), 1e-12)


def cosine_distance(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return 1.0 - np.asarray(a) @ np.asarray(b)


def confidence_from_distance(distance: float, threshold: float) -> float:
    if distance <= threshold:
        value = 0.5 + 0.5 * (threshold - distance) / max(threshold, 1e-6)
    else:
        value = 0.5 * max(0.0, 1.0 - (distance - threshold) / max(1.0 - threshold, 1e-6))
    return float(np.clip(value * 100.0, 0.0, 100.0))


def draw_yolo_box(frame, box, label: str, color: tuple[int, int, int]) -> None:
    x, y, w, h = box
    cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2, cv2.LINE_AA)
    font = cv2.FONT_HERSHEY_SIMPLEX
    scale, thickness = 0.55, 2
    (text_w, text_h), baseline = cv2.getTextSize(label, font, scale, thickness)
    top = max(0, y - text_h - baseline - 10)
    right = min(frame.shape[1] - 1, x + text_w + 12)
    cv2.rectangle(frame, (x, top), (right, y), color, -1)
    cv2.putText(frame, label, (x + 6, y - baseline - 4), font, scale, (255, 255, 255), thickness, cv2.LINE_AA)
