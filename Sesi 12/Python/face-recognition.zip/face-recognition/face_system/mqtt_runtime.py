from __future__ import annotations

import json
import platform
import random
import threading
import time
from datetime import datetime, timezone
from typing import Any, Callable

import paho.mqtt.client as mqtt

from .config import mqtt_topics


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


class MqttRuntime:
    def __init__(self, config: dict[str, Any], profiles_callback: Callable[[dict[str, Any]], None] | None = None) -> None:
        self.config = config
        self.cfg = config["mqtt"]
        self.topics = mqtt_topics(config)
        self.profiles_callback = profiles_callback
        suffix = f"{platform.node()[:10]}-{random.randint(0, 0xFFFFFF):06x}"
        prefix = f"face-{config['identity']['id_group']}-{config['identity']['node_id']}"
        self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"{prefix}-{suffix}"[:64])
        if self.cfg.get("username"):
            self.client.username_pw_set(self.cfg["username"], self.cfg.get("password", ""))
        self.client.reconnect_delay_set(1, 30)
        offline = self._base_payload("offline")
        self.client.will_set(self.topics["camera_status"], self._json(offline), qos=1, retain=True)
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message
        self.connected = threading.Event()

    def _base_payload(self, state: str) -> dict[str, Any]:
        return {
            "id_group": self.config["identity"]["id_group"],
            "node_id": self.config["identity"]["node_id"],
            "state": state,
            "timestamp": utc_now(),
        }

    @staticmethod
    def _json(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))

    def _on_connect(self, client, userdata, flags, reason_code, properties) -> None:
        if reason_code == 0:
            self.connected.set()
            client.publish(
                self.topics["camera_status"],
                self._json(self._base_payload("online")),
                qos=1,
                retain=True,
            )
            if self.profiles_callback is not None:
                client.subscribe(self.topics["face_profiles"], qos=1)
            print(f"[MQTT] Terhubung ke {self.cfg['host']}:{self.cfg['port']}")
        else:
            print(f"[MQTT] Koneksi ditolak: {reason_code}")

    def _on_disconnect(self, client, userdata, disconnect_flags, reason_code, properties) -> None:
        self.connected.clear()
        if reason_code != 0:
            print(f"[MQTT] Terputus ({reason_code}); reconnect otomatis aktif.")

    def _on_message(self, client, userdata, message) -> None:
        if message.topic != self.topics["face_profiles"] or self.profiles_callback is None:
            return
        try:
            payload = json.loads(message.payload.decode("utf-8"))
            self.profiles_callback(payload)
            print("[MQTT] Nama profil pengguna diperbarui dari Node-RED.")
        except (UnicodeDecodeError, ValueError, OSError) as exc:
            print(f"[MQTT] Profil pengguna tidak valid: {exc}")

    def start(self) -> None:
        self.client.connect_async(
            self.cfg["host"], int(self.cfg["port"]), int(self.cfg.get("keepalive", 60))
        )
        self.client.loop_start()

    def publish(self, topic_key: str, payload: dict[str, Any], retain: bool = False) -> bool:
        body = {**self._base_payload(payload.get("state", "event")), **payload}
        info = self.client.publish(
            self.topics[topic_key],
            self._json(body),
            qos=int(self.cfg.get("qos", 1)),
            retain=retain,
        )
        return info.rc == mqtt.MQTT_ERR_SUCCESS

    def stop(self) -> None:
        if self.connected.is_set():
            info = self.client.publish(
                self.topics["camera_status"],
                self._json(self._base_payload("offline")),
                qos=1,
                retain=True,
            )
            info.wait_for_publish(timeout=2.0)
        self.client.disconnect()
        self.client.loop_stop()
