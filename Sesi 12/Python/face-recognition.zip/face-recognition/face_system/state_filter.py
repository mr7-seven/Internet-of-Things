from __future__ import annotations

import time
from dataclasses import dataclass


@dataclass(frozen=True)
class StableState:
    state: str
    face_id: str

    @property
    def key(self) -> str:
        return f"{self.state}:{self.face_id}"


class StateFilter:
    def __init__(self, confirm_frames: int, unknown_frames: int, lost_frames: int, hold_seconds: float) -> None:
        self.confirm_frames = max(1, confirm_frames)
        self.unknown_frames = max(1, unknown_frames)
        self.lost_frames = max(1, lost_frames)
        self.hold_seconds = max(0.0, hold_seconds)
        self.stable = StableState("idle", "")
        self.candidate = self.stable
        self.count = 0
        self.last_face_at = time.monotonic()

    def update(self, state: str, face_id: str = "") -> tuple[StableState, bool]:
        now = time.monotonic()
        if state != "idle":
            self.last_face_at = now
        elif now - self.last_face_at < self.hold_seconds:
            return self.stable, False

        candidate = StableState(state, face_id if state == "recognized" else "")
        if candidate == self.candidate:
            self.count += 1
        else:
            self.candidate = candidate
            self.count = 1

        required = self.confirm_frames
        if state == "unknown":
            required = self.unknown_frames
        elif state == "idle":
            required = self.lost_frames

        if self.count < required or candidate == self.stable:
            return self.stable, False
        self.stable = candidate
        return self.stable, True
