"""Komponen bersama sistem keamanan pengenalan wajah."""

