from __future__ import annotations

import argparse

import cv2

from face_system.config import load_config
from face_system.database import EmbeddingDatabase
from face_system.vision import draw_yolo_box, extract_faces


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Uji beberapa wajah dalam satu gambar terhadap database embedding."
    )
    parser.add_argument("image", help="Path gambar uji")
    args = parser.parse_args()
    image = cv2.imread(args.image)
    if image is None:
        raise FileNotFoundError(f"Gambar tidak dapat dibaca: {args.image}")
    config = load_config()
    database = EmbeddingDatabase(config)
    faces = extract_faces(image, config)

    recognized_count = 0
    unknown_count = 0

    for index, face in enumerate(faces, start=1):
        result = database.identify(face.crop_bgr)

        if result["recognized"]:
            recognized_count += 1
            face_id = result["face_id"]
            identity = database.display_name(face_id)
            label = f"{identity} | {result['confidence']:.1f}%"
            color = (0, 200, 0)
        else:
            unknown_count += 1
            label = f"UNKNOWN | {result['confidence']:.1f}%"
            color = (0, 0, 255)

        draw_yolo_box(image, face.box, label, color)
        print(
            f"Wajah {index}: {label} | "
            f"distance={result['distance']:.4f} | "
            f"recognized={result['recognized']}"
        )

    total_faces = len(faces)
    print("\n=== RINGKASAN ===")
    print(f"Total wajah    : {total_faces}")
    print(f"Dikenali       : {recognized_count}")
    print(f"Tidak dikenal  : {unknown_count}")

    display = cv2.copyMakeBorder(
        image,
        0,
        54,
        0,
        0,
        cv2.BORDER_CONSTANT,
        value=(24, 28, 32),
    )
    summary = (
        f"TOTAL {total_faces}  |  DIKENALI {recognized_count}  |  "
        f"UNKNOWN {unknown_count}"
    )
    cv2.putText(
        display,
        summary,
        (10, image.shape[0] + 20),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.52,
        (80, 230, 160),
        2,
        cv2.LINE_AA,
    )
    cv2.putText(
        display,
        f"Threshold: {database.threshold:.4f} | Q / ESC untuk menutup",
        (10, image.shape[0] + 43),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.42,
        (220, 225, 230),
        1,
        cv2.LINE_AA,
    )


    cv2.namedWindow("Recognition Test", cv2.WINDOW_AUTOSIZE)
    cv2.imshow("Recognition Test", display)

    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
